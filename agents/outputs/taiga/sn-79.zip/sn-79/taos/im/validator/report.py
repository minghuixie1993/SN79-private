# SPDX-FileCopyrightText: 2025 Rayleigh Research <to@rayleigh.re>
# SPDX-License-Identifier: MIT
"""
Prometheus metrics reporting service: publishes validator, simulation, miner,
book, trade, and GenTRX gauges via a FastAPI endpoint over POSIX IPC.
"""
import os
import sys
import traceback
import time
import torch
import psutil
import asyncio
import bittensor as bt
import pandas as pd
import posix_ipc
import mmap
import struct
import msgpack
import argparse    

from typing import Dict
from collections import deque, defaultdict
from concurrent.futures import ThreadPoolExecutor
from taos.im.protocol.models import TradeInfo, MarketSimulationConfig
from taos.im.validator.block_stats import empty_block_stats
from taos.im.protocol.events import TradeEvent

from taos.common.utils.prometheus import prometheus
from taos.im.utils import duration_from_timestamp
from taos.im.config import debeta_dial
from taos.im.validator.ingest_payload import kappa_maps, debeta_maps, scoring_params
from prometheus_client import Counter, Gauge, Info, CollectorRegistry, generate_latest, CONTENT_TYPE_LATEST
from prometheus_client.core import GaugeMetricFamily
from taos.im.validator.exposition import Exposition, SNAPSHOT_ENABLED
from fastapi.responses import Response
from taos.im.validator.http_surface import PerClientConcurrency, make_app, metrics_server_options
import uvicorn
import threading

async def _push_to_mvtrx_data_service(state_dict: dict, url: str) -> None:
    """Delegate to the optional data-service push module when present."""
    try:
        from taos.im.validator.mvtrx_push import push_to_data_service as _push
    except ImportError:
        return
    await _push(state_dict, url)


# Exposition warm-up ceiling. The reporting subprocess restarts with the
# validator; its Prometheus registries start EMPTY and are not repopulated until
# the first publish_metrics completes (the validator spends several minutes on
# wallet loading + balance refresh + bootstrap first). Serving /metrics during
# that window returns empty gauges, which the scraper records as false zeros —
# the source of the dashboard dip on every restart. We withhold exposition
# (HTTP 503 = a scrape gap, not zeros) until the first publish, but never
# indefinitely: after this many seconds we serve whatever we have so a validator
# that genuinely never publishes can't wedge /metrics at 503 and hide the box.
# GZIP OF THE PROMETHEUS EXPOSITION -- opt-in, read once here rather than at each server start.
#
# Level 6, not the library's default of 9: on Prometheus text the two land within a few percent of
# each other on size while 9 costs several times the CPU, and that cost is paid on the event loop
# that is serving the scrape. A level high enough to make the scrape slower than the transfer it
# saves defeats the purpose.
_METRICS_GZIP_ENABLED = os.environ.get("MVTRX_METRICS_GZIP", "0").strip().lower() in ("1", "true", "yes", "on")
try:
    _METRICS_GZIP_LEVEL = min(9, max(1, int(os.environ.get("MVTRX_METRICS_GZIP_LEVEL", "6"))))
except ValueError:
    _METRICS_GZIP_LEVEL = 6

_EXPOSITION_WARMUP_MAX_SECONDS = 600


class ReportingService:
    # Shared validator state pushed in via IPC before each report (not set in
    # __init__). Annotation-only declarations — no runtime effect — so static
    # analysis resolves these attributes.
    """Out-of-process reporting: consumes validator state snapshots and serves metrics.

    Runs as its own process so a slow scrape or a large snapshot can never block a validator step.
    """
    kappa_values: dict
    activity_factors: dict
    pnl_factors: dict
    scores: dict
    unnormalized_scores: dict
    miner_stats: dict
    initial_balances: dict
    initial_balances_published: dict
    step_rates: dict
    validator_config: dict
    current_block: int
    simulation_timestamp: int
    step: int
    uid: int
    fundamental_price: float
    shared_state_reporting: bool

    def _response_for(self, data: dict) -> dict:
        """What the main process gets back for one publish: the step, and the two pieces of state the service owns
        between cycles. A publish that deferred (the simulation id not yet known on a cold run) returned before it
        copied the request's state onto the service, so the loop read attributes that were never set and failed every
        cycle until the id appeared (localnet deploy, 7 October 2026). The request's own values answer in that case,
        so the main process gets back exactly what it sent."""
        return {
            'step': data.get('step'),
            'initial_balances_published': getattr(self, 'initial_balances_published', None)
            if getattr(self, 'initial_balances_published', None) is not None
            else dict(data.get('initial_balances_published') or {}),
            'miner_stats': getattr(self, 'miner_stats', None)
            if getattr(self, 'miner_stats', None) is not None
            else dict(data.get('miner_stats') or {}),
        }

    def __init__(self, config):
        """
        Initialise the reporting service, setting up IPC channels and Prometheus metrics.

        Creates POSIX message queues and shared memory segments for receiving
        publish requests from the validator, initialises all Prometheus registries,
        and starts the FastAPI metrics server in a background thread.

        Args:
            config: Configuration object with wallet, netuid, and prometheus settings.
        """
        self.config = config
        self.wallet = bt.Wallet(
            path=self.config.wallet.path,
            name=self.config.wallet.name,
            hotkey=self.config.wallet.hotkey
        )
        self.running = True
        self.prometheus_initialized = False
        self.current_sim_id = None
        # Exposition warm-up guard: /metrics is withheld (503) until the first
        # publish_metrics fully processes a payload, so a cold restart serves a
        # scrape gap instead of empty-gauge false zeros. See _metrics_ready().
        self._first_publish_done = False
        self._exposition_start = time.monotonic()
        
        _pfx = getattr(config, 'ipc_prefix', 'validator')
        bt.logging.info(f"Reporting service IPC prefix: {_pfx!r}")
        self.request_queue = posix_ipc.MessageQueue(
            f"/{_pfx}-report-req",
            flags=posix_ipc.O_CREAT,
            max_messages=2,
            max_message_size=1024
        )
        self.response_queue = posix_ipc.MessageQueue(
            f"/{_pfx}-report-res",
            flags=posix_ipc.O_CREAT,
            max_messages=2,
            max_message_size=1024
        )
        self.request_shm = posix_ipc.SharedMemory(
            f"/{_pfx}-report-data",
            flags=posix_ipc.O_CREAT,
            size=200 * 1024 * 1024
        )
        self.response_shm = posix_ipc.SharedMemory(
            f"/{_pfx}-report-response-data",
            flags=posix_ipc.O_CREAT,
            size=100 * 1024 * 1024
        )
        
        self.request_mem = mmap.mmap(self.request_shm.fd, self.request_shm.size)
        self.response_mem = mmap.mmap(self.response_shm.fd, self.response_shm.size)
        
        self.thread_pool = ThreadPoolExecutor(max_workers=2)
        self.report_executor = ThreadPoolExecutor(max_workers=1)        
        self._init_prometheus()
        
    def _metrics_ready(self):
        """Whether the /metrics endpoints may serve exposition yet.

        Ready once the first publish_metrics has fully processed a payload
        (`_first_publish_done`), OR once the bounded warm-up ceiling has elapsed
        — the ceiling ensures a validator that never publishes cannot wedge
        /metrics at 503 forever (we then serve whatever we have). Before either,
        the endpoints return 503 so the scraper records a gap rather than the
        empty-gauge zeros that cause the dashboard dip on restart.
        """
        if self._first_publish_done:
            return True
        return (time.monotonic() - self._exposition_start) >= _EXPOSITION_WARMUP_MAX_SECONDS

    def _metrics_app(self):
        """The metrics app: the combined /metrics and one path per registry family."""
        app = make_app()
        # OFF UNLESS ASKED FOR. Compressing the exposition trades CPU on the scrape path against
        # transfer size, and whether that trade pays depends on how large the exposition is, how often
        # it is scraped and what sits between the two -- none of which match between a development box
        # and a production deployment. Where this was a problem it was resolved by giving the host more
        # capacity, so the capability stays available rather than applied by default.
        if _METRICS_GZIP_ENABLED:
            from fastapi.middleware.gzip import GZipMiddleware

            app.add_middleware(GZipMiddleware, minimum_size=1024, compresslevel=_METRICS_GZIP_LEVEL)
            bt.logging.info(
                f"Prometheus exposition will be gzipped at level {_METRICS_GZIP_LEVEL}"
            )
        # Added last, so it is the outermost layer: a request past its address's bound is refused before any work.
        app.add_middleware(PerClientConcurrency)

        def _warmup_response():
            # None => ready to serve; an empty 200 => still warming up. We return
            # 200 (not 503) so the scraper records a scrape GAP (absent series, no
            # false zeros) WITHOUT flipping up=0 / firing target-down alerts on every
            # restart. The body carries only a comment, so no gauge series are emitted.
            if self._metrics_ready():
                return None
            return Response(content=b"# metrics warming up\n", status_code=200, media_type=CONTENT_TYPE_LATEST)

        def _body(name=None):
            # The frozen cycle, rendered once and sliced per registry; before the first cycle, or with
            # the snapshot switched off, the live render the child served until 30 September 2026.
            if SNAPSHOT_ENABLED:
                served = self.exposition.serve(name)
                if served is not None:
                    return served
            if name is None:
                return b''.join(
                    generate_latest(self.registries[n]) for n in self.exposition.main_registries() if n in self.registries
                )
            return generate_latest(self.registries[name])

        def _endpoint(name=None):
            warming = _warmup_response()
            if warming is not None:
                return warming
            return Response(content=_body(name), media_type=CONTENT_TYPE_LATEST)

        @app.get("/metrics")
        def all_metrics():
            """The board registries combined; agent and trades are on their own endpoints unless MVTRX_METRICS_MAIN=all"""
            return _endpoint()

        @app.get("/metrics/validator")
        def validator_metrics():
            """Validator-specific metrics: counters, validator_gauges, neuron_info"""
            return _endpoint('validator')

        @app.get("/metrics/simulation")
        def simulation_metrics():
            """Simulation metrics: simulation_gauges"""
            return _endpoint('simulation')

        @app.get("/metrics/miner")
        def miner_metrics():
            """Miner metrics: miner_gauges, miners, miner_identity"""
            return _endpoint('miner')

        @app.get("/metrics/agent")
        def agent_metrics():
            """Miner metrics: agent_gauges"""
            return _endpoint('agent')

        @app.get("/metrics/books")
        def book_metrics():
            """Book metrics: book_gauges, books"""
            return _endpoint('books')

        @app.get("/metrics/trades")
        def trade_metrics():
            """Trade metrics: trades, miner_trades"""
            return _endpoint('trades')

        @app.get("/metrics/gentrx")
        def gentrx_metrics():
            """GenTRX distributed-training metrics: pool allocation, per-miner EMA scores."""
            return _endpoint('gentrx')

        return app

    def _start_metrics_server(self):
        """Serve the metrics app from a daemon thread, which ends with the process. The bind address and the port
        come from metrics_server_options (http_surface); the per-address bound is the app's own middleware."""
        app = self._metrics_app()
        options = metrics_server_options(self.config)

        def run_server():
            """Serve the metrics endpoint until the process is stopped."""
            uvicorn.run(app, **metrics_server_options(self.config))

        self.metrics_server_thread = threading.Thread(target=run_server, daemon=True)
        self.metrics_server_thread.start()
        bt.logging.success(f"Prometheus metrics server started on {options['host']}:{options['port']}")
    
    def _init_prometheus(self):
        """
        Initialise all Prometheus collector registries and metric objects.

        Creates separate registries for validator, simulation, miner, agent, books,
        trades, and gentrx metrics, then starts the metrics HTTP server.
        """
        prometheus(
            config=self.config,
            port=self.config.prometheus.port,
            level=None,
            start_server=False
        )
        self.registry_validator = CollectorRegistry()
        self.registry_simulation = CollectorRegistry()
        self.registry_miner = CollectorRegistry()
        self.registry_agent = CollectorRegistry()
        self.registry_books = CollectorRegistry()
        self.registry_trades = CollectorRegistry()
        self.registry_gentrx = CollectorRegistry()

        self.registries = {
            'validator': self.registry_validator,
            'simulation': self.registry_simulation,
            'miner': self.registry_miner,
            'agent': self.registry_agent,
            'books': self.registry_books,
            'trades': self.registry_trades,
            'gentrx': self.registry_gentrx,
        }
        # One scrape, one cycle: report() publishes a frozen snapshot of every family at the end of each
        # cycle and the endpoints serve slices of its one render (exposition.py).
        self.exposition = Exposition(self.registries)

        # Child-handle / last-value cache for the persistent gauge families
        # (agent_gauges, miner_gauges, book_gauges, simulation_gauges). Keyed by
        # (id(gauge), label_tuple) -> [child, last_value]. The apply loop resolves
        # the Prometheus child once and skips the lock+tuple-normalize that
        # gauge.labels() pays on every call, and skips the .set() entirely when
        # the value is unchanged from the prior cycle. This is the hot path at
        # full cardinality (~1.6M agent_gauges updates/cycle on mainnet's
        # 128 books x ~256 miners). Cleared families (trades/books/miner_trades)
        # are NOT cached — their children are destroyed each cycle. Entries are
        # evicted via _remove_and_evict on every .remove(), and the whole cache
        # is reset on simulation changeover (clear_all_metrics).
        self._child_cache = {}

        # Read ONCE at init, not per book: this is checked inside a 259x128 loop, so a getattr
        # chain through the config there would run ~33k times a cycle for a constant.
        _sc = getattr(getattr(self, 'config', None), 'scoring', None)
        self._debeta_book_gauges = bool(debeta_dial(getattr(_sc, 'debeta', None), 'publish_book_gauges'))

        self.prometheus_counters = Counter('counters', 'Counter summaries for the running validator.', ['wallet', 'netuid', 'sim_id', 'timestamp', 'counter_name'], registry=self.registry_validator)
        # simulation_gauges, miner_gauges and book_gauges are snapshot-backed since 30 September 2026 (carry
        # forward, as the eager Gauges did) so that a scrape is one frozen cycle; see exposition.py.
        self.prometheus_simulation_gauges = _SnapshotCollector('simulation_gauges', 'Gauge summaries for global simulation metrics.', ['wallet', 'netuid', 'sim_id', 'simulation_gauge_name'])
        self.registry_simulation.register(self.prometheus_simulation_gauges)
        # Per asset class under a multi-asset layout (0.6.3): weight, bar, books, makers, skilled uids, credit and the
        # weight a class effectively carries after a quiet class hands its weight back. Empty on a single market.
        self.prometheus_class_gauges = _SnapshotCollector('class_gauges', 'Gauge summaries per asset class.',
                                                           ['wallet', 'netuid', 'sim_id', 'asset_class', 'class_gauge_name'])
        self.registry_simulation.register(self.prometheus_class_gauges)
        # the per-class per-uid de-beta detail the class pools are built from (0.6.3), so an agent's making, ranks,
        # factors and books can be read per asset class on the dashboards
        self.prometheus_agent_class_gauges = _SnapshotCollector('agent_class_gauges', 'Per-miner de-beta detail per asset class.',
                                                                 ['wallet', 'netuid', 'sim_id', 'asset_class', 'agent_id', 'agent_class_gauge_name'])
        self.registry_simulation.register(self.prometheus_agent_class_gauges)
        self.prometheus_validator_gauges = Gauge('validator_gauges', 'Gauge summaries for validator-related metrics.', ['wallet', 'netuid', 'sim_id', 'validator_gauge_name'], registry=self.registry_validator)
        self.prometheus_miner_gauges = _SnapshotCollector('miner_gauges', 'Gauge summaries for miner-related metrics.', ['wallet', 'netuid', 'sim_id', 'agent_id', 'miner_gauge_name'])
        self.registry_miner.register(self.prometheus_miner_gauges)
        self.prometheus_book_gauges = _SnapshotCollector('book_gauges', 'Gauge summaries for book-related metrics.', ['wallet', 'netuid', 'sim_id', 'book_id', 'level', 'book_gauge_name'])
        self.registry_books.register(self.prometheus_book_gauges)
        # agent_gauges is the high-cardinality family (~1.8M series/cycle). It is
        # served via a snapshot collector instead of an eager Gauge so the per-cycle
        # apply cost (gauge.labels()+locked .set() x1.8M) collapses to a dict swap.
        self.prometheus_agent_gauges = _SnapshotCollector('agent_gauges', 'Gauge summaries for agent-related metrics.', ['wallet', 'netuid', 'sim_id', 'book_id', 'agent_id', 'agent_gauge_name'])
        self.registry_agent.register(self.prometheus_agent_gauges)
        # Bounded-slot shape: per-trade numeric fields live in the metric VALUE keyed
        # by `trade_gauge_name`, indexed by a fixed `slot` (rolling-buffer position).
        # This caps cardinality at books x buffer_len x fields instead of minting a
        # new series per trade (price/fee/volume/timestamp/id are values, not labels).
        # trades / miner_trades / books are clear-and-rebuild families (rolling
        # slot buffers re-emitted in full each cycle). At mainnet cardinality the
        # eager path — gauge.clear() then a fresh labels()+set() per series (the
        # labels() recreates the child the clear() just destroyed) — was ~890K
        # ops/cycle and the dominant reporting-apply cost. Served instead via
        # replace-mode snapshot collectors: the per-cycle cost collapses to a
        # dict build + swap, and serialisation is lock-free on /metrics scrape.
        self.prometheus_trades = _SnapshotCollector('trades', 'Gauge summaries for trade metrics.',
            ['wallet', 'netuid', 'sim_id', 'book_id', 'slot', 'trade_gauge_name'],
            carry_forward=False)
        self.registry_trades.register(self.prometheus_trades)
        self.prometheus_miner_trades = _SnapshotCollector('miner_trades', 'Gauge summaries for agent trade metrics.',
            ['wallet', 'netuid', 'sim_id', 'book_id', 'uid', 'slot', 'miner_trade_gauge_name'],
            carry_forward=False)
        self.registry_trades.register(self.prometheus_miner_trades)
        self.prometheus_books = _SnapshotCollector('books', 'Gauge summaries for book snapshot metrics.', [
            'wallet', 'netuid', 'sim_id', 'timestamp', 'timestamp_str', 'book_id',
            'bid_5', 'bid_vol_5', 'bid_4', 'bid_vol_4', 'bid_3', 'bid_vol_3', 'bid_2', 'bid_vol_2', 'bid_1', 'bid_vol_1',
            'ask_5', 'ask_vol_5', 'ask_4', 'ask_vol_4', 'ask_3', 'ask_vol_3', 'ask_2', 'ask_vol_2', 'ask_1', 'ask_vol_1',
            'book_gauge_name'
        ], carry_forward=False)
        self.registry_books.register(self.prometheus_books)
        # miners and miner_identity are rebuilt in full every cycle: replace-mode snapshot collectors since
        # 30 September 2026, so no scrape can see them half rebuilt (three of 206 mainnet board reads in the
        # week before lost some or all coldkeys that way).
        self.prometheus_miners = _SnapshotCollector('miners', 'Gauge summaries for miner metrics.', [
            'wallet', 'netuid', 'sim_id', 'timestamp', 'timestamp_str', 'agent_id', 'hotkey', 'coldkey', 'axon_ip', 'axon_port', 'axon',
            'placement', 'base_balance', 'base_loan', 'base_collateral', 'quote_balance', 'quote_loan', 'quote_collateral',
            'inventory_value', 'inventory_value_change', 'pnl', 'pnl_change', 'total_realized_pnl',
            'total_daily_volume', 'min_daily_volume', 'average_daily_volume',
            'total_roundtrip_volume', 'min_roundtrip_volume', 'average_roundtrip_volume',
            'activity_factor', 'pnl_factor',
            'kappa', 'kappa_penalty', 'kappa_score',
            'pnl_score', 'combined_score', 'gentrx_score',
            'unnormalized_score', 'score',
            'debeta_score', 'debeta_making_rank', 'debeta_skill_rank', 'debeta_p11_factor',
            'debeta_s3_factor', 'debeta_bg_share',
            'debeta_making_realized', 'debeta_making_captured', 'debeta_making_basis',
            'debeta_making_share', 'debeta_ladder_input',
            'debeta_present', 'debeta_coverage_books', 'debeta_skill_coverage_factor',
            'num_scored_books', 'scorable',
            'miner_gauge_name'
        ], carry_forward=False)
        self.registry_miner.register(self.prometheus_miners)
        self.prometheus_miner_identity = _SnapshotCollector('miner_identity', 'Per-miner identity (hotkey/coldkey/axon) for historical attribution; value always 1.0, re-series on re-registration or axon change.', ['wallet', 'netuid', 'sim_id', 'agent_id', 'hotkey', 'coldkey', 'axon_ip', 'axon_port'], carry_forward=False)
        self.registry_miner.register(self.prometheus_miner_identity)
        self.prometheus_info = Info('neuron_info', "Info summaries for the running validator.", ['wallet', 'netuid', 'sim_id'], registry=self.registry_validator)
        # One info row per asset class (0.6.3): the class's own market configuration with its book range, so the
        # dashboard's Simulation Config table shows every class. A single market is one row named "market".
        self.prometheus_simconfig_info = Info('simulation_config', 'Market configuration per asset class.',
                                              ['wallet', 'netuid', 'sim_id', 'asset_class'], registry=self.registry_validator)
        # book -> asset class, one series per book, so a dashboard can filter any per-book panel by class
        self.prometheus_book_class = Gauge('book_asset_class', 'The asset class each book belongs to (value 1).',
                                           ['wallet', 'netuid', 'sim_id', 'book_id', 'asset_class'],
                                           registry=self.registry_validator)
        self.prometheus_gentrx_gauges = Gauge('gentrx_gauges', 'GenTRX distributed-training validator metrics.', ['wallet', 'netuid', 'sim_id', 'gentrx_gauge_name'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_scores = Gauge('gentrx_miner_scores', 'Per-miner GenTRX EMA score (validator-smoothed).', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self.prometheus_gentrx_training = Gauge('gentrx_training', 'GenTRX model training statistics (loss, acceptance, timing).', ['wallet', 'netuid', 'sim_id', 'stat'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_score_own = Gauge('gentrx_miner_score_own', 'Per-miner GenTRX own-data score (last round, pre-EMA).', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_score_held = Gauge('gentrx_miner_score_held', 'Per-miner GenTRX held-out validation score (last round, pre-EMA).', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_score = Gauge('gentrx_miner_score', 'Per-miner GenTRX combined score (last round, pre-EMA).', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_accepted = Gauge('gentrx_miner_accepted', 'Per-miner GenTRX gradient accepted in last round (1=yes, 0=no).', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_overfitting = Gauge('gentrx_miner_overfitting', 'Per-miner overfitting flag in last round (1=overfit detected, 0=ok).', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_rollback_winner = Gauge('gentrx_miner_rollback_winner', 'Per-miner flag indicating gradient was selected during rollback (1=yes, 0=no).', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self.prometheus_gentrx_miner_grad_norm = Gauge('gentrx_miner_grad_norm', 'Per-miner gradient L2 norm in last round.', ['wallet', 'netuid', 'sim_id', 'uid'], registry=self.registry_gentrx)
        self._start_metrics_server()
        self.prometheus_initialized = True
        
    def clear_all_metrics(self):
        """
        Clear all Prometheus metrics across all registries.
        
        This is called when a new simulation starts to prevent stale metrics
        from the previous simulation from persisting in graphs.
        """
        bt.logging.info("Clearing all metrics for simulation changeover...")
        start = time.time()
        
        try:
            # Clear all gauge metrics
            self.prometheus_simulation_gauges.clear()
            self.prometheus_validator_gauges.clear()
            self.prometheus_miner_gauges.clear()
            self.prometheus_book_gauges.clear()
            self.prometheus_agent_gauges.clear()
            self.prometheus_trades.clear()
            self.prometheus_miner_trades.clear()
            self.prometheus_books.clear()
            self.prometheus_miners.clear()
            self.prometheus_miner_identity.clear()
            self.prometheus_info.clear()
            # Cached children now point at removed series — drop the cache so the
            # next cycle re-resolves fresh handles.
            self._child_cache.clear()
            # a scrape between the changeover and the next cycle sees the cleared families, as it did
            self.exposition.publish(step=getattr(self, 'step', None),
                                    sim_timestamp=getattr(self, 'simulation_timestamp', None),
                                    sim_id=getattr(getattr(self, 'simulation', None), 'simulation_id', None))
            bt.logging.success(f"All metrics cleared ({time.time()-start:.4f}s)")
        except Exception as e:
            bt.logging.error(f"Error clearing metrics: {e}")
            bt.logging.error(traceback.format_exc())

    def _apply_snapshot_collectors(self, updates):
        """Route updates targeting snapshot-collector families into fresh
        per-cycle snapshots and swap them in; return (remaining, agent_count,
        cleared_count) where `remaining` is the non-collector updates for the
        caller to apply via its own path (_set_cached / _set_if_changed).

        agent_gauges carries forward; trades/books/miner_trades replace. Keeping
        the collector set here means both apply paths in publish_metrics stay in
        sync — a family added to one is handled by both.
        """
        agent_collector = self.prometheus_agent_gauges
        snapshots = {
            agent_collector: {},
            self.prometheus_class_gauges: {},
            self.prometheus_agent_class_gauges: {},
            self.prometheus_trades: {},
            self.prometheus_miner_trades: {},
            self.prometheus_books: {},
            # since 30 September 2026 every bulk family is snapshot-backed, so a scrape is one frozen
            # cycle: these three carry forward as their eager Gauges did, miners and miner_identity are
            # rebuilt in full every cycle (replace) as their clear-and-rebuild did, without the window
            # in which a scrape saw the family half rebuilt
            self.prometheus_simulation_gauges: {},
            self.prometheus_miner_gauges: {},
            self.prometheus_book_gauges: {},
            self.prometheus_miners: {},
            self.prometheus_miner_identity: {},
        }
        remaining = []
        for update in updates:
            snap = snapshots.get(update[0])
            if snap is not None:
                snap[update[2:]] = update[1]
            else:
                remaining.append(update)
        for collector, snap in snapshots.items():
            # rows written by set(**labels) during the cycle (miners, miner_identity) join the swap
            snap.update(collector.take_pending())
        for collector, snap in snapshots.items():
            # Fidelity with the old clear-and-rebuild: the eager path only
            # clear()'d a family when it had >=1 update this cycle, so a cycle
            # emitting none (e.g. no new trades) LEFT the prior series in place.
            # Skip the empty swap for replace families so trades/miner_trades
            # don't blank out during quiet cycles. Carry-forward families
            # always update: an empty merge is a no-op that retains their series.
            if snap or collector._carry_forward:
                collector.update(snap)
        cleared_count = (
            len(snapshots[self.prometheus_trades])
            + len(snapshots[self.prometheus_miner_trades])
            + len(snapshots[self.prometheus_books])
        )
        return remaining, len(snapshots[agent_collector]), cleared_count

    async def run(self):
        """
        Main async event loop for the reporting service.

        Drains any stale IPC messages on startup, then waits for 'publish' or
        'shutdown' commands from the validator via the POSIX request queue,
        dispatching to `publish_metrics` and writing results back via shared memory.
        """
        bt.logging.info("Reporting service started")

        while True:
            try:
                self.request_queue.receive(timeout=0.0)
                bt.logging.warning("Drained stale message from reporting request queue")
            except posix_ipc.BusyError:
                break
        
        while self.running:
            try:
                message, _ = self.request_queue.receive(timeout=1.0)
                command = message.decode('utf-8')
                
                if command == 'publish':
                    read_start = time.time()
                    self.request_mem.seek(0)
                    size_bytes = self.request_mem.read(8)
                    data_size = struct.unpack('Q', size_bytes)[0]
                    request_bytes = self.request_mem.read(data_size)
                    
                    deserialize_start = time.time()
                    data = msgpack.unpackb(request_bytes, raw=False, strict_map_key=False)
                    deserialize_time = time.time() - deserialize_start
                    
                    bt.logging.info(f"Read reporting data ({time.time()-read_start:.4f}s, deserialize={deserialize_time:.4f}s)")

                    await self.publish_metrics(data)

                    result = self._response_for(data)
                    write_start = time.time()
                    
                    serialize_start = time.time()
                    result_bytes = msgpack.packb(result, use_bin_type=True)
                    serialize_time = time.time() - serialize_start
                    
                    self.response_mem.seek(0)
                    self.response_mem.write(struct.pack('Q', len(result_bytes)))
                    self.response_mem.write(result_bytes)
                    bt.logging.info(f"Wrote reporting response data ({time.time()-write_start:.4f}s, serialize={serialize_time:.4f}s)")

                    drain_start = time.time()
                    drained = 0
                    while True:
                        try:
                            self.response_queue.receive(timeout=0.0)
                            drained += 1
                        except posix_ipc.BusyError:
                            break
                    if drained > 0:
                        bt.logging.warning(f"Drained {drained} stale reporting response signals ({time.time()-drain_start:.4f}s)")
                    send_start = time.time()
                    max_retries = 3
                    for attempt in range(max_retries):
                        try:
                            self.response_queue.send(b'ready', timeout=1.0)
                            bt.logging.info(f"Reporting Response signal sent ({time.time()-send_start:.4f}s)")
                            break
                        except posix_ipc.BusyError:
                            bt.logging.warning(f"Reporting Response queue full, retry {attempt+1}/{max_retries}")
                            try:
                                self.response_queue.receive(timeout=0.0)
                                bt.logging.debug("Drained one more stale message from Reporting Response Queue")
                            except posix_ipc.BusyError:
                                pass
                            time.sleep(0.1)
                        except Exception as e:
                            bt.logging.error(f"Error sending Reporting response signal: {e}")
                            break
                    
                elif command == 'shutdown':
                    bt.logging.info("Shutdown command received")
                    self.running = False
                    
            except posix_ipc.BusyError:
                await asyncio.sleep(0.01)
            except Exception as e:
                bt.logging.error(f"Error in reporting loop: {e}")
                bt.logging.error(traceback.format_exc())
        
        self.cleanup()
    
    async def publish_metrics(self, data):
        """
        Deserialise a reporting payload and publish all Prometheus metrics.

        Clears stale metrics whenever the simulation ID changes, then delegates
        to `report()` to push updated gauges.

        Args:
            data (dict): Decoded msgpack payload from the validator containing
                simulation state, account balances, trade data, and scoring results.
        """
        new_sim_id = data['simulation']['simulation_id']
        
        if new_sim_id is None:
            # simulation_id is transiently None — on_start() resets it and on_tick()
            # re-derives it on the next state frame. Treat None as "not yet known":
            # skip this publish entirely rather than treating it as a sim change,
            # which would trigger a spurious clear and possibly a double-clear on recovery.
            bt.logging.debug("publish_metrics: simulation_id is None, deferring until valid")
            return

        if self.current_sim_id is not None and new_sim_id != self.current_sim_id:
            # Genuine simulation changeover: both IDs are real and they differ.
            # Clear so stale metrics from the old simulation don't bleed into the new one.
            bt.logging.warning(
                f"Simulation ID changed: {self.current_sim_id} → {new_sim_id}. "
                f"Clearing all metrics..."
            )
            self.clear_all_metrics()
        else:
            # First valid sim_id seen (fresh start, exchange mode, or reporting-service
            # restart mid-simulation). Do NOT clear: a mid-sim restart would wipe valid
            # accumulating metrics, and stale gauges from a prior instance are overwritten
            # naturally on the next publish cycle.
            if self.current_sim_id is None:
                bt.logging.info(
                    f"First valid metrics publish (sim_id={new_sim_id}). "
                    f"Resuming without clearing existing metrics."
                )

        self.current_sim_id = new_sim_id
        
        def deserialize_to_nested_dict(d):
            """Normalize volume-sum dicts to nested {uid: {book_id: float}} with
            int keys. Accepts the nested form the validator now sends directly
            (msgpack preserves int keys under strict_map_key=False) and the legacy
            flat 'uid:book_id' string-keyed form, so a mixed-version validator /
            reporting pair can't silently drop volume data."""
            result = defaultdict(lambda: defaultdict(float))
            for key, val in d.items():
                if isinstance(val, dict):
                    uid = int(key)
                    for book_id, vol in val.items():
                        result[uid][int(book_id)] = vol
                else:
                    uid, book_id = map(int, str(key).split(':'))
                    result[uid][book_id] = val
            return result

        self.recent_trades = {
            int(bookId): [TradeInfo.model_construct(**t) for t in trades]
            for bookId, trades in data['recent_trades'].items()
        }
        self.recent_miner_trades = {
            int(uid): {
                int(bookId): [(TradeEvent.model_construct(**item['trade']), item['role']) for item in trades]
                for bookId, trades in book_trades.items()
            }
            for uid, book_trades in data['recent_miner_trades'].items()
        }

        self.volume_sums = deserialize_to_nested_dict(data['volume_sums'])
        self.maker_volume_sums = deserialize_to_nested_dict(data['maker_volume_sums'])
        self.taker_volume_sums = deserialize_to_nested_dict(data['taker_volume_sums'])
        self.self_volume_sums = deserialize_to_nested_dict(data['self_volume_sums'])
        self.fee_sums = deserialize_to_nested_dict(data.get('fee_sums', {}))
        self.roundtrip_volume_sums = deserialize_to_nested_dict(data['roundtrip_volume_sums'])
        self.inventory_history = data['inventory_history']
        self.inventory_quote = data.get('inventory_quote') or {}

        self.total_realized_pnl = {
            int(uid): pnl for uid, pnl in data['total_realized_pnl'].items()
        }
        self.realized_pnl_by_book = {
            int(uid): {
                int(book_id): pnl 
                for book_id, pnl in books.items()
            }
            for uid, books in data['realized_pnl_by_book'].items()
        }

        for key in ['activity_factors', 'pnl_factors', 'kappa_values',
                    'unnormalized_scores', 'scores', 'miner_stats', 'initial_balances',
                    'initial_balances_published', 'simulation_timestamp', 'step',
                    'step_rates', 'fundamental_price', 'shared_state_rewarding',
                    'current_block', 'uid', 'metagraph_data', 'validator_config']:
            setattr(self, key, data[key])
        self.round_gaps = list(data.get('round_gaps') or [])
        self.query_waits = list(data.get('query_waits') or [])
        self.reward_gate_waits = list(data.get('reward_gate_waits') or [])
        self.pending_reward_tasks = int(data.get('pending_reward_tasks') or 0)
        self.debeta_scores = {int(uid): float(v) for uid, v in (data.get('debeta_scores', {}) or {}).items()}
        self.debeta_class_summary = {int(c): dict(v) for c, v in (data.get('debeta_class_summary') or {}).items()}
        self.debeta_class_details = {int(c): {int(u): dict(d) for u, d in (v or {}).items()}
                                     for c, v in (data.get('debeta_class_details') or {}).items()}
        self.capture_floor_stats = {int(b): dict(v) for b, v in (data.get('capture_floor_stats') or {}).items()}
        self.capture_settle_by_class = {int(c): dict(v) for c, v in (data.get('capture_settle_by_class') or {}).items()}
        self.scoring_shadow_health = data.get('scoring_shadow')
        self.history_clock = data.get('history_clock')
        self.exchange_settlement = data.get('exchange_settlement')

        def _int_keyed_books(d):
            """IPC serialization stringifies keys; the book-gauge block indexes by int uid/book."""
            return {int(u): {int(b): float(x) for b, x in (bk or {}).items()}
                    for u, bk in (d or {}).items()}
        self.capture_buy_sums = _int_keyed_books(data.get('debeta_capture_buy_sums'))
        self.capture_sell_sums = _int_keyed_books(data.get('debeta_capture_sell_sums'))
        self.debeta_alphas_by_book = _int_keyed_books(data.get('debeta_alphas_by_book'))
        self.gentrx_scores = data.get('gentrx_scores', {})
        self.gentrx_enabled = data.get('gentrx_enabled', False)
        self.gentrx_training = data.get('gentrx_training', {})
        self.gentrx_scores_detailed = data.get('gentrx_scores_detailed', {})
        self.gentrx_config = data.get('gentrx_config', {})
        
        class SimpleState:
            """Minimal stand-in for validator state, carrying just what reporting reads."""
            pass
        self.last_state = SimpleState()
        self.last_state.accounts = data['last_state']['accounts']
        self.last_state.books = data['last_state']['books']
        self.last_state.notices = data['last_state']['notices']
        
        class SimpleMetagraph:
            """Minimal stand-in for the metagraph, carrying just what reporting reads."""
            pass
        self.metagraph = SimpleMetagraph()
        for key, value in self.metagraph_data.items():
            setattr(self.metagraph, key, value)
        
        sim_data = data['simulation']
        if 'block_count' in sim_data:
            self.simulation = MarketSimulationConfig(**sim_data)
        else:
            try:
                from taos.im.protocol.exchange_config import ExchangeConfig
            except ImportError:
                # Exchange-engine sim_data only ever arrives when --engine exchange
                # is active. Optional component; not part of this tree, so reaching
                # this branch means a misconfiguration.
                raise RuntimeError(
                    "Exchange engine mode is not supported in this build "
                    "(taos.im.protocol.exchange_config is not available). "
                    "Run with --engine simulation (default)."
                )
            self.simulation = ExchangeConfig(**sim_data)
        
        if not self.prometheus_initialized:
            self._init_prometheus()

        # Build per-agent stats from scoring data available in this context.
        # volume_sums / maker_volume_sums are already deserialized as {uid: {book_id: float}}.
        def _sum_books(d):
            return {uid: sum(float(v) for v in books.values())
                    for uid, books in d.items()}

        # In simulation mode open_positions tracks longs/shorts counts.
        # In exchange mode the LOB accounts['o'] field holds resting orders directly.
        is_exchange = not hasattr(self.simulation, 'block_count')
        agent_open_orders = {}
        agent_orders_detail: dict = {}

        if is_exchange:
            # Build open-order counts and per-order detail from LOB accounts['o'].
            # accounts format: {uid: {netuid: {'o': [{i,s,p,q,...}], 'bb':..., ...}}}
            lob_accounts = data.get('last_state', {}).get('accounts') or {}
            for uid_key, uid_books in lob_accounts.items():
                try:
                    uid = int(uid_key)
                    if not isinstance(uid_books, dict):
                        continue
                    for nid_key, acct in uid_books.items():
                        if not isinstance(acct, dict):
                            continue
                        nid = int(nid_key)
                        for ord_ in (acct.get('o') or []):
                            if not isinstance(ord_, dict):
                                continue
                            lob_id = ord_.get('i', ord_.get('id'))
                            if lob_id is None:
                                continue
                            agent_open_orders[uid] = agent_open_orders.get(uid, 0) + 1
                            agent_orders_detail.setdefault(uid, []).append({
                                "order_id": int(lob_id),
                                "netuid":   nid,
                                "side":     int(ord_.get('s', ord_.get('side', 0))),
                                "price":    float(ord_.get('p', ord_.get('price', 0.0))),
                                "quantity": float(ord_.get('q', ord_.get('quantity', 0.0))),
                            })
                except Exception:
                    continue
            # Stale-Redis fix: explicitly write an empty list for UIDs with no orders
            # so Redis overwrites the key instead of leaving the previous value until TTL.
            for uid_key in lob_accounts:
                try:
                    uid = int(uid_key)
                    if uid not in agent_orders_detail:
                        agent_orders_detail[uid] = []
                except Exception:
                    pass
        else:
            for uid, book_pos in (data.get('open_positions') or {}).items():
                total = sum(
                    p.get('longs_count', 0) + p.get('shorts_count', 0)
                    for p in (book_pos.values() if isinstance(book_pos, dict) else [])
                )
                agent_open_orders[uid] = total

        _ingest_url = (
            getattr(getattr(self.config, 'exchange', None), 'data_service_url', '')
            if is_exchange else
            (getattr(getattr(self.config, 'simulation', None), 'data_service_url', '')
             or getattr(getattr(self.config, 'exchange', None), 'data_service_url', ''))
        )
        # The process-level flag is the authority: it is set once at launch and cannot
        # vary, whereas the per-payload value has been observed arriving False on a
        # single cycle of an observing validator, which ran the entire non-observe
        # reporting path. The payload is still honoured so an older validator that does
        # not forward the flag keeps working.
        _cfg_observe = bool(getattr(getattr(self.config, 'neuron', None), 'observe', False))
        is_observe = _cfg_observe or bool((data.get('validator_config') or {}).get('observe', False))

        asyncio.create_task(_push_to_mvtrx_data_service({
            "mode":           "exchange" if is_exchange else "simulation",
            "network":        getattr(getattr(self.config, 'subtensor', None), 'network', ''),
            "timestamp":      int(time.time() * 1e9),
            "block":          data.get('current_block', 0),
            "books":          data['last_state']['books'],
            "accounts":       data['last_state']['accounts'],
            "pools":          data['last_state'].get('pools'),
            "reconciliation": data.get('reconciliation', {}),
            # per-agent scoring — used by data service to build agent:stats. The kappa and de-beta
            # keys come from the same functions as the validator's own push, so agent_kappa is the
            # kappa TOTAL here as everywhere (this push used to send the kappa SCORE under that key,
            # and the two landed in the same agent_snapshots column).
            "agent_scores":          self.scores,
            **kappa_maps(self.kappa_values),
            **debeta_maps(self.kappa_values),
            "scoring_params":        scoring_params(self.config, self.kappa_values),
            "agent_volume":          _sum_books(self.volume_sums),
            "agent_maker_volume":    _sum_books(self.maker_volume_sums),
            "agent_roundtrip_volume":_sum_books(self.roundtrip_volume_sums),
            "agent_pnl":             {uid: float(pnl) for uid, pnl in self.total_realized_pnl.items()},
            "agent_open_orders":     agent_open_orders,
            "agent_orders_detail":   agent_orders_detail,
            # chain-level data forwarded from exchange engine's last chain state
            "block_events":   data.get('block_events', []),
            "delegates":      data.get('delegates', {}),
            # metagraph for identity + validator panel
            "metagraph":      self.metagraph_data,
            "validator_uid":  self.uid,
            # simulation only: fundamental prices
            "fundamental_price": self.fundamental_price,
        }, url=_ingest_url))

        if not is_observe:
            await report(self)

        # A payload has now been fully processed (gauges populated for the
        # non-observe path; observe mode legitimately keeps empty registries).
        # Release the exposition warm-up guard so /metrics stops returning 503.
        # Only ever flips false->true; never withheld again once running.
        self._first_publish_done = True

    def pagerduty_alert(self, message, details=None):
        """
        Log a critical alert message (stub — the reporting service has no PagerDuty hook).

        Args:
            message (str): Human-readable alert description.
            details (dict, optional): Additional context to log alongside the message.
        """
        bt.logging.error(f"ALERT: {message}")
        if details:
            bt.logging.error(f"Details: {details}")
    
    def cleanup(self):
        """
        Release all IPC and thread-pool resources held by the reporting service.
        """
        self.request_queue.close()
        self.response_queue.close()
        self.request_mem.close()
        self.request_shm.close_fd()
        self.thread_pool.shutdown(wait=True)
        self.report_executor.shutdown(wait=True)

def simulation_config_rows(simulation):
    """One row per asset class: book range, realizations and the class's market configuration fields, as strings.
    A single market is one row named "market"; the exchange mechanism one row named "exchange"."""
    try:
        classes = simulation.asset_classes()
    except Exception:
        classes = []
    rows = {}
    for cls in classes or []:
        books = sorted(int(b) for b in (getattr(cls, 'books', None) or []))
        cfg = getattr(cls, 'config', None)
        dump = cfg.model_dump() if hasattr(cfg, 'model_dump') else {}
        row = {'books': (f"{books[0]}-{books[-1]}" if books else ""), 'n_books': str(len(books))}
        row |= {f"simulation_{k}": str(v) for k, v in dump.items() if k not in ('logDir', 'fee_policy')}
        # the class's own fee policy, in the labels the Fee Policy table reads (simulation_fee_policy_*), so the
        # table shows one row per class like the Simulation Config table
        fee = getattr(cfg, 'fee_policy', None)
        if hasattr(fee, 'to_prom_info'):
            row |= fee.to_prom_info()
        row['_book_ids'] = books
        rows[str(getattr(cls, 'name', 'market'))] = row
    return rows


def class_names(simulation) -> dict:
    """``{class index: class name}`` in the configuration's order, the names book_asset_class and
    simulation_config_info carry; empty when the configuration names no class."""
    try:
        return {i: str(getattr(cls, 'name', i)) for i, cls in enumerate(simulation.asset_classes() or [])}
    except Exception:
        return {}


# per-class per-uid detail key -> agent_class_gauge_name (the miner gauge's name without its debeta_ prefix)
CLASS_DETAIL_GAUGES = (
    ('making_raw', 'making'), ('making_rank', 'making_rank'), ('skill_raw', 'skill'), ('skill_rank', 'skill_rank'),
    ('p11_factor', 'p11_factor'), ('making_s3_factor', 's3_factor'), ('bg_share', 'bg_share'),
    ('skill_coverage_factor', 'coverage_factor'), ('skill_net_alpha', 'net_alpha'), ('skill_books', 'skill_books'),
    ('coverage_books', 'coverage_books'), ('present', 'present'), ('notional', 'notional'),
)


def publish_class_gauges(self, updates, wallet_addr, netuid, simid):
    """class_gauges, one series per class and summary field, labelled by the class's name."""
    names = class_names(getattr(self, 'simulation', None))
    for _cls, _summary in (getattr(self, 'debeta_class_summary', None) or {}).items():
        label = names.get(int(_cls), str(_cls)) if str(_cls).lstrip('-').isdigit() else str(_cls)
        for _name, _value in _summary.items():
            updates.append((self.prometheus_class_gauges, float(_value), wallet_addr, netuid, simid, label, _name))


def publish_agent_class_gauges(self, updates, wallet_addr, netuid, simid):
    """agent_class_gauges: the per-class per-uid de-beta detail the class pools were built from (making, ranks,
    factors, books, notional, presence within the class), labelled by the class's name. A None is absent."""
    names = class_names(getattr(self, 'simulation', None))
    coll = getattr(self, 'prometheus_agent_class_gauges', None)
    if coll is None:
        return
    for _cls, _by_uid in (getattr(self, 'debeta_class_details', None) or {}).items():
        label = names.get(int(_cls), str(_cls)) if str(_cls).lstrip('-').isdigit() else str(_cls)
        for _uid, _dd in (_by_uid or {}).items():
            for _key, _gauge in CLASS_DETAIL_GAUGES:
                _v = _dd.get(_key)
                if _v is None:
                    continue
                updates.append((coll, float(_v), wallet_addr, netuid, simid, label, int(_uid), _gauge))


def publish_capture_floor_gauges(self, updates, wallet_addr, netuid, simid):
    """book_gauges capture_floor and capture_dust_share: the dust floor's level per book and the share of the live
    capture window's prints it excludes."""
    coll = getattr(self, 'prometheus_book_gauges', None)
    for _book, _st in (getattr(self, 'capture_floor_stats', None) or {}).items():
        for _key, _gauge in (("floor", "capture_floor"), ("dust_share", "capture_dust_share")):
            _v = (_st or {}).get(_key)
            if _v is not None:
                updates.append((coll, float(_v), wallet_addr, netuid, simid, int(_book), 0, _gauge))



def publish_capture_settle_gauges(self, updates, wallet_addr, netuid, simid):
    """class_gauges capture_full, capture_cut and capture_cut_share: per asset class, the capture fills settled with a
    complete forward side, those settled cut, and the cut share."""
    names = class_names(getattr(self, 'simulation', None))
    for _cls, _row in (getattr(self, 'capture_settle_by_class', None) or {}).items():
        label = names.get(int(_cls), str(_cls))
        for _key, _gauge in (("full", "capture_full"), ("cut", "capture_cut"), ("cut_share", "capture_cut_share")):
            updates.append((self.prometheus_class_gauges, float(_row.get(_key, 0.0)), wallet_addr, netuid, simid,
                            label, _gauge))


def neuron_info_labels(self) -> dict:
    """The labels of the neuron_info series: the validator's identity, every scoring dial it runs
    (config_scoring_*) and the fee policy (simulation_fee_policy_*), which the dashboards' Scoring Config and
    Fee Policy tables read. The market parameters are NOT here: since 0.6.3 simulation_config_info publishes them
    per asset class, and carrying a copy of all of them put this series at 150 labels, which the metrics store
    behind the dashboards refused on 6 October 2026 (VictoriaMetrics ignores a series over its per-series label
    cap); the two tables went dark while the 100-label per-class series was ingested. Held under 100 by
    tests/test_the_neuron_info_series_stays_under_the_store_label_cap.py."""
    hotkey = self.wallet.hotkey.ss58_address
    labels = {
        'uid': str(self.metagraph.hotkeys.index(hotkey)) if hotkey in self.metagraph.hotkeys else -1,
        'network': self.config.subtensor.network,
        'coldkey': str(self.wallet.coldkeypub.ss58_address),
        'coldkey_name': self.config.wallet.name,
        'hotkey': str(hotkey),
        'name': self.config.wallet.hotkey,
    }
    labels |= {f"config_scoring_{name}": str(value) for name, value in self.validator_config['scoring'].items()}
    fee_policy = getattr(self.simulation, 'fee_policy', None)
    if fee_policy:
        labels |= fee_policy.to_prom_info()
    return labels


def publish_simulation_config_info(self):
    """Publish simulation_config_info, one series per asset class (see simulation_config_rows)."""
    info = getattr(self, 'prometheus_simconfig_info', None)
    if info is None:
        return
    info.clear()
    book_class = getattr(self, 'prometheus_book_class', None)
    if book_class is not None:
        book_class.clear()
    for name, row in simulation_config_rows(self.simulation).items():
        books = row.pop('_book_ids', [])
        info.labels(wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid,
                    sim_id=self.simulation.simulation_id, asset_class=name).info(row)
        if book_class is not None:
            for b in books:
                book_class.labels(wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid,
                                  sim_id=self.simulation.simulation_id, book_id=str(b), asset_class=name).set(1)


def round_quantile(values, q):
    """The inclusive quantile, as the metrics store's quantile() computes it, so a live read and a baseline drawn from
    the store agree; None of nothing."""
    v = sorted(values)
    if not v:
        return None
    if len(v) == 1:
        return v[0]
    rank = q * (len(v) - 1)
    lo = int(rank)
    hi = min(lo + 1, len(v) - 1)
    return v[lo] + (rank - lo) * (v[hi] - v[lo])


def round_block_gauges(ms) -> list:
    """A uid's published block of rounds as (gauge, value): the request counts, the mean response time of the answered
    rounds with the block's 5th percentile (the uid's floor) and median, which the round lines read, and the engine's
    view of the uid's instructions: placements and cancels sent, placed and refused, cancels honoured and failed, fills,
    and instructions dropped under the caps."""
    times = ms.get('call_time') or []
    return [
        ("requests", ms['requests']),
        ("success", ms['requests'] - ms['failures'] - ms['timeouts'] - ms['rejections']),
        ("failures", ms['failures']),
        ("timeouts", ms['timeouts']),
        ("rejections", ms['rejections']),
        ("call_time", (sum(times) / len(times)) if times else 0),
        ("call_time_p5", round_quantile(times, 0.05) if times else 0),
        ("call_time_median", round_quantile(times, 0.5) if times else 0),
        ("placed", ms.get('placed', 0)),
        ("refused", ms.get('refused', 0)),
        ("refused_contract", ms.get('refused_contract', 0)),
        ("placements_sent", ms.get('placements_sent', 0)),
        ("cancels_sent", ms.get('cancels_sent', 0)),
        ("cancels_ok", ms.get('cancels_ok', 0)),
        ("cancels_failed", ms.get('cancels_failed', 0)),
        ("fills", ms.get('fills', 0)),
        ("dropped", ms.get('dropped', 0)),
    ]


def round_timing_gauges(self) -> list:
    """The validator's round timing over its last published rounds, as (gauge, value): the round period's 5th
    percentile, median and 95th percentile (wall seconds between consecutive states), the query wait's median and 95th
    percentile (dispatch to the last answer or the global timeout), the longest wait for the reward lock and the reward
    tasks pending. The lists travel in the report payload; an older payload publishes only the pending count."""
    out = []
    gaps = list(getattr(self, 'round_gaps', None) or [])
    if gaps:
        out += [("round_period_p5", round_quantile(gaps, 0.05)), ("round_period_median", round_quantile(gaps, 0.5)),
                ("round_period_p95", round_quantile(gaps, 0.95))]
    waits = list(getattr(self, 'query_waits', None) or [])
    if waits:
        out += [("query_wait_median", round_quantile(waits, 0.5)), ("query_wait_p95", round_quantile(waits, 0.95))]
    gate = list(getattr(self, 'reward_gate_waits', None) or [])
    if gate:
        out.append(("reward_gate_wait_max", max(gate)))
    out.append(("reward_tasks_pending", int(getattr(self, 'pending_reward_tasks', 0) or 0)))
    return out


def publish_validator_gauges(self: ReportingService):
    """
    Publishes validator-specific metrics to Prometheus gauges.
    
    Metrics include validator metagraph information (UID, stake, trust, dividends, emission, 
    last update, active status) and system resource usage (CPU, RAM, disk).
    
    Args:
        self (ReportingService): The intelligent markets simulation validator instance
        
    Returns:
        None
    """
    bt.logging.debug("Publishing validator metrics...")
    start = time.time()
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="uid").set( self.uid )
    # instructions the engine could not encode for the simulator and dropped from a step's message (see SimulationEngine.respond)
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="response_pack_drops").set( float(getattr(getattr(self, 'engine', None), 'response_pack_drops', 0) or 0) )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="stake").set( self.metagraph.stake[self.uid] )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="validator_trust").set( self.metagraph.validator_trust[self.uid] )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="dividends").set( self.metagraph.dividends[self.uid] )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="emission").set( self.metagraph.emission[self.uid] )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="last_update").set( self.current_block - self.metagraph.last_update[self.uid] )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="active").set( self.metagraph.active[self.uid] )
    for _name, _value in round_timing_gauges(self):
        self.prometheus_validator_gauges.labels(wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name=_name).set(float(_value))
    cpu_usage = psutil.cpu_percent()
    memory_info = psutil.virtual_memory()
    memory_usage = memory_info.percent
    disk_info = psutil.disk_usage('/')
    disk_usage = disk_info.percent
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="cpu_usage_percent").set( cpu_usage )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="ram_usage_percent").set( memory_usage )
    self.prometheus_validator_gauges.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id, validator_gauge_name="disk_usage_percent").set( disk_usage )    
    _shadow_health = getattr(self, 'scoring_shadow_health', None)
    if _shadow_health:
        # Scoring-service health. A parity re-INIT storm (testnet: one every two minutes)
        # truncates the de-beta window the child scores on and stalls main for every snapshot; these
        # make it a dashboard fact instead of a log grep.
        for _gauge, _key in (
            ("scoring_shadow_parity_matches", "parity_matches"),
            ("scoring_shadow_parity_mismatches", "parity_mismatches"),
            ("scoring_shadow_reinits", "reinits"),
            ("scoring_shadow_tee_dropped", "tee_dropped"),
            ("scoring_shadow_suspended", "cutover_suspended"),
            ("scoring_shadow_initialized", "initialized"),
        ):
            self.prometheus_validator_gauges.labels(
                wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid,
                sim_id=self.simulation.simulation_id, validator_gauge_name=_gauge,
            ).set(float(_shadow_health.get(_key, 0) or 0))
    _clock = getattr(self, 'history_clock', None)
    if _clock:
        # A run change the validator did not apply leaves the previous run's last window stamped ahead of the
        # clock, inside every window and never pruned; the first gauge is that distance (0 when clean), the
        # other two count the repairs (the load-time rebase and the first-update recovery).
        for _gauge in ("history_stamp_ahead_ns", "run_changes_recovered", "histories_rebased_at_load"):
            self.prometheus_validator_gauges.labels(
                wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid,
                sim_id=self.simulation.simulation_id, validator_gauge_name=_gauge,
            ).set(float(_clock.get(_gauge, 0) or 0))
    _settlement = getattr(self, 'exchange_settlement', None)
    if _settlement:
        # Exchange settlement counters, one gauge each as settlement_<name>.
        for _key, _value in _settlement.items():
            self.prometheus_validator_gauges.labels(
                wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid,
                sim_id=self.simulation.simulation_id, validator_gauge_name=f"settlement_{_key}",
            ).set(float(_value or 0))
    bt.logging.debug(f"Validator metrics published ({time.time()-start:.4f}s).")

def publish_gentrx_gauges(self: ReportingService) -> None:
    """
    Publish GenTRX distributed-training metrics to the gentrx Prometheus registry.

    Exposes pool-level gauges (enabled flag, simulation share, active miner count),
    per-miner EMA-smoothed scores, and training statistics (loss, acceptance rate,
    checkpoint version, round count, rollback count, and timing).

    Args:
        self (ReportingService): The reporting service instance holding Prometheus
            gauge objects and the current gentrx_scores / gentrx_training state.
    """
    wallet_addr = self.wallet.hotkey.ss58_address
    netuid = self.config.netuid
    simid = self.simulation.simulation_id

    gentrx_scores = getattr(self, 'gentrx_scores', {}) or {}
    gentrx_enabled = getattr(self, 'gentrx_enabled', False)
    gentrx_share = self.validator_config.get('scoring', {}).get('gentrx_simulation_share', 0.0)
    active_miners = sum(1 for s in gentrx_scores.values() if s > 0)

    g = self.prometheus_gentrx_gauges
    g.labels(wallet=wallet_addr, netuid=netuid, sim_id=simid, gentrx_gauge_name="enabled").set(1 if gentrx_enabled else 0)
    g.labels(wallet=wallet_addr, netuid=netuid, sim_id=simid, gentrx_gauge_name="simulation_share").set(gentrx_share)
    g.labels(wallet=wallet_addr, netuid=netuid, sim_id=simid, gentrx_gauge_name="active_miners").set(active_miners)

    cfg = getattr(self, 'gentrx_config', {}) or {}
    for key in ('min_score', 'overfit_ratio', 'books_per_miner', 'val_fraction'):
        v = cfg.get(key)
        if v is not None:
            g.labels(wallet=wallet_addr, netuid=netuid, sim_id=simid, gentrx_gauge_name=key).set(float(v))
    ema_alpha = self.validator_config.get('scoring', {}).get('gentrx_ema_alpha')
    if ema_alpha is not None:
        g.labels(wallet=wallet_addr, netuid=netuid, sim_id=simid, gentrx_gauge_name="ema_alpha").set(float(ema_alpha))

    ms = self.prometheus_gentrx_miner_scores
    for uid_str, score in gentrx_scores.items():
        ms.labels(wallet=wallet_addr, netuid=netuid, sim_id=simid, uid=str(uid_str)).set(float(score))

    detailed = getattr(self, 'gentrx_scores_detailed', {}) or {}
    for uid_key, entry in detailed.items():
        if not isinstance(entry, dict):
            continue
        uid = str(uid_key)
        lv = dict(wallet=wallet_addr, netuid=netuid, sim_id=simid, uid=uid)
        s_own = entry.get('score_own')
        s_held = entry.get('score_held')
        if s_own is not None:
            self.prometheus_gentrx_miner_score_own.labels(**lv).set(float(s_own))
        if s_held is not None:
            self.prometheus_gentrx_miner_score_held.labels(**lv).set(float(s_held))
        self.prometheus_gentrx_miner_score.labels(**lv).set(float(entry.get('score', 0.0)))
        self.prometheus_gentrx_miner_accepted.labels(**lv).set(1.0 if entry.get('accepted') else 0.0)
        self.prometheus_gentrx_miner_overfitting.labels(**lv).set(1.0 if entry.get('overfitting') else 0.0)
        self.prometheus_gentrx_miner_rollback_winner.labels(**lv).set(1.0 if entry.get('was_rollback_winner') else 0.0)
        gn = entry.get('grad_norm')
        if gn is not None:
            self.prometheus_gentrx_miner_grad_norm.labels(**lv).set(float(gn))

    # Training stats from last aggregation round
    tr = getattr(self, 'gentrx_training', {}) or {}
    if tr:
        t = self.prometheus_gentrx_training
        lv = dict(wallet=wallet_addr, netuid=netuid, sim_id=simid)
        for stat, val in (
            ("loss_before",           tr.get("loss_before")),
            ("loss_after",            tr.get("loss_after")),
            ("loss_delta",            (tr["loss_before"] - tr["loss_after"])
                                      if tr.get("loss_before") is not None and tr.get("loss_after") is not None
                                      else None),
            ("loss_improvement_pct",  tr.get("loss_improvement_pct")),
            ("n_assigned",            tr.get("n_assigned")),
            ("n_delivered",           tr.get("n_delivered")),
            ("n_collected",           tr.get("n_collected")),
            ("n_version_mismatched",  tr.get("n_version_mismatched")),
            ("n_scored",              tr.get("n_scored")),
            ("n_accepted",            tr.get("n_accepted")),
            ("acceptance_rate",       (tr["n_accepted"] / tr["n_scored"])
                                      if tr.get("n_scored") else None),
            ("version",               tr.get("version")),
            ("agg_round",             tr.get("round")),
            ("rolled_back",           1 if tr.get("rolled_back") else 0),
            ("rollback_rate_10w",     tr.get("rollback_rate_10w")),
            ("rollback_rate_50w",     tr.get("rollback_rate_50w")),
            ("rounds_aggregated_total", tr.get("rounds_aggregated_total")),
            ("rollbacks_total",       tr.get("rollbacks_total")),
            ("t_score_s",             tr.get("t_score_s")),
            ("t_aggregate_s",         tr.get("t_aggregate_s")),
            ("t_total_s",             tr.get("t_total_s")),
            ("t_proposal_eval_s",     tr.get("t_proposal_eval_s")),
            ("t_save_ckpt_s",         tr.get("t_save_ckpt_s")),
            ("t_loader_build_s",      tr.get("t_loader_build_s")),
            ("grad_norm_mean",        tr.get("grad_norm_mean")),
            ("grad_norm_min",         tr.get("grad_norm_min")),
            ("grad_norm_max",         tr.get("grad_norm_max")),
            ("grad_norm_median",      tr.get("grad_norm_median")),
            ("grad_norm_std",         tr.get("grad_norm_std")),
            ("overlap_pairs_checked", tr.get("overlap_pairs_checked")),
            ("overlap_pairs_high",    tr.get("overlap_pairs_high")),
            ("overlap_mean",          tr.get("overlap_mean")),
            ("overlap_max",           tr.get("overlap_max")),
            ("loader_cache_hits",     tr.get("loader_cache_hits")),
            ("loader_cache_misses",   tr.get("loader_cache_misses")),
            ("loader_cache_hit_rate", tr.get("loader_cache_hit_rate")),
            ("proposals_evaluated",   tr.get("proposals_evaluated")),
            ("proposals_skipped",     tr.get("proposals_skipped")),
            *(
                (f"per_field_loss_before_{f}", tr.get(f"per_field_loss_before_{f}"))
                for f in ("order_type", "price", "vol_int", "vol_dec", "interval")
            ),
            *(
                (f"per_field_loss_after_{f}", tr.get(f"per_field_loss_after_{f}"))
                for f in ("order_type", "price", "vol_int", "vol_dec", "interval")
            ),
        ):
            if val is not None:
                t.labels(**lv, stat=stat).set(float(val))


def publish_info(self: ReportingService) -> None:
    """
    Publishes static simulation and validator information metrics

    Args:
        self (ReportingService): The intelligent markets simulation validator.
    Returns:
        None
    """
    self.prometheus_info.labels( wallet=self.wallet.hotkey.ss58_address, netuid=self.config.netuid, sim_id=self.simulation.simulation_id ).info (neuron_info_labels(self))
    publish_simulation_config_info(self)
    publish_validator_gauges(self)
    publish_gentrx_gauges(self)

class _SnapshotCollector:
    """Snapshot-backed collector replacing an eager high-cardinality Gauge.

    Removes the ~1.8M-per-cycle gauge.labels()+locked .set() apply loop (the
    reporting-timeout root cause): the per-cycle cost becomes plain dict ops, and
    serialisation happens lock-free on /metrics scrape via collect().

    Semantics are byte-for-byte identical to the eager Gauge, including
    persistence: a series **carries forward at its last value** until it is
    explicitly evicted (evict(), mirroring gauge.remove()) or cleared (clear(),
    mirroring gauge.clear()). It does NOT drop a series merely because the series
    was not re-emitted this cycle — matching the eager Gauge, where a child set
    once survives until removed. Each cycle, update() merges this cycle's emitted
    values over the retained snapshot and applies pending evictions.
    """

    def __init__(self, name, documentation, labelnames, carry_forward=True):
        self._name = name
        self._documentation = documentation
        self._labelnames = list(labelnames)
        self._snapshot = {}
        self._pending_evict = set()
        # rows staged by set(**labels) during the cycle (the miners and miner_identity families are
        # written that way, one row per uid); folded into the cycle's snapshot by the apply router
        self._pending = {}
        # carry_forward=True (agent_gauges): a series persists at its last value
        # until explicitly evicted, mirroring an eager Gauge that keeps a child
        # once set. carry_forward=False (the former clear-and-rebuild families
        # trades / books / miner_trades): each cycle FULLY replaces the snapshot,
        # mirroring gauge.clear() + rebuild — the new snapshot is the exposition.
        self._carry_forward = carry_forward

    def evict(self, labels):
        # Mark a series for removal at the next update() — mirrors gauge.remove().
        """Drop the series for one label set.

        Args:
            labels: The label values identifying the series.
        """
        self._pending_evict.add(labels)

    def update(self, cycle_values):
        # copy-then-swap keeps collect() (running on the scrape thread) lock-free
        # and torn-read-safe: collect() only ever sees a fully-built snapshot.
        """Replace the collector's gauges with this cycle's values.

        Args:
            cycle_values: Mapping of label sets to gauge values.
        """
        if not self._carry_forward:
            # Replace: the family is re-emitted in full every cycle, so this
            # cycle's values ARE the complete exposition — no merge/carry-forward
            # (which would leak stale rolling-buffer slots from prior cycles).
            self._snapshot = cycle_values
            self._pending_evict = set()
            return
        merged = dict(self._snapshot)
        merged.update(cycle_values)
        if self._pending_evict:
            for key in self._pending_evict:
                merged.pop(key, None)
            self._pending_evict = set()
        self._snapshot = merged

    def clear(self):
        """Drop every stored series."""
        self._snapshot = {}
        self._pending_evict = set()
        self._pending = {}

    def set(self, value, **labels):
        """Stage one series for this cycle by keyword labels (the Gauge.labels(**labels).set(value)
        shape); it reaches the exposition when the cycle's snapshot is swapped in."""
        self._pending[tuple(labels.get(name) for name in self._labelnames)] = value

    def take_pending(self):
        """The rows staged by set() since the last take, cleared."""
        pending, self._pending = self._pending, {}
        return pending

    def collect(self):
        # add_metric stores values unchecked and prometheus_client calls float() at serialisation
        # time, so a single bad sample would 500 the entire /metrics endpoint, not just this family.
        # Skip (and count) unusable samples so every other series stays exposed.
        """Yield the stored series to the Prometheus client."""
        snapshot = self._snapshot
        family = GaugeMetricFamily(self._name, self._documentation, labels=self._labelnames)
        add_metric = family.add_metric
        _dropped = 0
        for labels, value in snapshot.items():
            if value is None:
                _dropped += 1
                continue
            try:
                value = float(value)
            except (TypeError, ValueError):
                _dropped += 1
                continue
            add_metric([str(label) for label in labels], value)
        if _dropped:
            # bt.logging, not the stdlib logger: this module has no logger and a stdlib one would not
            # reach pm2's captured output, so the warning would exist and be invisible.
            bt.logging.warning(
                f"{self._name}: {_dropped} unusable sample(s) skipped during collection (value was None "
                f"or non-numeric); the remaining series are exposed normally"
            )
        yield family


def _set_if_changed(gauge, value, *labels):
    """
    Sets a Prometheus gauge value only if it differs from the current value.
    
    Args:
        gauge: Prometheus gauge object to update
        value: New value to set on the gauge
        *labels: Variable number of positional label values for the gauge
        
    Returns:
        None
    """
    # gauge.labels() is the dominant cost of the apply loop (acquires the
    # collector lock, normalizes the label tuple, dict-lookup/create the child)
    # and runs ~1.8M times per reporting cycle. Resolve the child ONCE and reuse
    # it for both the read and the write: the previous form called labels()
    # twice on every changed series, roughly doubling the per-update cost.
    # labels() creates the child if absent, so the old KeyError branch is moot.
    child = gauge.labels(*labels)
    if child._value.get() != value:
        child.set(value)

def _set_cached(cache, gauge, value, labels):
    """Set a gauge value via a persistent child-handle / last-value cache.

    For the persistent gauge families this is the hot path. On a cache hit the
    only work is a dict lookup and a float comparison; gauge.labels() (lock +
    label-tuple normalization + dict lookup) and a locked _value.get() are paid
    only on first sight of a series. Unchanged values short-circuit with no
    Prometheus interaction at all.

    Args:
        cache: dict keyed by (id(gauge), labels) -> [child, last_value].
        gauge: Prometheus gauge object.
        value: New value to set.
        labels: Tuple of positional label values.
    """
    ck = (id(gauge), labels)
    entry = cache.get(ck)
    if entry is None:
        child = gauge.labels(*labels)
        child.set(value)
        cache[ck] = [child, value]
        return
    if entry[1] != value:
        entry[0].set(value)
        entry[1] = value

def _remove_and_evict(cache, gauge, *labels):
    """Remove a gauge series and evict any cached handle for it.

    Eviction is required so that if the series reappears with the same value it
    was last set to, _set_cached re-creates it rather than short-circuiting on a
    stale last-value entry and leaving the series absent from the registry.

    For a _SnapshotCollector the carry-forward snapshot persists series across
    cycles, so eviction must be explicit (mirrors gauge.remove()).
    """
    if isinstance(gauge, _SnapshotCollector):
        gauge.evict(labels)
        return
    try:
        gauge.remove(*labels)
    except KeyError:
        pass
    cache.pop((id(gauge), labels), None)

def _set_if_changed_metric(gauge, value, **labels):
    """
    Sets a Prometheus gauge value only if it differs from the current value using keyword labels.
    
    Args:
        gauge: Prometheus gauge object to update
        value: New value to set on the gauge
        **labels: Variable number of keyword label-value pairs for the gauge
        
    Returns:
        None
    """
    # duck-typed rather than isinstance: a test that reloads this module holds another class object
    if hasattr(gauge, 'take_pending'):
        gauge.set(value, **labels)
        return
    # Single labels() lookup reused for read + write (see _set_if_changed).
    child = gauge.labels(**labels)
    if child._value.get() != value:
        child.set(value)

def exchange_inventory(inv_history: Dict, quote_by_ts: Dict, initial_quote: Dict):
    """(totals, per_book) of one uid on the exchange, where one quote balance is shared by every book.

    Each book's inventory value is its wealth less its wealth when its account first appeared, and both include the
    shared quote, so every book carries the quote's whole change since its own first appearance. A book's own change is
    its inventory value less that quote change; the account's total is the books' own changes plus the quote's change
    since the first entry, counted once, and `per_book` gives each book an equal share of that quote change so the
    books sum to the total. `totals` follows the history's order. A timestamp whose quote was not recorded (the first
    update after a restart) keeps its plain sum.
    """
    tss = list(inv_history)
    totals, per_book = [], {}
    if not tss:
        return totals, per_book
    q_ref = quote_by_ts.get(tss[0])
    if q_ref is None:
        q_ref = next((initial_quote[b] for b in inv_history[tss[0]] if initial_quote.get(b) is not None), None)
    for ts in tss:
        row, q = inv_history[ts], quote_by_ts.get(ts)
        if q is None or q_ref is None or not row:
            totals.append(sum(row.values()))
            per_book[ts] = dict(row)
            continue
        own = {b: v - (q - (initial_quote[b] if initial_quote.get(b) is not None else q)) for b, v in row.items()}
        share = (q - q_ref) / len(own)
        per_book[ts] = {b: v + share for b, v in own.items()}
        totals.append(sum(own.values()) + (q - q_ref))
    return totals, per_book


def account_quote_totals(accounts_data: Dict, books, is_exchange: bool):
    """(quote balance, quote loan, quote collateral) of one account: summed over books in simulation, where every book
    has its own quote, and read once on the exchange, where every book shows the one shared balance."""
    present = [b for b in books if b in accounts_data]
    if is_exchange:
        a = accounts_data[present[0]] if present else {"qb": {"t": 0.0}, "ql": 0.0, "qc": 0.0}
        return a['qb']['t'], a['ql'], a['qc']
    return (sum(accounts_data[b]['qb']['t'] for b in present), sum(accounts_data[b]['ql'] for b in present),
            sum(accounts_data[b]['qc'] for b in present))


def report_book_ids(validator_data: Dict):
    """The books a report iterates: the run's id set when the caller supplies it, else the dense range.
    A dense range on a sparse layout skips real books and visits phantom ones."""
    ids = validator_data.get('book_ids')
    return list(ids) if ids is not None else range(int(validator_data['book_count']))


def report_worker(validator_data: Dict, state_data: Dict) -> Dict:
    """
    Compute per-miner and per-book metrics from a snapshot of validator state.

    Runs in a thread-pool executor to avoid blocking the reporting event loop.

    Args:
        validator_data (Dict): Snapshot of validator state including volume sums,
            inventory history, realized P&L, activity/pnl factors, kappa values,
            scores, and simulation config.
        state_data (Dict): Current simulator state containing accounts, books,
            and notices.

    Returns:
        Dict: Result dict with keys 'metrics' (computed miner/book data),
            'updated_stats' (unused), and 'error' (str or None on failure).
    """
    result = {
        'metrics': {},
        'updated_stats': {},
        'error': None
    }
    try:
        validator_data['simulation_timestamp']
        validator_data['step']
        accounts = state_data['accounts']
        books = state_data['books']
        if not accounts:
            return result
        
        total_realized_pnl = validator_data['total_realized_pnl']
        realized_pnl_by_book = validator_data['realized_pnl_by_book']
        fee_sums_by_book = validator_data.get('fee_sums', {})

        volume_sums = validator_data['volume_sums']
        maker_volume_sums = validator_data['maker_volume_sums']
        taker_volume_sums = validator_data['taker_volume_sums']
        self_volume_sums = validator_data['self_volume_sums']
        roundtrip_volume_sums = validator_data['roundtrip_volume_sums']
        volume_decimals = validator_data['simulation_config']['volumeDecimals']

        daily_volumes = {}
        for agentId in accounts.keys():
            daily_volumes[agentId] = {}
            for bookId in report_book_ids(validator_data):
                total_vol = volume_sums.get(agentId, {}).get(bookId, 0.0)
                total_maker_vol = maker_volume_sums.get(agentId, {}).get(bookId, 0.0)
                total_taker_vol = taker_volume_sums.get(agentId, {}).get(bookId, 0.0)
                total_self_vol = self_volume_sums.get(agentId, {}).get(bookId, 0.0)
                daily_volumes[agentId][bookId] = {
                    'total': total_vol,
                    'maker': total_maker_vol,
                    'taker': total_taker_vol,
                    'self': total_self_vol,
                }

        daily_roundtrip_volumes = {}
        for agentId in accounts.keys():
            daily_roundtrip_volumes[agentId] = {}
            for bookId in report_book_ids(validator_data):
                roundtrip_vol = roundtrip_volume_sums.get(agentId, {}).get(bookId, 0.0)
                daily_roundtrip_volumes[agentId][bookId] = roundtrip_vol
        
        inventory_history = validator_data['inventory_history']
        total_inventory_history = {}
        pnl = {}

        for agentId in accounts.keys():
            if agentId < 0:
                continue
            if agentId not in inventory_history or not inventory_history[agentId]:
                continue
            if len(inventory_history[agentId]) < 2:
                continue
            
            if validator_data.get('is_exchange'):
                total_inventory_history[agentId], _ = exchange_inventory(
                    inventory_history[agentId], (validator_data.get('inventory_quote') or {}).get(agentId) or {},
                    (validator_data.get('initial_quote') or {}).get(agentId) or {})
            else:
                total_inventory_history[agentId] = [
                    sum(list(inventory_value.values()))
                    for inventory_value in list(inventory_history[agentId].values())
                ]
            pnl[agentId] = total_inventory_history[agentId][-1] - total_inventory_history[agentId][0]

        scores = torch.FloatTensor(list(validator_data['scores'].values()))
        indices = scores.argsort(dim=-1, descending=True)
        placements = torch.empty_like(indices).scatter_(
            -1, indices, torch.arange(scores.size(-1), device=scores.device)
        )

        miner_metrics = {}
        for agentId, accounts_data in accounts.items():
            if agentId < 0:
                continue
            if agentId not in total_inventory_history:
                continue

            base_decimals = validator_data['simulation_config']['baseDecimals']
            quote_decimals = validator_data['simulation_config']['quoteDecimals']

            total_base_balance = round(
                sum([accounts_data[bookId]['bb']['t'] for bookId in books]),
                base_decimals
            )
            total_base_loan = round(
                sum([accounts_data[bookId]['bl'] for bookId in books]),
                base_decimals
            )
            total_base_collateral = round(
                sum([accounts_data[bookId]['bc'] for bookId in books]),
                base_decimals
            )
            _qt, _ql, _qc = account_quote_totals(accounts_data, books, bool(validator_data.get('is_exchange')))
            total_quote_balance = round(_qt, quote_decimals)
            total_quote_loan = round(_ql, quote_decimals)
            total_quote_collateral = round(_qc, quote_decimals)

            total_daily_volume = {
                role: round(
                    sum([book_volume[role] for book_volume in daily_volumes[agentId].values()]),
                    volume_decimals
                )
                for role in ['total', 'maker', 'taker', 'self']
            }

            average_daily_volume = {
                role: round(
                    total_daily_volume[role] / len(daily_volumes[agentId]),
                    volume_decimals
                )
                for role in ['total', 'maker', 'taker', 'self']
            }

            min_daily_volume = {
                role: min([book_volume[role] for book_volume in daily_volumes[agentId].values()])
                for role in ['total', 'maker', 'taker', 'self']
            }

            total_roundtrip_volume = round(
                sum(daily_roundtrip_volumes[agentId].values()),
                volume_decimals
            )
            average_roundtrip_volume = round(
                total_roundtrip_volume / len(daily_roundtrip_volumes[agentId]),
                volume_decimals
            )
            min_roundtrip_volume = min(daily_roundtrip_volumes[agentId].values()) if daily_roundtrip_volumes[agentId] else 0.0

            activity_factor = (
                sum(validator_data['activity_factors'][agentId].values()) /
                len(validator_data['activity_factors'][agentId])
            ) if validator_data['activity_factors'][agentId] else 0.0
            pnl_factor = (
                sum(validator_data['pnl_factors'][agentId].values()) /
                len(validator_data['pnl_factors'][agentId])
            ) if validator_data['pnl_factors'][agentId] else 0.0
            kappa_values = validator_data['kappa_values'][agentId] if agentId in validator_data['kappa_values'] else None
            # EMA'd trading standing (0.5.5): reported as kappa_score/combined_score so the
            # dashboard shows the smoothed standing that drives reward, not the raw per-window
            # value. Falls back to the raw kappa_values when the EMA is off or not yet seeded.
            _ema_std = (validator_data.get('trading_score_ema') or {}).get(agentId)

            miner_metrics[agentId] = {
                'total_base_balance': total_base_balance,
                'total_base_loan': total_base_loan,
                'total_base_collateral': total_base_collateral,
                'total_quote_balance': total_quote_balance,
                'total_quote_loan': total_quote_loan,
                'total_quote_collateral': total_quote_collateral,
                'total_inventory_value': total_inventory_history[agentId][-1],
                'inventory_value_change': (
                    total_inventory_history[agentId][-1] - total_inventory_history[agentId][-2]
                    if len(total_inventory_history[agentId]) > 1 else 0.0
                ),
                'pnl': pnl[agentId],
                'pnl_change': (
                    pnl[agentId] - (total_inventory_history[agentId][-2] - total_inventory_history[agentId][0])
                    if len(total_inventory_history[agentId]) > 1 else 0.0
                ),
                'total_realized_pnl': total_realized_pnl.get(agentId, 0.0),
                'total_daily_volume': total_daily_volume,
                'average_daily_volume': average_daily_volume,
                'min_daily_volume': min_daily_volume,
                'total_roundtrip_volume': total_roundtrip_volume,
                'average_roundtrip_volume': average_roundtrip_volume,
                'min_roundtrip_volume': min_roundtrip_volume,
                'activity_factor': activity_factor,
                'pnl_factor': pnl_factor,
                # .get, never []: a stub entry (a uid kappa-3 could not score while the de-beta weight is
                # nonzero) carried no median, and the KeyError killed the whole report worker every cycle.
                # At a nonzero rung the failure is near-silent: validator gauges keep publishing
                # while every miner, book and simulation gauge freezes, and nothing names the
                # report worker as the cause.
                'kappa': kappa_values.get('median') if kappa_values else None,
                'kappa_penalty': kappa_values.get('penalty') if kappa_values else None,
                'activity_weighted_normalized_median': kappa_values.get('activity_weighted_normalized_median') if kappa_values else None,
                'kappa_score': kappa_values.get('score') if kappa_values else None,
                'pnl_score': kappa_values.get('pnl_score') if kappa_values else None,
                'combined_score': _ema_std if _ema_std is not None else (kappa_values.get('final_score') if kappa_values else None),
                'unnormalized_score': validator_data['unnormalized_scores'].get(agentId, 0.0),
                'score': scores[agentId].item() if agentId < len(scores) else 0.0,
                'gentrx_score': float(validator_data.get('gentrx_scores', {}).get(agentId, 0.0)),
                'placement': placements[agentId].item() if agentId < len(placements) else len(scores),
                # DE-BETA decomposition, straight off uid_kappa where reward.py stored it. None on any
                # fallback cycle, which the gauge writer turns into an eviction rather than a stale value.
                'trading_score': kappa_values.get('trading_score') if kappa_values else None,
                'debeta_score': kappa_values.get('debeta_score') if kappa_values else None,
                'making_raw': kappa_values.get('making_raw') if kappa_values else None,
            # published under BOTH making_pool settings: what this uid would be paid from the
            # proportional pool, and what the ladder would rank, so the alternative is visible
            # on the dashboards before the dial is turned
            'making_share': kappa_values.get('making_share') if kappa_values else None,
            'ladder_input': kappa_values.get('ladder_input') if kappa_values else None,
                'making_rank': kappa_values.get('making_rank') if kappa_values else None,
                # both making bases and which one pays (0.6.3): reward.py stores them on uid_kappa with the
                # legs above, and the gauge loop and the miners table read them by these keys
                'making_realized': kappa_values.get('making_realized') if kappa_values else None,
                'making_captured': kappa_values.get('making_captured') if kappa_values else None,
                'making_basis': kappa_values.get('making_basis') if kappa_values else None,
                'skill_raw': kappa_values.get('skill_raw') if kappa_values else None,
                'skill_rank': kappa_values.get('skill_rank') if kappa_values else None,
                'p11_factor': kappa_values.get('p11_factor') if kappa_values else None,
                's3_factor': kappa_values.get('s3_factor') if kappa_values else None,
                'bg_share': kappa_values.get('bg_share') if kappa_values else None,
                'present': kappa_values.get('present') if kappa_values else None,
                'debeta_w_make': kappa_values.get('debeta_w_make') if kappa_values else None,
                'debeta_weight': kappa_values.get('debeta_weight') if kappa_values else None,
                'debeta_floor': kappa_values.get('debeta_floor') if kappa_values else None,
                'skill_other': kappa_values.get('skill_other') if kappa_values else None,
                'skill_weakest3': kappa_values.get('skill_weakest3') if kappa_values else None,
                'skill_books_kept': kappa_values.get('skill_books_kept') if kappa_values else None,
                'skill_mark_alt': kappa_values.get('skill_mark_alt') if kappa_values else None,
                'skill_net_alpha_mark_alt': kappa_values.get('skill_net_alpha_mark_alt') if kappa_values else None,
                'maker_notional_two_sided': kappa_values.get('maker_notional_two_sided') if kappa_values else None,
                'at_best_seconds': kappa_values.get('at_best_seconds') if kappa_values else None,
                'best_size': kappa_values.get('best_size') if kappa_values else None,
                'skill_pool_factor': kappa_values.get('skill_pool_factor') if kappa_values else None,
                'skill_coverage_factor': kappa_values.get('skill_coverage_factor') if kappa_values else None,
                'coverage_books': kappa_values.get('coverage_books') if kappa_values else None,
                'skill_p11_factor': kappa_values.get('skill_p11_factor') if kappa_values else None,
                'skill_net_alpha': kappa_values.get('skill_net_alpha') if kappa_values else None,
                'notional': kappa_values.get('notional') if kappa_values else None,
                'presence_share': kappa_values.get('presence_share') if kappa_values else None,
                'num_scored_books': kappa_values.get('num_scored_books') if kappa_values else None,
                'scorable': kappa_values.get('scorable') if kappa_values else None,
            }

        result['metrics'] = {
            'miner_metrics': miner_metrics,
            'daily_volumes': daily_volumes,
            'daily_roundtrip_volumes': daily_roundtrip_volumes,
            'total_inventory_history': total_inventory_history,
            'total_realized_pnl': total_realized_pnl,
            'realized_pnl_by_book': realized_pnl_by_book,
            'fee_sums_by_book': fee_sums_by_book,
            'pnl': pnl,
            'scores': scores.tolist(),
            'placements': placements.tolist(),
        }
    except Exception as ex:
        result['error'] = str(ex)
        result['traceback'] = traceback.format_exc()
    return result


async def report(self: ReportingService) -> None:
    """
    Calculates and publishes metrics related to simulation state, validator and agent performance.

    Args:
        self (ReportingService): The intelligent markets simulation validator.
    Returns:
        None
    """
    try:
        self.shared_state_reporting = True
        report_step = self.step
        simulation_duration = duration_from_timestamp(self.simulation_timestamp)
        bt.logging.info(f"Publishing Metrics at Step {self.step} ({simulation_duration})...")
        report_start = time.time()
        updates = deque()    
        bt.logging.debug("Collecting simulation metrics...")
        start = time.time()
        
        agent_gauges = self.prometheus_agent_gauges
        book_gauges = self.prometheus_book_gauges
        miner_gauges = self.prometheus_miner_gauges
        wallet_addr = self.wallet.hotkey.ss58_address
        netuid = self.config.netuid
        simid = self.simulation.simulation_id

        updates.append((
            self.prometheus_simulation_gauges,
            self.simulation_timestamp,
            wallet_addr,
            netuid,
            simid,
            "timestamp"
        ))

        updates.append((
            self.prometheus_simulation_gauges,
            sum(self.step_rates) / len(self.step_rates) if len(self.step_rates) > 0 else 0,
            wallet_addr,
            netuid,
            simid,
            "step_rate"
        ))
        publish_class_gauges(self, updates, wallet_addr, netuid, simid)
        publish_capture_settle_gauges(self, updates, wallet_addr, netuid, simid)
        publish_agent_class_gauges(self, updates, wallet_addr, netuid, simid)
        bt.logging.debug(f"Simulation metrics collected ({time.time()-start:.4f}s).")

        has_new_trades = False
        has_new_miner_trades = False

        publish_info(self)

        bt.logging.debug("Collecting book metrics...")
        book_start = time.time()
        for bookId, book in self.last_state.books.items():
            if book['b']:
                bid_cumsum = 0
                for i, level in enumerate(book['b']):
                    updates.append((book_gauges, level['p'],
                        wallet_addr, netuid, simid, bookId, i, "bid"))
                    updates.append((book_gauges, level['q'],
                        wallet_addr, netuid, simid, bookId, i, "bid_vol"))
                    bid_cumsum += level['q']
                    updates.append((book_gauges, bid_cumsum,
                        wallet_addr, netuid, simid, bookId, i, "bid_vol_sum"))
                    if i == 20:
                        break
            if book['a']:
                ask_cumsum = 0
                for i, level in enumerate(book['a']):
                    updates.append((book_gauges, level['p'],
                        wallet_addr, netuid, simid, bookId, i, "ask"))
                    updates.append((book_gauges, level['q'],
                        wallet_addr, netuid, simid, bookId, i, "ask_vol"))
                    ask_cumsum += level['q']
                    updates.append((book_gauges, ask_cumsum,
                        wallet_addr, netuid, simid, bookId, i, "ask_vol_sum"))
                    if i == 20:
                        break
            if book['b'] and book['a']:
                mid = (book['b'][0]['p'] + book['a'][0]['p']) / 2
                updates.append((book_gauges, mid,
                    wallet_addr, netuid, simid, bookId, 0, "mid"))

                def get_price(side, idx):
                    if side == 'bid':
                        return book['b'][idx]['p'] if len(book['b']) > idx else 0
                    if side == 'ask':
                        return book['a'][idx]['p'] if len(book['a']) > idx else 0

                def get_vol(side, idx):
                    if side == 'bid':
                        return book['b'][idx]['q'] if len(book['b']) > idx else 0
                    if side == 'ask':
                        return book['a'][idx]['q'] if len(book['a']) > idx else 0

                updates.append((self.prometheus_books, 1.0,
                    wallet_addr, netuid, simid, self.simulation_timestamp, simulation_duration, bookId,
                    get_price('bid',4), get_vol('bid',4), get_price('bid',3), get_vol('bid',3), get_price('bid',2), get_vol('bid',2),
                    get_price('bid',1), get_vol('bid',1), get_price('bid',0), get_vol('bid',0),
                    get_price('ask',4), get_vol('ask',4), get_price('ask',3), get_vol('ask',3), get_price('ask',2), get_vol('ask',2),
                    get_price('ask',1), get_vol('ask',1), get_price('ask',0), get_vol('ask',0),
                    "books"
                ))
            # The fundamental price does not depend on this step's trades: it used to sit inside the
            # trades branch below, so a quiet book had no fundamental_price series after a reporting
            # restart until its next trade.
            fp = self.fundamental_price.get(bookId) if self.fundamental_price else None
            if fp is not None:
                if isinstance(fp, pd.Series):
                    updates.append((book_gauges,
                        fp.iloc[-1],
                        wallet_addr, netuid, simid, bookId, 0, "fundamental_price"))
                elif fp:
                    updates.append((book_gauges,
                        fp,
                        wallet_addr, netuid, simid, bookId, 0, "fundamental_price"))
                else:
                    _remove_and_evict(self._child_cache, book_gauges,
                        wallet_addr, netuid, simid, bookId, 0, "fundamental_price")

            trades = [event for event in (book.get('e') or []) if event['y'] == 't']
            if trades:
                last_trade = trades[-1]
                updates.append((book_gauges, last_trade['p'],
                    wallet_addr, netuid, simid, bookId, 0, "trade_price"))
                updates.append((book_gauges, sum([trade['q'] for trade in trades]),
                    wallet_addr, netuid, simid, bookId, 0, "trade_volume"))
                updates.append((book_gauges, sum([trade['q'] for trade in trades if trade['s'] == 0]),
                    wallet_addr, netuid, simid, bookId, 0, "trade_buy_volume"))
                updates.append((book_gauges, sum([trade['q'] for trade in trades if trade['s'] == 1]),
                    wallet_addr, netuid, simid, bookId, 0, "trade_sell_volume"))

                has_new_trades = True
            else:
                # No trade on this book this step. The gauges are persistent, so between trades they used
                # to hold the previous step's values, and after a reporting restart a quiet book had NO
                # trade_price or trade_volume series at all until it traded again (testnet:
                # 31 of 128 books blank four minutes after a restart). The last trade price is seeded from
                # the recent-trades buffer the validator keeps per book, and this step's volume is what
                # it is, zero.
                _recent = (getattr(self, 'recent_trades', None) or {}).get(bookId)
                if _recent:
                    updates.append((book_gauges, _recent[-1].price,
                        wallet_addr, netuid, simid, bookId, 0, "trade_price"))
                for _g in ("trade_volume", "trade_buy_volume", "trade_sell_volume"):
                    updates.append((book_gauges, 0.0, wallet_addr, netuid, simid, bookId, 0, _g))
            if getattr(self.simulation, 'fee_policy', None) and self.simulation.fee_policy.fee_type == 'dynamic':
                DISMTR = self.last_state.books[bookId].get('r', self.last_state.books[bookId].get('mtr', 0))
                DISmakerRate = self.last_state.accounts[0][bookId]['f']['m']
                DIStakerRate = self.last_state.accounts[0][bookId]['f']['t']
                updates.append((book_gauges, DISmakerRate,
                        wallet_addr, netuid, simid, bookId, 0, "dynamic_maker_rate"))
                updates.append((book_gauges, DIStakerRate,
                        wallet_addr, netuid, simid, bookId, 0, "dynamic_taker_rate"))
                updates.append((book_gauges, DISMTR,
                        wallet_addr, netuid, simid, bookId, 0, "maker_taker_ratio"))
        publish_capture_floor_gauges(self, updates, wallet_addr, netuid, simid)
        bt.logging.debug(f"Book metrics collected ({time.time()-book_start:.4f}s).")

        if has_new_trades:
            bt.logging.debug("Collecting trade metrics...")
            start = time.time()
            for bookId, trades in self.recent_trades.items():
                # slot=0 is the most recent trade; values that were labels become
                # the gauge value keyed by trade_gauge_name. timestamp is emitted in
                # seconds (ns/1e9) to stay float64 integer-exact; the Grafana table
                # formats it (the human-readable timestamp_str label is dropped).
                for slot, trade in enumerate(reversed(trades)):
                    for name, val in (
                        ("timestamp", trade.timestamp / 1e9),
                        ("price", trade.price),
                        ("volume", trade.quantity),
                        ("maker_fee", trade.maker_fee),
                        ("taker_fee", trade.taker_fee),
                        ("side", trade.side),
                        ("taker_agent_id", trade.taker_agent_id),
                        ("maker_agent_id", trade.maker_agent_id),
                        ("aggressing_order_id", trade.taker_id),
                        ("resting_order_id", trade.maker_id),
                        ("trade_id", trade.id),
                    ):
                        updates.append((self.prometheus_trades, val,
                            wallet_addr, netuid, simid, bookId, slot, name))

            bt.logging.debug(f"Trade metrics collected ({time.time()-start:.4f}s).")

        if not self.last_state.accounts:
            bt.logging.info(f"Applying {len(updates)} metric updates...")
            apply_start = time.time()
            remaining, _, _ = self._apply_snapshot_collectors(updates)
            for update in remaining:
                _set_if_changed(*update)
            bt.logging.info(f"Applied {len(updates)} updates in {time.time()-apply_start:.4f}s")
            bt.logging.info(f"Metrics Published for Step {report_step} ({time.time()-report_start}s).")
            return
            
        bt.logging.debug("Computing miner metrics in worker process...")
        computation_start = time.time()
        volume_sums_snapshot = {uid: dict(books) for uid, books in self.volume_sums.items()}
        maker_volume_sums_snapshot = {uid: dict(books) for uid, books in self.maker_volume_sums.items()}
        taker_volume_sums_snapshot = {uid: dict(books) for uid, books in self.taker_volume_sums.items()}
        self_volume_sums_snapshot = {uid: dict(books) for uid, books in self.self_volume_sums.items()}
    
        validator_data = {
            'simulation_timestamp': self.simulation_timestamp,
            'step': self.step,
            'volume_sums': volume_sums_snapshot,
            'maker_volume_sums': maker_volume_sums_snapshot,
            'taker_volume_sums': taker_volume_sums_snapshot,
            'self_volume_sums': self_volume_sums_snapshot,
            'roundtrip_volume_sums': {uid: dict(books) for uid, books in self.roundtrip_volume_sums.items()},
            'inventory_history': self.inventory_history,
            'is_exchange': not hasattr(self.simulation, 'block_count'),
            'inventory_quote': {uid: dict(v) for uid, v in (getattr(self, 'inventory_quote', None) or {}).items()},
            'initial_quote': {uid: {b: (d or {}).get('QUOTE') for b, d in books_.items()}
                              for uid, books_ in (self.initial_balances or {}).items()},
            'total_realized_pnl': self.total_realized_pnl,
            'realized_pnl_by_book': self.realized_pnl_by_book,
            'fee_sums': {uid: dict(books) for uid, books in self.fee_sums.items()},
            'activity_factors': self.activity_factors,
            'pnl_factors': self.pnl_factors,
            'kappa_values': self.kappa_values,
            'unnormalized_scores': self.unnormalized_scores,
            'scores': self.scores,
            'debeta_scores': getattr(self, 'debeta_scores', {}) or {},
            'gentrx_scores': self.gentrx_scores,
            'book_count': self.simulation.book_count,
            'book_ids': list(self.simulation.book_ids),
            'simulation_config': {
                'volumeDecimals': self.simulation.volumeDecimals,
                'baseDecimals': getattr(self.simulation, 'baseDecimals', self.simulation.volumeDecimals),
                'quoteDecimals': getattr(self.simulation, 'quoteDecimals', self.simulation.volumeDecimals),
            }
        }

        state_data = {
            'accounts': self.last_state.accounts,
            'books': self.last_state.books,
            'notices': self.last_state.notices,
        }
        loop = asyncio.get_running_loop()
        future = loop.run_in_executor(self.report_executor, report_worker, validator_data, state_data)
        while not future.done():
            await asyncio.sleep(0.001)
        result = future.result()

        if result['error']:
            bt.logging.error(f"Error in report worker: {result['error']}\n{result.get('traceback', 'N/A')}")
            return

        bt.logging.debug(f"Miner metrics computed ({time.time()-computation_start:.4f}s).")

        metrics = result['metrics']
        miner_metrics = metrics['miner_metrics']
        daily_volumes = metrics['daily_volumes']
        daily_roundtrip_volumes = metrics['daily_roundtrip_volumes']
        self.realized_pnl_by_book = metrics['realized_pnl_by_book']
        _fee_sums_by_book = metrics.get('fee_sums_by_book', {})

        bt.logging.debug("Collecting agent book metrics...")
        start = time.time()

        bt.logging.debug("Pre-extracting inventory/kappa data...")
        extract_start = time.time()

        start_inventories = {}
        last_inventories = {}
        kappa_data = {}
        for agentId in self.last_state.accounts.keys():
            if agentId < 0:
                continue
            if agentId not in self.inventory_history or not self.inventory_history[agentId]:
                continue
            if len(self.inventory_history[agentId]) < 2:
                continue
            _hist = self.inventory_history[agentId]
            if not hasattr(self.simulation, 'block_count'):
                _, _per_book = exchange_inventory(
                    _hist, (getattr(self, 'inventory_quote', None) or {}).get(agentId) or {},
                    {b: (d or {}).get('QUOTE') for b, d in (self.initial_balances.get(agentId) or {}).items()})
                _hist = {ts: _per_book.get(ts, row) for ts, row in _hist.items()}
            inv_values = list(_hist.values())
            start_inventories[agentId] = [i for i in inv_values if len(i) > 0][0]
            last_inventories[agentId] = inv_values[-1]
            kappa_data[agentId] = self.kappa_values.get(agentId)
        bt.logging.debug(f"Pre-extraction complete ({time.time()-extract_start:.4f}s)")

        for agentId, accounts in self.last_state.accounts.items():
            initial_balance_publish_status = {bookId: False for bookId in self.simulation.book_ids}
            for bookId, _account in accounts.items():
                if agentId in self.initial_balances and self.initial_balances[agentId][bookId]['BASE'] is not None and not self.initial_balances_published.get(agentId, False):
                    updates.append((agent_gauges, self.initial_balances[agentId][bookId]['BASE'],
                        wallet_addr, netuid, simid, bookId, agentId, "base_balance_initial"))
                    updates.append((agent_gauges, self.initial_balances[agentId][bookId]['QUOTE'],
                        wallet_addr, netuid, simid, bookId, agentId, "quote_balance_initial"))
                    updates.append((agent_gauges, self.initial_balances[agentId][bookId]['WEALTH'],
                        wallet_addr, netuid, simid, bookId, agentId, "wealth_initial"))
                    initial_balance_publish_status[bookId] = True
            if all(initial_balance_publish_status.values()):
                self.initial_balances_published[agentId] = True

            if agentId not in start_inventories:
                continue

            start_inv = start_inventories[agentId]
            last_inv = last_inventories[agentId]
            kappas = kappa_data[agentId]

            for bookId, account in accounts.items():
                updates.append((agent_gauges, account['bb']['t'], wallet_addr, netuid, simid, bookId, agentId, "base_balance_total"))
                updates.append((agent_gauges, account['bb']['f'], wallet_addr, netuid, simid, bookId, agentId, "base_balance_free"))
                updates.append((agent_gauges, account['bb']['r'], wallet_addr, netuid, simid, bookId, agentId, "base_balance_reserved"))
                updates.append((agent_gauges, account['qb']['t'], wallet_addr, netuid, simid, bookId, agentId, "quote_balance_total"))
                updates.append((agent_gauges, account['qb']['f'], wallet_addr, netuid, simid, bookId, agentId, "quote_balance_free"))
                updates.append((agent_gauges, account['qb']['r'], wallet_addr, netuid, simid, bookId, agentId, "quote_balance_reserved"))
                updates.append((agent_gauges, account['bl'], wallet_addr, netuid, simid, bookId, agentId, "base_loan"))
                updates.append((agent_gauges, account['bc'], wallet_addr, netuid, simid, bookId, agentId, "base_collateral"))
                updates.append((agent_gauges, account['ql'], wallet_addr, netuid, simid, bookId, agentId, "quote_loan"))
                updates.append((agent_gauges, account['qc'], wallet_addr, netuid, simid, bookId, agentId, "quote_collateral"))
                if account['f']['v']:
                    updates.append((agent_gauges, account['f']['v'], wallet_addr, netuid, simid, bookId, agentId, "fees_traded_volume"))
                updates.append((agent_gauges, account['f']['m'], wallet_addr, netuid, simid, bookId, agentId, "fees_maker_rate"))
                updates.append((agent_gauges, account['f']['t'], wallet_addr, netuid, simid, bookId, agentId, "fees_taker_rate"))
                updates.append((agent_gauges, last_inv.get(bookId, 0.0), wallet_addr, netuid, simid, bookId, agentId, "inventory_value"))
                updates.append((agent_gauges, last_inv.get(bookId, 0.0) - start_inv.get(bookId, 0.0), wallet_addr, netuid, simid, bookId, agentId, "pnl"))
                if agentId in self.realized_pnl_by_book:
                    book_realized_pnl = self.realized_pnl_by_book[agentId].get(bookId, 0.0)
                    updates.append((agent_gauges, book_realized_pnl, wallet_addr, netuid, simid, bookId, agentId, "realized_pnl"))
                else:
                    updates.append((agent_gauges, 0.0, wallet_addr, netuid, simid, bookId, agentId, "realized_pnl"))
                _agent_fee_books = _fee_sums_by_book.get(agentId, _fee_sums_by_book.get(str(agentId), {}))
                updates.append((agent_gauges, _agent_fee_books.get(bookId, _agent_fee_books.get(str(bookId), 0.0)),
                                wallet_addr, netuid, simid, bookId, agentId, "net_fee"))
                # daily_volumes is keyed by the accounts snapshot metrics were built
                # from, but this loop walks the CURRENT last_state.accounts. An agent
                # present in one and not the other raised KeyError here and aborted
                # the whole publish, losing every gauge for the cycle rather than one.
                # 0.0 is the right default and not a papering-over: the builder itself
                # defaults these to 0.0 when the volume sums have nothing for the pair.
                # Every other lookup in this block is already defensive this way.
                _dv = daily_volumes.get(agentId, {}).get(bookId) or {}
                updates.append((agent_gauges, _dv.get('total', 0.0), wallet_addr, netuid, simid, bookId, agentId, "daily_volume"))
                updates.append((agent_gauges, _dv.get('maker', 0.0), wallet_addr, netuid, simid, bookId, agentId, "daily_maker_volume"))
                updates.append((agent_gauges, _dv.get('taker', 0.0), wallet_addr, netuid, simid, bookId, agentId, "daily_taker_volume"))
                updates.append((agent_gauges, _dv.get('self', 0.0), wallet_addr, netuid, simid, bookId, agentId, "daily_self_volume"))
                updates.append((agent_gauges, daily_roundtrip_volumes.get(agentId, {}).get(bookId, 0.0), wallet_addr, netuid, simid, bookId, agentId, "daily_roundtrip_volume"))
                updates.append((agent_gauges, self.activity_factors.get(agentId, {}).get(bookId, 0.0), wallet_addr, netuid, simid, bookId, agentId, "activity_factor"))
                updates.append((agent_gauges, self.pnl_factors.get(agentId, {}).get(bookId, 1.0), wallet_addr, netuid, simid, bookId, agentId, "pnl_factor"))
                if kappas:
                    # books and books_weighted are populated over DIFFERENT key sets: a uid
                    # with no scoreable books gets a full 'books' map and an empty
                    # 'books_weighted', so membership of the outer key does not imply the
                    # bookId is present. Index via .get on both.
                    _kappa_book = (kappas.get('books') or {}).get(bookId)
                    if _kappa_book is not None:
                        updates.append((agent_gauges, _kappa_book, wallet_addr, netuid, simid, bookId, agentId, "kappa"))
                    else:
                        _remove_and_evict(self._child_cache, agent_gauges, wallet_addr, netuid, simid, bookId, agentId, "kappa")
                    _kappa_weighted = (kappas.get('books_weighted') or {}).get(bookId)
                    if _kappa_weighted is not None:
                        updates.append((agent_gauges, _kappa_weighted, wallet_addr, netuid, simid, bookId, agentId, "weighted_kappa"))
                    else:
                        _remove_and_evict(self._child_cache, agent_gauges, wallet_addr, netuid, simid, bookId, agentId, "weighted_kappa")
                else:
                    _remove_and_evict(self._child_cache, agent_gauges, wallet_addr, netuid, simid, bookId, agentId, "kappa")
                # DE-BETA per-book inputs: which books earned making credit, and each book's alpha.
                # GATED, default off. Cardinality is uid x book, so on a 259x128 board these four are
                # ~133k series and ~24MB on a scrape already running 154MB. two_sided and alpha_counted
                # were dropped rather than gated: both are derivable in the query from the four below
                # plus the per-uid debeta_skill_floor, so publishing them bought nothing.
                #   two_sided     = debeta_capture_buy != 0 and debeta_capture_sell != 0
                #   alpha_counted = abs(debeta_alpha) >= debeta_skill_floor
                # Outside the `if kappas` block deliberately: these come from the validator's own
                # accumulators, not kappa_values, and must publish on a cycle where kappa produced none.
                if getattr(self, '_debeta_book_gauges', False):
                    _cb = (getattr(self, 'capture_buy_sums', {}).get(agentId) or {}).get(bookId)
                    _cs = (getattr(self, 'capture_sell_sums', {}).get(agentId) or {}).get(bookId)
                    _alp = (getattr(self, 'debeta_alphas_by_book', {}).get(agentId) or {}).get(bookId)
                    for _g, _v in (("debeta_capture_buy", _cb),
                                   ("debeta_capture_sell", _cs),
                                   ("debeta_book_making",
                                    (2.0 * min(_cb, _cs)) if (_cb is not None and _cs is not None) else None),
                                   ("debeta_alpha", _alp)):
                        if _v is not None:
                            updates.append((agent_gauges, _v, wallet_addr, netuid, simid, bookId, agentId, _g))
                        else:
                            _remove_and_evict(self._child_cache, agent_gauges, wallet_addr, netuid, simid, bookId, agentId, _g)
        bt.logging.debug(f"Agent book metrics collected ({time.time()-start:.4f}s).")

        bt.logging.debug("Collecting miner trade metrics...")
        start = time.time()
        for agentId, notices in self.last_state.notices.items():
            if agentId < 0:
                continue
            for notice in notices:
                if notice['y'] in ["EVENT_TRADE", "ET"]:
                    has_new_miner_trades = True
                    break
            if has_new_miner_trades:
                break
        if has_new_miner_trades:
            for uid, book_miner_trades in self.recent_miner_trades.items():
                for bookId, miner_trades in book_miner_trades.items():
                    if len(miner_trades) > 0:
                        last_maker_trade = None
                        last_taker_trade = None
                        # Bounded-slot shape (slot=0 most recent); numeric fields move
                        # from labels into the gauge value keyed by miner_trade_gauge_name.
                        # role is encoded 0=maker / 1=taker; timestamp emitted in seconds.
                        for slot, (miner_trade, role) in enumerate(reversed(self.recent_miner_trades[uid][bookId])):
                            _ts = getattr(miner_trade, 't', None)
                            if _ts is None:
                                # Malformed trade notice (missing timestamp) must never abort
                                # the entire metrics publish — skip this one slot.
                                continue
                            side = miner_trade.side if role == 'taker' else int(not miner_trade.side)
                            # Same principle as the timestamp guard above: one malformed slot must
                            # never abort the entire metrics publish. takerFee/makerFee are
                            # properties over Tf/Mf, and a trade restored from state before the
                            # notice fix has neither, which took metrics down four times in 40
                            # minutes. Skipped, not defaulted: a fabricated zero fee would
                            # misreport cost wherever fees are real.
                            try:
                                fee = miner_trade.makerFee if role == 'maker' else miner_trade.takerFee
                            except AttributeError:
                                bt.logging.debug(
                                    f"metrics: skipping a miner trade with no fee field (role {role})"
                                )
                                continue
                            # The other party's agent id; background flow carries a negative id, so the
                            # dashboard can show it as market rather than as a miner.
                            counterparty = miner_trade.takerAgentId if role == 'maker' else miner_trade.makerAgentId
                            for name, val in (
                                ("timestamp", _ts / 1e9),
                                ("price", miner_trade.price),
                                ("volume", miner_trade.quantity),
                                ("fee", fee),
                                ("side", side),
                                ("role", 1 if role == 'taker' else 0),
                                ("counterparty", counterparty),
                            ):
                                updates.append((self.prometheus_miner_trades, val,
                                    wallet_addr, netuid, simid, miner_trade.bookId, uid, slot, name))
                            if role == 'maker':
                                last_maker_trade = miner_trade
                            if role == 'taker':
                                last_taker_trade = miner_trade
                        if last_maker_trade:
                            updates.append((agent_gauges, last_maker_trade.makerFeeRate, wallet_addr, netuid, simid, bookId, uid, "fees_last_maker_rate"))
                        if last_taker_trade:
                            updates.append((agent_gauges, last_taker_trade.takerFeeRate, wallet_addr, netuid, simid, bookId, uid, "fees_last_taker_rate"))
        bt.logging.debug(f"Miner trade metrics collected ({time.time()-start:.4f}s).")

        bt.logging.debug("Collecting miner metrics...")
        self.prometheus_miners.clear()
        self.prometheus_miner_identity.clear()
        start = time.time()
        for agentId in miner_metrics:
            m = miner_metrics[agentId]

            updates.append((miner_gauges, m['total_base_balance'], wallet_addr, netuid, simid, agentId, "total_base_balance"))
            updates.append((miner_gauges, m['total_base_loan'], wallet_addr, netuid, simid, agentId, "total_base_loan"))
            updates.append((miner_gauges, m['total_base_collateral'], wallet_addr, netuid, simid, agentId, "total_base_collateral"))
            updates.append((miner_gauges, m['total_quote_balance'], wallet_addr, netuid, simid, agentId, "total_quote_balance"))
            updates.append((miner_gauges, m['total_quote_loan'], wallet_addr, netuid, simid, agentId, "total_quote_loan"))
            updates.append((miner_gauges, m['total_quote_collateral'], wallet_addr, netuid, simid, agentId, "total_quote_collateral"))
            updates.append((miner_gauges, m['total_inventory_value'], wallet_addr, netuid, simid, agentId, "total_inventory_value"))
            updates.append((miner_gauges, m['pnl'], wallet_addr, netuid, simid, agentId, "pnl"))
            updates.append((miner_gauges, m['total_realized_pnl'], wallet_addr, netuid, simid, agentId, "total_realized_pnl"))

            updates.append((miner_gauges, m['total_daily_volume']['total'], wallet_addr, netuid, simid, agentId, "total_daily_volume"))
            updates.append((miner_gauges, m['total_daily_volume']['maker'], wallet_addr, netuid, simid, agentId, "total_daily_maker_volume"))
            updates.append((miner_gauges, m['total_daily_volume']['taker'], wallet_addr, netuid, simid, agentId, "total_daily_taker_volume"))
            updates.append((miner_gauges, m['total_daily_volume']['self'], wallet_addr, netuid, simid, agentId, "total_daily_self_volume"))

            updates.append((miner_gauges, m['average_daily_volume']['total'], wallet_addr, netuid, simid, agentId, "average_daily_volume"))
            updates.append((miner_gauges, m['average_daily_volume']['maker'], wallet_addr, netuid, simid, agentId, "average_daily_maker_volume"))
            updates.append((miner_gauges, m['average_daily_volume']['taker'], wallet_addr, netuid, simid, agentId, "average_daily_taker_volume"))
            updates.append((miner_gauges, m['average_daily_volume']['self'], wallet_addr, netuid, simid, agentId, "average_daily_self_volume"))

            updates.append((miner_gauges, m['min_daily_volume']['total'], wallet_addr, netuid, simid, agentId, "min_daily_volume"))
            updates.append((miner_gauges, m['min_daily_volume']['maker'], wallet_addr, netuid, simid, agentId, "min_daily_maker_volume"))
            updates.append((miner_gauges, m['min_daily_volume']['taker'], wallet_addr, netuid, simid, agentId, "min_daily_taker_volume"))
            updates.append((miner_gauges, m['min_daily_volume']['self'], wallet_addr, netuid, simid, agentId, "min_daily_self_volume"))
            
            updates.append((miner_gauges, m['total_roundtrip_volume'], wallet_addr, netuid, simid, agentId, "total_roundtrip_volume"))
            updates.append((miner_gauges, m['average_roundtrip_volume'], wallet_addr, netuid, simid, agentId, "average_roundtrip_volume"))
            updates.append((miner_gauges, m['min_roundtrip_volume'], wallet_addr, netuid, simid, agentId, "min_roundtrip_volume"))

            updates.append((miner_gauges, m['activity_factor'], wallet_addr, netuid, simid, agentId, "activity_factor"))
            updates.append((miner_gauges, m['pnl_factor'], wallet_addr, netuid, simid, agentId, "pnl_factor"))

            if m['kappa'] is not None:
                updates.append((miner_gauges, m['kappa'], wallet_addr, netuid, simid, agentId, "kappa"))
                if m['activity_weighted_normalized_median'] is not None:
                    updates.append((miner_gauges, m['activity_weighted_normalized_median'], wallet_addr, netuid, simid, agentId, "activity_weighted_normalized_median_kappa"))
                if m['kappa_penalty'] is not None:
                    updates.append((miner_gauges, m['kappa_penalty'], wallet_addr, netuid, simid, agentId, "kappa_penalty"))
                if m['kappa_score'] is not None:
                    updates.append((miner_gauges, m['kappa_score'], wallet_addr, netuid, simid, agentId, "kappa_score"))
            else:
                _remove_and_evict(self._child_cache, miner_gauges, wallet_addr, netuid, simid, agentId, "kappa")
            # The blend scores, the de-beta decomposition and the eligibility flag are NOT kappa gauges
            # and are published for every miner whose carrier holds them. They used to sit inside the
            # kappa test above: at kappa weight 0 (the final rung) no uid has a kappa, and on the first
            # cycle of (0, 0, 1), every debeta_*, trading_score,
            # combined_score and scorable series disappeared for all 257 miners while the score itself
            # kept moving. The same gate had hidden the decomposition for the scored uids without a
            # kappa at every earlier rung.
            if m['pnl_score'] is not None:
                updates.append((miner_gauges, m['pnl_score'], wallet_addr, netuid, simid, agentId, "pnl_score"))
            if m.get('trading_score') is not None:
                # RAW pre-EMA trading score: the quantity the blend invariant checks
                # (combined_score above is the EMA standing and would never reconcile).
                updates.append((miner_gauges, m['trading_score'], wallet_addr, netuid, simid, agentId, "trading_score"))
            else:
                _remove_and_evict(self._child_cache, miner_gauges, wallet_addr, netuid, simid, agentId, "trading_score")
            if m['combined_score'] is not None:
                updates.append((miner_gauges, m['combined_score'], wallet_addr, netuid, simid, agentId, "combined_score"))
            else:
                _remove_and_evict(self._child_cache, miner_gauges, wallet_addr, netuid, simid, agentId, "combined_score")
            # DE-BETA decomposition. Emitted when present and EVICTED when absent, so a fallback
            # cycle (empty debeta map -> legacy kappa+pnl) cannot leave a stale making/skill series
            # implying de-beta still drives the score.
            for _k, _g in (('debeta_score', 'debeta_score'),
                           ('making_share', 'debeta_making_share'),
                           ('ladder_input', 'debeta_ladder_input'),
                           ('making_raw', 'debeta_making'),
                           ('making_rank', 'debeta_making_rank'),
                           ('skill_raw', 'debeta_skill'),
                           ('skill_rank', 'debeta_skill_rank'),
                           ('p11_factor', 'debeta_p11_factor'),
                           ('s3_factor', 'debeta_s3_factor'),
                           ('bg_share', 'debeta_bg_share'),
                           ('making_realized', 'debeta_making_realized'),
                           ('making_captured', 'debeta_making_captured'),
                           ('making_basis', 'debeta_making_basis'),
                           ('present', 'debeta_present'),
                           ('debeta_weight', 'debeta_weight'),
                           ('debeta_w_make', 'debeta_w_make'),
                           ('debeta_floor', 'debeta_skill_floor'),
                           # 0.6.2 skill-leg quantities: the other drift variant's skill, the three-way
                           # weakest sub-window kappa, books left after the hurdle, the pool factor, the
                           # filled notional and the graded presence share
                           ('skill_other', 'debeta_skill_other_variant'),
                           # the alternative mark's skill (0.6.5): judged on live data before a change of mark pays
                           ('skill_mark_alt', 'debeta_skill_mark_alt'),
                           ('skill_net_alpha_mark_alt', 'debeta_skill_net_alpha_mark_alt'),
                           # the liquidity a maker provides (0.6.5): read before a making rule pays for it
                           ('maker_notional_two_sided', 'debeta_maker_notional_two_sided'),
                           ('at_best_seconds', 'debeta_at_best_seconds'),
                           ('best_size', 'debeta_best_size'),
                           ('skill_weakest3', 'debeta_skill_weakest3'),
                           ('skill_books_kept', 'debeta_skill_books_kept'),
                           ('skill_pool_factor', 'debeta_skill_pool_factor'),
                           ('skill_coverage_factor', 'debeta_skill_coverage_factor'),
                           ('coverage_books', 'debeta_coverage_books'),
                           ('skill_p11_factor', 'debeta_skill_p11_factor'),
                           ('skill_net_alpha', 'debeta_skill_net_alpha'),
                           ('notional', 'debeta_notional'),
                           ('presence_share', 'debeta_presence_share'),
                           ('num_scored_books', 'num_scored_books')):
                _v = m.get(_k)
                if _v is not None:
                    updates.append((miner_gauges, _v, wallet_addr, netuid, simid, agentId, _g))
                else:
                    _remove_and_evict(self._child_cache, miner_gauges, wallet_addr, netuid, simid, agentId, _g)
            # scorable is a warmup flag, not a score: 0 explains a legitimate zero.
            if m.get('scorable') is not None:
                updates.append((miner_gauges, 1.0 if m["scorable"] else 0.0, wallet_addr, netuid, simid, agentId, "scorable"))

            updates.append((miner_gauges, m['unnormalized_score'], wallet_addr, netuid, simid, agentId, "unnormalized_score"))
            updates.append((miner_gauges, m['score'], wallet_addr, netuid, simid, agentId, "score"))
            updates.append((miner_gauges, m['gentrx_score'], wallet_addr, netuid, simid, agentId, "gentrx_score"))
            updates.append((miner_gauges, m['placement'], wallet_addr, netuid, simid, agentId, "placement"))

            updates.append((miner_gauges, (self.metagraph.trust[agentId] if len(self.metagraph.trust) > agentId else 0.0), wallet_addr, netuid, simid, agentId, "trust"))
            updates.append((miner_gauges, (self.metagraph.consensus[agentId] if len(self.metagraph.consensus) > agentId else 0.0), wallet_addr, netuid, simid, agentId, "consensus"))
            updates.append((miner_gauges, (self.metagraph.incentive[agentId] if len(self.metagraph.incentive) > agentId else 0.0), wallet_addr, netuid, simid, agentId, "incentive"))
            updates.append((miner_gauges, (self.metagraph.emission[agentId] if len(self.metagraph.emission) > agentId else 0.0), wallet_addr, netuid, simid, agentId, "emission"))

            _ms = self.miner_stats.get(agentId)
            if _ms and _ms['requests'] >= 100:
                for _name, _value in round_block_gauges(_ms):
                    updates.append((miner_gauges, _value, wallet_addr, netuid, simid, agentId, _name))
                self.miner_stats[agentId] = empty_block_stats()

            _set_if_changed_metric(
                self.prometheus_miners,
                1.0,
                wallet=wallet_addr,
                netuid=netuid,
                sim_id=simid,
                agent_id=agentId,
                hotkey=(self.metagraph.hotkeys[agentId] if len(getattr(self.metagraph, 'hotkeys', [])) > agentId else ""),
                coldkey=(self.metagraph.coldkeys[agentId] if len(getattr(self.metagraph, 'coldkeys', [])) > agentId else ""),
                axon_ip=(self.metagraph.axon_ips[agentId] if len(getattr(self.metagraph, 'axon_ips', [])) > agentId else ""),
                axon_port=(str(self.metagraph.axon_ports[agentId]) if len(getattr(self.metagraph, 'axon_ports', [])) > agentId else ""),
                # Combined display form for tables; Grafana transforms cannot concatenate strings.
                axon=(f"{self.metagraph.axon_ips[agentId]}:{self.metagraph.axon_ports[agentId]}"
                      if len(getattr(self.metagraph, 'axon_ips', [])) > agentId
                      and len(getattr(self.metagraph, 'axon_ports', [])) > agentId else ""),
                timestamp=self.simulation_timestamp,
                timestamp_str=duration_from_timestamp(self.simulation_timestamp),
                placement=m['placement'],
                base_balance=m['total_base_balance'],
                base_loan=m['total_base_loan'],
                base_collateral=m['total_base_collateral'],
                quote_balance=m['total_quote_balance'],
                quote_loan=m['total_quote_loan'],
                quote_collateral=m['total_quote_collateral'],
                inventory_value=m['total_inventory_value'],
                inventory_value_change=m['inventory_value_change'],
                pnl=m['pnl'],
                pnl_change=m['pnl_change'],
                total_realized_pnl=m['total_realized_pnl'],
                total_daily_volume=m['total_daily_volume']['total'],
                min_daily_volume=m['min_daily_volume']['total'],
                average_daily_volume=m['average_daily_volume']['total'],
                total_roundtrip_volume=m['total_roundtrip_volume'],
                min_roundtrip_volume=m['min_roundtrip_volume'], 
                average_roundtrip_volume=m['average_roundtrip_volume'],
                activity_factor=m['activity_factor'],
                pnl_factor=m['pnl_factor'],
                # EMPTY labels when the component was not computed, never a stringified None or the stub's
                # 0.0: Prometheus treats a label with an empty value as absent, so when kappa-3 is skipped
                # for every miner (kappa weight 0, the final rung) the kappa, penalty and kappa score
                # columns of the Agents table disappear on their own, and come back by themselves the
                # cycle kappa is computed again, with no dashboard edit either way. A skipped kappa is
                # recognised by its missing median; the stub carries penalty and score as 0.0.
                kappa=("" if m['kappa'] is None else m['kappa']),
                kappa_penalty=("" if m['kappa'] is None or m['kappa_penalty'] is None else m['kappa_penalty']),
                kappa_score=("" if m['kappa'] is None or m['kappa_score'] is None else m['kappa_score']),
                pnl_score=("" if m['pnl_score'] is None else m['pnl_score']),
                combined_score=m['combined_score'],
                gentrx_score=m['gentrx_score'],
                unnormalized_score=m['unnormalized_score'],
                score=m['score'],
                # De-beta decomposition as table columns; None (fallback cycle or pre-debeta) reads
                # as 0.0 so the Agents table stays numeric-sortable rather than showing 'None'.
                debeta_score=(m['debeta_score'] if m.get('debeta_score') is not None else 0.0),
                debeta_making_rank=(m['making_rank'] if m.get('making_rank') is not None else 0.0),
                debeta_skill_rank=(m['skill_rank'] if m.get('skill_rank') is not None else 0.0),
                debeta_p11_factor=(m['p11_factor'] if m.get('p11_factor') is not None else 0.0),
                debeta_s3_factor=(m['s3_factor'] if m.get('s3_factor') is not None else 1.0),
                debeta_bg_share=(m['bg_share'] if m.get('bg_share') is not None else -1.0),
                debeta_making_realized=(m['making_realized'] if m.get('making_realized') is not None else 0.0),
                debeta_making_captured=(m['making_captured'] if m.get('making_captured') is not None else 0.0),
                debeta_making_basis=(m['making_basis'] if m.get('making_basis') is not None else 0.0),
                # EVERY DECLARED LABEL MUST BE SUPPLIED. prometheus_client rejects the whole call
                # when one is missing -- "Incorrect label names" -- so a label added to the gauge
                # without a matching argument here stops the entire miner gauge publishing, not just
                # its own series.
                debeta_making_share=(m['making_share'] if m.get('making_share') is not None else 0.0),
                debeta_ladder_input=(m['ladder_input'] if m.get('ladder_input') is not None else 0.0),
                # Presence and the two coverage counts belong on the summary row: the per-miner
                # de-beta table that used to carry them duplicated six of its ten columns from here.
                debeta_present=(m['present'] if m.get('present') is not None else 1.0),
                debeta_coverage_books=(m['coverage_books'] if m.get('coverage_books') is not None else 0),
                debeta_skill_coverage_factor=(m['skill_coverage_factor']
                                              if m.get('skill_coverage_factor') is not None else 1.0),
                num_scored_books=(m['num_scored_books'] if m.get('num_scored_books') is not None else 0),
                scorable=(1.0 if m.get('scorable') else 0.0),
                miner_gauge_name='miners'
            )
            _set_if_changed_metric(
                self.prometheus_miner_identity,
                1.0,
                wallet=wallet_addr,
                netuid=netuid,
                sim_id=simid,
                agent_id=agentId,
                hotkey=(self.metagraph.hotkeys[agentId] if len(getattr(self.metagraph, 'hotkeys', [])) > agentId else ""),
                coldkey=(self.metagraph.coldkeys[agentId] if len(getattr(self.metagraph, 'coldkeys', [])) > agentId else ""),
                axon_ip=(self.metagraph.axon_ips[agentId] if len(getattr(self.metagraph, 'axon_ips', [])) > agentId else ""),
                axon_port=(str(self.metagraph.axon_ports[agentId]) if len(getattr(self.metagraph, 'axon_ports', [])) > agentId else ""),
            )
        bt.logging.debug(f"Miner metrics collected ({time.time()-start:.4f}s).")
        
        # Diagnostic (env-gated, off by default): dump this cycle's agent series
        # (value, label-tuple) once, for the offline eager-vs-collector golden diff.
        # Works identically on the eager (0.4.6) and collector builds.
        _dump_path = os.environ.get('REPORT_DUMP_AGENT')
        if _dump_path and not getattr(self, '_agent_dumped', False):
            import pickle
            _ag_series = [(u[1], u[2:]) for u in updates if u[0] is self.prometheus_agent_gauges]
            try:
                with open(_dump_path, 'wb') as _f:
                    pickle.dump(_ag_series, _f)
                self._agent_dumped = True
                bt.logging.warning(f"REPORT_DUMP_AGENT: dumped {len(_ag_series)} agent series to {_dump_path}")
            except Exception as _e:
                bt.logging.warning(f"REPORT_DUMP_AGENT dump failed: {_e}")

        bt.logging.info(f"Applying {len(updates)} metric updates...")
        apply_start = time.time()
        cache = self._child_cache
        # agent_gauges (~1.8M-series bulk, carry-forward) + trades/books/
        # miner_trades (~890K, replace) all route into fresh per-cycle snapshots
        # swapped in at the end — no per-series labels()/.set() and no clear().
        # Everything else stays on the persistent-child cache (cheap on unchanged).
        remaining, agent_count, cleared_count = self._apply_snapshot_collectors(updates)
        for update in remaining:
            _set_cached(cache, update[0], update[1], update[2:])
        bt.logging.info(
            f"Applied {len(updates)} updates in {time.time()-apply_start:.4f}s "
            f"({agent_count} agent_gauges + {cleared_count} trades/books/miner_trades "
            f"via snapshot collectors)"
        )
        # THE ONE POINT A SCRAPE MAY SEE: every family has this cycle's values and none has the next's.
        self.exposition.publish(step=report_step, sim_timestamp=self.simulation_timestamp, sim_id=simid)

        bt.logging.info(f"Metrics Published for Step {report_step} ({time.time()-report_start}s).")
    except Exception as ex:
        self.pagerduty_alert(f"Unable to publish metrics : {ex}", details={"traceback": traceback.format_exc()})
    finally:
        self.shared_state_reporting = False
        
def build_parser() -> argparse.ArgumentParser:
    """The reporting child's own argument parser: the validator forwards what the child reads."""
    parser = argparse.ArgumentParser()
    bt.Wallet.add_args(parser)
    bt.Subtensor.add_args(parser)
    bt.logging.add_args(parser)

    parser.add_argument('--netuid', type=int, default=1)
    parser.add_argument('--logging.level', type=str, default="info")
    parser.add_argument('--prometheus.port', type=int, default=9001)
    parser.add_argument('--prometheus.host', type=str, default='0.0.0.0')
    parser.add_argument('--prometheus.level', type=str, default='INFO')
    parser.add_argument('--cpu-cores', type=str, default=None)
    parser.add_argument('--ipc-prefix', type=str, default='validator',
                        help='Prefix for POSIX IPC resource names — "validator" for simulation, "exchange" for exchange mode')
    # This parser is NOT the validator's: an option the validator forwards but this parser does not
    # declare is dropped by bt.Config, and config.scoring simply does not exist here. The per-book
    # de-beta gauges were dead in the child for exactly that reason, with the flag forwarded.
    from taos.im.config import _flag
    parser.add_argument('--scoring.debeta.publish_book_gauges', type=_flag, nargs='?', const=True, default=True,
                        help='Publish the per-book de-beta gauges; forwarded by the validator, `false` turns them off')
    parser.add_argument('--neuron.observe', type=_flag, nargs='?', const=True, default=False,
                        help='Observe mode; forwarded by the validator so the child does not have to infer it per payload')
    return parser


if __name__ == '__main__':
    bt.logging.set_info()
    parser = build_parser()
    config = bt.Config(parser)
    bt.logging(config=config)

    if config.cpu_cores:
        cores = [int(c) for c in config.cpu_cores.split(',')]
        os.sched_setaffinity(0, set(cores))
        bt.logging.info(f"Reporting service assigned to cores: {cores}")
    
    service = ReportingService(config)
    
    try:
        asyncio.run(service.run())
    except KeyboardInterrupt:
        bt.logging.info("Reporting service stopped by user")
    except Exception as e:
        bt.logging.error(f"Reporting service crashed: {e}")
        bt.logging.error(traceback.format_exc())
        sys.exit(1)