# SPDX-FileCopyrightText: 2026 Rayleigh Research <to@rayleigh.re>
# SPDX-License-Identifier: MIT
"""Shadow scoring service — Q3 Stage A (parity-gated groundwork for the split).

Goal: move all history-consuming background work (volume/PnL accounting, reward,
save, report prep) out of the validator main process. Before any cutover, this
shadow proves the replication property: a subprocess fed (a) one snapshot of the
history structures and (b) the same raw state bytes per round maintains
BIT-IDENTICAL structures by running the very same trade.update_trade_volumes.

Mechanics:
- Main tees each round's raw msgpack state bytes over a socketpair (sent on a
  single-thread executor: FIFO framing, ~10ms GIL-released syscalls off-loop).
- One-time INIT under _reward_lock: each history structure is plainified
  (lambda-factory defaultdicts are unpicklable), pickled and streamed; the child
  rebuilds the exact defaultdict/deque shells and applies buffered rounds newer
  than the snapshot.
- Both sides compute a cheap parity digest at deterministic sim-timestamps
  (counts + running totals; ~10ms); the child ships its digest back and main
  logs [SHADOW-PARITY] MATCH/MISMATCH against its own ring.

Default OFF (SCORING_SHADOW=1 or a repo-root .scoring_shadow sentinel enables);
zero effect on scoring — the child's structures are observed, never consumed.
"""
import hashlib
import multiprocessing
import os
import pickle
import struct
import threading
import time
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

SHADOW_PARITY_NS = int(os.environ.get("SHADOW_PARITY_NS", "10000000000"))
# Parity self-heal storm breaker. This many re-INITs inside this window means the child cannot be
# brought into parity at all (a structure missing from the snapshot, a dropped tee) and every further
# re-INIT only stalls main for the snapshot: the service suspends itself and main scores in-process
# until the validator restarts. 0 disables. A storm of re-INITs inside the window, none of which
# holds parity, is the signature this breaker exists for.
# The side queue's cap, matching the pre-INIT queue's 64. Both hold whole rounds of raw state.
SHADOW_SIDE_BUFFER_MAX = int(os.environ.get("SHADOW_SIDE_BUFFER_MAX", "64"))
SHADOW_REINIT_STORM_N = int(os.environ.get("SHADOW_REINIT_STORM_N", "3"))
SHADOW_REINIT_STORM_S = float(os.environ.get("SHADOW_REINIT_STORM_S", "900"))
# Cutover VERIFY (main recomputes every SCORING_PROC_VERIFY_EVERY-th boundary and cross-checks the
# child) is a second full get_rewards under the reward lock. A due check runs only while at most
# MAX_PENDING reward tasks are queued (the running one included); otherwise it is deferred to the
# next boundary, and after FORCE_AFTER deferrals it runs regardless so a permanently busy box still
# verifies. Unthrottled, a VERIFY holds the reward lock long enough for the queue to cross the
# query-blocking threshold, and miners go unqueried while it does.
SCORING_PROC_VERIFY_MAX_PENDING = int(os.environ.get("SCORING_PROC_VERIFY_MAX_PENDING", "2"))
SCORING_PROC_VERIFY_FORCE_AFTER = int(os.environ.get("SCORING_PROC_VERIFY_FORCE_AFTER", "3"))


def scoring_proc_verify_decision(pending_reward_tasks: int, deferrals: int) -> tuple:
    """Whether a due VERIFY runs at this boundary. Returns (run, deferrals_after)."""
    if pending_reward_tasks <= SCORING_PROC_VERIFY_MAX_PENDING or deferrals >= SCORING_PROC_VERIFY_FORCE_AFTER:
        return True, 0
    return False, deferrals + 1


class VerifyScheduler:
    """When main runs the in-process VERIFY of the cutover child, one decision per scoring boundary.

    A check falls due every `every` boundaries. A due check runs when the reward queue is short
    (scoring_proc_verify_decision); otherwise the WHOLE due period is skipped and counted, and after
    enough skipped periods the next due check runs regardless. The period is consumed either way: the
    first cut carried the due flag to the next boundary, where the queue is the same size because the
    adoption wait alone queues three rounds, so the check merely slid three boundaries and ran at the
    old cadence (testnet: deferred at boundaries 10, 11, 12, ran at 13). Skipping the
    period gives one VERIFY per (force_after + 1) * every boundaries on a busy box and every `every`
    on an idle one.
    """

    def __init__(self, every: int):
        self.every = max(1, int(every))
        self.deferrals = 0
        self.last = None  # "ran", "deferred" or None when the boundary was not due

    @property
    def skips_before_force(self) -> int:
        """How many more due periods may be skipped before one runs regardless of the queue."""
        return max(0, SCORING_PROC_VERIFY_FORCE_AFTER - self.deferrals)

    def boundary(self, n: int, pending_reward_tasks: int) -> bool:
        """`n` is the running count of cutover boundaries; returns whether VERIFY runs at this one."""
        self.last = None
        if n % self.every != 0:
            return False
        run, self.deferrals = scoring_proc_verify_decision(pending_reward_tasks, self.deferrals)
        self.last = "ran" if run else "deferred"
        return run

# De-beta fill-stream accumulators (trade.update_trade_volumes). Running sums keyed {uid: {book: x}}
# (debeta_inv is {book: {uid: x}}) as two-level float defaultdicts; the rest plain dicts: the
# reconstruction state, the capture-mid print windows, the P11 counterparty sums and the
# timestamped histories every sum is pruned from.
_DEBETA_DD2 = ["capture_buy_sums", "capture_sell_sums", "realized_buy_sums", "realized_sell_sums", "debeta_mtm", "debeta_invsum", "debeta_inv",
               "debeta_heldn", "debeta_heldinv", "debeta_helddrift", "debeta_notional",
               "debeta_mtm_alt", "debeta_invsum_alt", "debeta_inv_alt",
               "debeta_maker_buy_notional", "debeta_maker_sell_notional", "debeta_at_best", "debeta_best_size"]
_DEBETA_PLAIN = [
    "debeta_invn", "debeta_pfirst", "debeta_plast", "debeta_drift", "debeta_mark_state",
    "debeta_capture_mid", "debeta_cp", "debeta_cpc", "debeta_cpc_hist",
    "debeta_capbuy_hist", "debeta_capsell_hist", "debeta_realbuy_hist", "debeta_realsell_hist", "debeta_mtm_hist", "debeta_invsum_hist",
    "debeta_invn_hist", "debeta_drift_hist", "debeta_cp_hist",
    "debeta_heldn_hist", "debeta_heldinv_hist", "debeta_helddrift_hist", "debeta_notional_hist",
    "debeta_invn_alt", "debeta_pfirst_alt", "debeta_plast_alt", "debeta_drift_alt", "debeta_mark_state_alt",
    "debeta_mtm_alt_hist", "debeta_invsum_alt_hist", "debeta_invn_alt_hist", "debeta_drift_alt_hist",
    "debeta_maker_buy_notional_hist", "debeta_maker_sell_notional_hist", "debeta_at_best_hist", "debeta_best_size_hist",
]

_STRUCT_NAMES = [
    "trade_volumes", "volume_sums", "maker_volume_sums", "taker_volume_sums",
    "self_volume_sums", "fee_sums", "roundtrip_volumes", "roundtrip_volume_sums",
    "realized_pnl_history", "agent_pnl_by_book", "agent_pnl_total",
    "open_positions", "inventory_history", "inventory_quote", "initial_balances",
    "recent_trades", "recent_miner_trades",
    # Shadow-reward inputs: mutated in place by score_uids each interval, so
    # once initialized the child's own scoring keeps them in lockstep with main.
    "kappa_values", "activity_factors", "pnl_factors",
    # The de-beta accumulators. Until 0.6.1 the snapshot stopped at the kappa structures, so every
    # INIT (and every parity re-INIT) restarted the child's making and skill windows from zero while
    # main's kept going; in cutover mode the child's are the ones that score, so frequent re-INITs
    # leave the legs computed over a tiny slice of fills.
    *_DEBETA_DD2,
    *_DEBETA_PLAIN,
    # Redelivery dedup ledgers (exchange mode): a child with an empty ledger counts every redelivered
    # fill again.
    "_debeta_seen_tids", "_volume_seen_tids",
]


def shadow_enabled() -> bool:
    """Whether the scoring shadow is switched on for this validator."""
    if os.environ.get("SCORING_SHADOW", "0") == "1":
        return True
    try:
        repo_root = Path(__file__).resolve().parents[3]
        return (repo_root / ".scoring_shadow").exists()
    except Exception:
        return False


def cutover_enabled() -> bool:
    """Cutover mode: the scoring service computes rewards authoritatively and
    main adopts them (with per-interval fallback and periodic verification).

    DEFAULT ON (validated live: full score-vector VERIFY, history parity through
    dereg resets, automatic in-process fallback). Disable with SCORING_PROC=0 or
    a repo-root .no_scoring_proc sentinel — the quick rollback switches. The
    legacy .scoring_proc opt-in sentinel is now redundant (harmless if present)."""
    env = os.environ.get("SCORING_PROC")
    if env == "0":
        return False
    if env == "1":
        return True
    try:
        repo_root = Path(__file__).resolve().parents[3]
        return not (repo_root / ".no_scoring_proc").exists()
    except Exception:
        return True


def _plainify(obj):
    """Recursively convert dict-likes to plain dicts so lambda-factory
    defaultdicts pickle; deques, tuples and model objects pass through
    (they pickle natively). Values are never copied deeper than needed."""
    if isinstance(obj, dict):
        return {k: _plainify(v) for k, v in obj.items()}
    if isinstance(obj, deque):
        return deque(_plainify(v) for v in obj)
    if isinstance(obj, list):
        return [_plainify(v) for v in obj]
    return obj


def _rebuild_structs(parts: dict) -> dict:
    """Rebuild the exact container shells main uses, so missing-key behaviour
    (load-bearing defaultdict auto-creation) is identical in the shadow."""
    out = {}

    def dd_float_2(plain):
        """Recursively round every float in a nested structure to 2 decimals for stable digests."""
        d = defaultdict(lambda: defaultdict(float))
        for uid, books in plain.items():
            inner = defaultdict(float)
            inner.update(books)
            d[uid] = inner
        return d

    for name in ("volume_sums", "maker_volume_sums", "taker_volume_sums",
                 "self_volume_sums", "fee_sums", "roundtrip_volume_sums",
                 "agent_pnl_by_book"):
        out[name] = dd_float_2(parts.get(name, {}))

    apt = defaultdict(float)
    apt.update(parts.get("agent_pnl_total", {}))
    out["agent_pnl_total"] = apt

    rtv = defaultdict(lambda: defaultdict(lambda: defaultdict(float)))
    for uid, books in parts.get("roundtrip_volumes", {}).items():
        for book_id, vols in books.items():
            inner = defaultdict(float)
            inner.update(vols)
            rtv[uid][book_id] = inner
    out["roundtrip_volumes"] = rtv

    rpn = defaultdict(lambda: defaultdict(dict))
    for uid, hist in parts.get("realized_pnl_history", {}).items():
        inner = defaultdict(dict)
        inner.update(hist)
        rpn[uid] = inner
    out["realized_pnl_history"] = rpn

    pos = defaultdict(lambda: defaultdict(lambda: {'longs': deque(), 'shorts': deque()}))
    for uid, books in parts.get("open_positions", {}).items():
        for book_id, p in books.items():
            pos[uid][book_id] = {
                'longs': deque(p.get('longs', ())),
                'shorts': deque(p.get('shorts', ())),
            }
    out["open_positions"] = pos

    for name in _DEBETA_DD2:
        out[name] = dd_float_2(parts.get(name, {}))
    for name in _DEBETA_PLAIN + ["_debeta_seen_tids", "_volume_seen_tids"]:
        out[name] = parts.get(name, {})

    for name in ("trade_volumes", "inventory_history", "inventory_quote", "initial_balances",
                 "recent_trades", "recent_miner_trades",
                 "kappa_values", "activity_factors", "pnl_factors"):
        out[name] = parts.get(name, {})

    return out


def compute_parity_components(s) -> dict:
    """Per-structure digests of the history state (duck-typed: works on the
    Validator and the shadow container alike). Sorted keys + sorted-value sums
    make each insertion-order independent; exact float repr keeps them
    bit-sensitive to real divergence. Kept per-field so a mismatch names the
    diverging structure instead of just failing a combined hash."""
    def sum_books(d):
        """Sum a per-book mapping into one total."""
        return tuple(
            (int(u), float(sum(sorted(float(x) for x in b.values()))))
            for u, b in sorted(d.items())
        )

    def h(v):
        """Short stable hash of a value, for digest comparison."""
        return hashlib.md5(repr(v).encode()).hexdigest()[:12]

    return {
        "n_pnl": h(sum(len(hh) for hh in s.realized_pnl_history.values())),
        "n_tv": h(sum(len(r.get('total', {})) for b in s.trade_volumes.values() for r in b.values())),
        "n_rt": h(sum(len(v) for b in s.roundtrip_volumes.values() for v in b.values())),
        "n_pos": h(sum(len(p['longs']) + len(p['shorts'])
                       for b in s.open_positions.values() for p in b.values())),
        "pnl_total": h(tuple(sorted((int(u), float(v)) for u, v in s.agent_pnl_total.items()))),
        "pnl_book": h(sum_books(s.agent_pnl_by_book)),
        "vol": h(sum_books(s.volume_sums)),
        "rt": h(sum_books(s.roundtrip_volume_sums)),
        # The de-beta legs' inputs: a child scoring on accumulators main does not share must show here,
        # not only in the scores it publishes.
        "debeta_cap": h(sum_books(getattr(s, "capture_buy_sums", {}) or {})
                        + sum_books(getattr(s, "capture_sell_sums", {}) or {})),
        "debeta_real": h(sum_books(getattr(s, "realized_buy_sums", {}) or {})
                         + sum_books(getattr(s, "realized_sell_sums", {}) or {})),
        "debeta_mtm": h(sum_books(getattr(s, "debeta_mtm", {}) or {})),
        "prune": h(getattr(s, "_last_prune_timestamp", None)),
    }


def pnl_len_vector(s) -> dict:
    """{uid: len(realized_pnl_history[uid])} for non-empty hists — the uid-level
    breakdown behind the n_pnl component, shipped with parity frames so an
    n_pnl mismatch names WHICH uids diverge (and by how much)."""
    return {int(u): len(h) for u, h in s.realized_pnl_history.items() if h}


def mtm_vector(s) -> dict:
    """{uid: (books held, summed mark-to-market, summed inventory on those books)} for debeta_mtm, the uid-level breakdown behind the
    debeta_mtm component. Since 1 October 2026 the local shadow diverged on that one structure within a
    round of every INIT with only two hashes in the log; this names the uids so the cause can be read."""
    inv = getattr(s, "debeta_inv", {}) or {}          # {book: {uid: inventory}}
    out = {}
    for u, b in (getattr(s, "debeta_mtm", {}) or {}).items():
        vals = [float(x) for x in (b or {}).values()]
        inv_sum = sum(float((inv.get(bk) or {}).get(u, 0.0)) for bk in (b or {}))
        out[int(u)] = (len(vals), round(float(sum(sorted(vals))), 6), round(inv_sum, 6))
    return out


def mtm_books_vector(s) -> dict:
    """Per uid and book, (mark-to-market, inventory), plus each book's last price and whether its rolling mark
    state carries a previous mark: the three inputs the marking loop needs. Shipped with the parity frame so a
    debeta_mtm mismatch shows WHICH input differs for the diverging uid."""
    inv = getattr(s, "debeta_inv", {}) or {}
    plast = getattr(s, "debeta_plast", {}) or {}
    mark = getattr(s, "debeta_mark_state", {}) or {}
    books = {}
    for u, b in (getattr(s, "debeta_mtm", {}) or {}).items():
        books[int(u)] = {int(bk): (round(float(v), 6), round(float((inv.get(bk) or {}).get(u, 0.0)), 6)) for bk, v in (b or {}).items()}
    return {"books": books, "p_last": {int(bk): (None if v is None else round(float(v), 6)) for bk, v in plast.items()},
            "mark_prev": {int(bk): (st or {}).get("prev") is not None for bk, st in mark.items()}}


def parity_vectors(s) -> dict:
    """The uid-level vectors that ride with a parity frame, one function for both sides."""
    return {"n_pnl": pnl_len_vector(s), "debeta_mtm": mtm_vector(s), "mtm_books": mtm_books_vector(s)}


def uid_level_diff(mine: dict, theirs: dict, limit: int = 8) -> dict:
    """The uids whose vector entries differ, largest sum difference first and one-sided uids after, capped
    at `limit`, plus the one-sided lists and the total count. Entries are (books, sum) pairs or ints."""
    def _sum(e):
        if e is None:
            return None
        return float(e[1]) if isinstance(e, (tuple, list)) else float(e)
    diff = {u: (mine.get(u), theirs.get(u)) for u in set(mine) | set(theirs) if mine.get(u) != theirs.get(u)}
    only_main = sorted(u for u, (a, b) in diff.items() if b is None)
    only_shadow = sorted(u for u, (a, b) in diff.items() if a is None)
    # largest difference first; a side with no entry counts as zero, so a uid one side never saw ranks by its size
    ordered = sorted(diff, key=lambda u: -abs((_sum(diff[u][0]) or 0.0) - (_sum(diff[u][1]) or 0.0)))[:limit]
    return {"uids": {u: diff[u] for u in ordered}, "only_main": only_main, "only_shadow": only_shadow, "n_diff": len(diff)}


def compute_parity_digest(s) -> str:
    """Combined digest over the per-structure components."""
    comps = compute_parity_components(s)
    return hashlib.md5(repr(sorted(comps.items())).encode()).hexdigest()


class ShadowState:
    """Attribute container exposing exactly the surface trade.update_trade_volumes
    (and, for shadow-reward, score_uids) touches, so the shadow runs the SAME
    functions on the SAME shapes."""

    def __init__(self, structs: dict, knobs: dict):
        for name, value in structs.items():
            setattr(self, name, value)
        self._last_prune_timestamp = knobs.get("_last_prune_timestamp")
        self._last_accounted_ts = knobs.get("_last_accounted_ts")
        self.step = knobs.get("step", 0)
        self.effective_max_uids = knobs["effective_max_uids"]
        self.config = knobs["config"]
        self.simulation = knobs["simulation"]
        # Shadow-reward inputs (see shadow_score). kappa_cache stays empty —
        # the fingerprint cache is off by default and score_uids gates on it.
        self.scoring_config = knobs.get("scoring_config")
        self.simulation_config = knobs.get("simulation_config")
        self.scoring_interval = knobs.get("scoring_interval", 0)
        self.validator_uid = knobs.get("validator_uid")
        self.kappa_cache = {}
        self.deregistered_uids = []

    def pagerduty_alert(self, message, details=None):
        """Raise a PagerDuty alert from the shadow process.

        Args:
            message: Incident summary.
            details: Structured context attached to the incident.
        """
        print(f"[SHADOW] pagerduty (suppressed): {message}", flush=True)


def shadow_score(shadow: ShadowState, sim_ts: int, deregs: list,
                 gentrx_scores=None, gentrx_ema=None,
                 trading_ema=None, trading_ema_n=None, trading_ema_ts=None,
                 absent=None, presence=None, debeta_pool_ema=None) -> dict:
    """Run the SAME scoring main runs (score_uids + Pareto distribute) on the
    shadow's structures. Mutates kappa/activity/pnl factors in place exactly as
    main's reward does, keeping the shadow in lockstep.

    GenTRX inputs are main-side state: shipped in via score_at (cutover mode)
    or empty (shadow mode — the trading comparison is unaffected either way;
    the EMA state round-trips through main so the child stays stateless).

    Returns {'trading', 'gentrx', 'factors', 'gentrx_ema'} — everything main
    adopts in cutover mode.

    Args:
        shadow: The shadow's replica structures.
        sim_ts: Simulation timestamp of the boundary being scored.
        deregs: Uids deregistered this round.
        gentrx_scores: Live GenTRX scores.
        gentrx_ema: Carried GenTRX EMA.
        trading_ema: Carried trading EMA.
        trading_ema_n: Carried per-uid EMA counts.
        trading_ema_ts: Carried per-uid EMA timestamps.
        debeta_pool_ema: Carried smoothed making term and share, under the proportional making pool.

    Returns:
        The shadow's scoring result for parity comparison.
    """
    from taos.im.config import debeta_dial
    from taos.im.validator.reward import (apply_track_record_ema, compute_debeta_scores, making_pool_inputs,
                                          pool_pay_vector, score_uids, skill_bar, smoothed_skill_share)

    shadow.deregistered_uids = list(deregs)
    # The presence gate's absent set is main-side knowledge (query outcomes), shipped with the inputs.
    shadow.debeta_absent = (set(int(u) for u in absent) if absent is not None else None)
    # The graded presence share, main-side knowledge too, shipped the same way.
    shadow.debeta_presence_shares = ({int(u): float(v) for u, v in presence.items()} if presence is not None else None)
    all_uids = list(range(shadow.effective_max_uids))
    _ema = dict(gentrx_ema or {})
    validator_data = {
        'kappa_values': shadow.kappa_values,
        'kappa_cache': shadow.kappa_cache,
        'activity_factors': shadow.activity_factors,
        'pnl_factors': shadow.pnl_factors,
        'roundtrip_volumes': shadow.roundtrip_volumes,
        'realized_pnl_history': shadow.realized_pnl_history,
        'config': shadow.scoring_config,
        'simulation_config': shadow.simulation_config,
        'simulation_timestamp': sim_ts,
        'uids': all_uids,
        'deregistered_uids': shadow.deregistered_uids,
        'device': 'cpu',
        'gentrx_scores': dict(gentrx_scores or {}),
        'gentrx_ema': _ema,
        # Main's get_rewards ships this key from its own accumulators; the replica omitted it, which
        # (with the config duck also lacking scoring.debeta) silently pinned cutover scoring to the
        # legacy path. The shadow owns the same fill-stream accumulators via the trade.py update path.
        'debeta_scores': compute_debeta_scores(shadow),
        # Read AFTER the line above, which stashes them on the shadow (dict literals evaluate in source
        # order). Main adopts this child's kappa_values for publishing in cutover mode, and the per-uid
        # publisher reads the decomposition from these keys: without them every rank, raw leg, CP
        # factor, w_make and floor is None on the wire and num_scored_books reads 0 for every miner.
        'debeta_detail': getattr(shadow, 'debeta_detail', {}) or {},
        'debeta_floor': getattr(shadow, 'debeta_floor', None),
        'debeta_w_make': getattr(shadow, 'debeta_w_make', None),
    }
    trading_scores, gentrx_scores_out = score_uids(validator_data)
    # Track-record EMA: same pre-round state main ships (parity contract with
    # reward.get_rewards); the child stays stateless — the state round-trips.
    _tema = dict(trading_ema or {})
    _tema_n = dict(trading_ema_n or {})
    _tema_ts = trading_ema_ts
    _hl = (shadow.scoring_config.get('scoring', {}) or {}).get('score_ema_halflife', 0)
    _pema = {k: dict(v or {}) for k, v in (debeta_pool_ema or {}).items()}
    _n_snap, _last_snap = dict(_tema_n), _tema_ts
    if _hl and _hl > 0:
        # Parity with main: fresh miners still in min_lookback (no valid Kappa) keep k=0.
        _scorable = {uid for uid in all_uids if (shadow.kappa_values.get(uid) or {}).get('scorable')}
        trading_scores, _tema_ts = apply_track_record_ema(
            trading_scores, all_uids, shadow.deregistered_uids,
            sim_ts, _hl, _tema, _tema_n, _tema_ts, _scorable)
    # Identical allocation pipeline to main's get_rewards: the proportional making pool when the
    # dial is on (same helpers, same auxiliary-EMA schedule), otherwise soft floor THEN Pareto.
    # (The floor was missing here — a pre-existing divergence whenever
    # rewarding.floor.enabled is on; a no-op when it is off.)
    _dcfg = ((shadow.scoring_config.get('scoring', {}) or {}).get('debeta') or {})
    _pool_mode = str(debeta_dial(_dcfg, 'making_pool'))
    _pool = max(0.0, min(1.0, float(debeta_dial(_dcfg, 'weight')) * float(debeta_dial(_dcfg, 'w_make'))))
    # computed, smoothed and published under BOTH settings, exactly as main does, so the state main
    # adopts in cutover mode stays warm and the gauges exist whichever way the dial is set
    _ladder, _term, _share = making_pool_inputs(
        getattr(shadow, 'debeta_detail', {}) or {}, all_uids, trading_scores,
        float(debeta_dial(_dcfg, 'weight')), float(debeta_dial(_dcfg, 'w_make')))
    # as in main: under a per-class dial the class-mixed making vector is the one smoothed and paid
    _class_shares = getattr(shadow, '_debeta_class_shares', None)
    if _class_shares:
        _share = {uid: float(_class_shares[0].get(uid, 0.0)) for uid in all_uids}
    if _hl and _hl > 0 and _pool > 0.0:
        for _k, _vec in (("term", _term), ("share", _share)):
            _st = dict(_pema.get(_k) or {})
            _sm, _ = apply_track_record_ema(
                _vec, all_uids, shadow.deregistered_uids,
                sim_ts, _hl, _st, dict(_n_snap), _last_snap, _scorable)
            _pema[_k] = _st
            _vec.update(_sm)
        _ladder = {uid: max(0.0, float(trading_scores[uid]) - float(_term[uid])) for uid in all_uids}
    _share_tot = sum(_share.values())
    for uid in all_uids:
        _kv = shadow.kappa_values.get(uid)
        if _kv is not None:
            _kv['making_share'] = (float(_share[uid]) / _share_tot) if _share_tot > 0 else 0.0
            _kv['ladder_input'] = float(_ladder[uid])
    _skill_sm = None
    if _hl and _hl > 0 and _pool > 0.0 and _pool_mode == "proportional_both":
        _skill_sm = smoothed_skill_share(_dcfg, getattr(shadow, 'debeta_detail', {}) or {}, all_uids, _class_shares,
                                         _pema, shadow.deregistered_uids, sim_ts, _hl, _n_snap, _last_snap, _scorable,
                                         skill_min_books=skill_bar(shadow))
    distributed = pool_pay_vector(
        _pool_mode, _pool, getattr(shadow, 'debeta_detail', {}) or {}, all_uids, _ladder, trading_scores, _share,
        shadow.scoring_config, skill_bar(shadow), class_shares=_class_shares,
        skill_share=_skill_sm)
    return {
        'trading': [float(x) for x in distributed.tolist()],
        'gentrx': [float(gentrx_scores_out[uid]) for uid in all_uids],
        'factors': {
            'kappa_values': shadow.kappa_values,
            'activity_factors': shadow.activity_factors,
            'pnl_factors': shadow.pnl_factors,
        },
        'gentrx_ema': validator_data.get('gentrx_ema', {}),
        'trading_ema': _tema,
        'trading_ema_n': _tema_n,
        'trading_ema_ts': _tema_ts,
        'debeta_pool_ema': _pema,
    }


def child_save_validator_state(shadow, light: dict, path: str) -> int:
    """Write the validator-state file from the child's replica structures plus
    main's shipped light fields — the exact dict persistence.build_validator_state
    produces, stream-packed at the same depth and atomically replaced, so the
    file is indistinguishable from a main-side save. The ongoing parity digests

    Args:
        shadow: The child's replica structures.
        light: Main-only fields shipped for the save.
        path: Destination state-file path.
    are the proof the heavy subtrees match main's. Returns bytes written."""
    import msgpack
    from taos.im.validator.persistence import (
        _SAVE_STREAM_DEPTH, _stream_pack, build_debeta_state,
        snapshot_inventory_history, snapshot_realized_pnl_history,
        snapshot_volume_sums, snapshot_trade_volumes,
        snapshot_roundtrip_volumes, snapshot_open_positions,
    )
    vols = snapshot_volume_sums(shadow)
    data = {
        "step": light["step"],
        "simulation_timestamp": light["simulation_timestamp"],
        "hotkeys": light["hotkeys"],
        "scores": light["scores"],
        "gentrx_scores": light["gentrx_scores"],
        "activity_factors": shadow.activity_factors,
        "pnl_factors": shadow.pnl_factors,
        "inventory_history": snapshot_inventory_history(shadow),
        "kappa_values": shadow.kappa_values,
        "realized_pnl_history": snapshot_realized_pnl_history(shadow),
        "open_positions": snapshot_open_positions(shadow),
        "unnormalized_scores": light["unnormalized_scores"],
        "deregistered_uids": light["deregistered_uids"],
        "trading_score_ema": light.get("trading_score_ema", {}),
        "trading_score_ema_ts": light.get("trading_score_ema_ts"),
        "trading_score_ema_n": light.get("trading_score_ema_n", {}),
        # the proportional making pool's smoothed term and share, as main's save writes them
        "debeta_pool_ema": light.get("debeta_pool_ema", {}),
        "trade_volumes": snapshot_trade_volumes(shadow),
        "roundtrip_volumes": snapshot_roundtrip_volumes(shadow),
        "volume_sums": vols["volume_sums"],
        "maker_volume_sums": vols["maker_volume_sums"],
        "taker_volume_sums": vols["taker_volume_sums"],
        "self_volume_sums": vols["self_volume_sums"],
        "roundtrip_volume_sums": vols["roundtrip_volume_sums"],
        # Same block, same function as main's build_validator_state: this file is what a restart loads,
        # and without it the de-beta windows restarted from zero on every restart with the shadow on.
        **build_debeta_state(shadow),
        "miner_stats": light["miner_stats"],
        "miner_presence": light.get("miner_presence", {}),
    }
    packer = msgpack.Packer(use_bin_type=True)
    tmp = f"{path}.tmp.shadow"
    try:
        with open(tmp, "wb", buffering=1024 * 1024) as f:
            total = _stream_pack(packer, f.write, data, _SAVE_STREAM_DEPTH)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    return total


def _send_frame(sock, obj) -> None:
    data = pickle.dumps(obj, protocol=5)
    sock.sendall(struct.pack("Q", len(data)) + data)


def _recv_exact(sock, n: int) -> bytes:
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise EOFError("shadow socket closed")
        buf += chunk
    return buf


def _recv_frame(sock):
    (size,) = struct.unpack("Q", _recv_exact(sock, 8))
    return pickle.loads(_recv_exact(sock, size))


def apply_state_bytes(shadow: ShadowState, raw: bytes) -> int:
    """Parse the raw msgpack state exactly as the engine does and apply the same
    accounting. Returns the state timestamp."""
    import msgpack
    from taos.im.protocol import MarketSimulationStateUpdate
    from taos.im.validator.multiasset_state import flatten_multiasset_state
    from taos.im.validator.trade import update_trade_volumes

    d = msgpack.unpackb(raw, raw=False, use_list=True, strict_map_key=False)
    # Main flattens a multi-asset request (backgrounds -> instances -> books) in the engine's receive path
    # before it accounts for the round; the replica replays the bytes from before that step, so it must
    # flatten too or it sees no books at all under the multi-asset layout (2 October 2026).
    d, _ = flatten_multiasset_state(d)
    state = MarketSimulationStateUpdate.parse_dict(d)
    shadow.step += 1
    update_trade_volumes(shadow, state)
    # Derive resets from the state itself (same data main scans) and apply at
    # the same position — immediately after this round's update.
    validator_uid = getattr(shadow, 'validator_uid', None)
    if validator_uid is not None:
        from taos.im.validator.trade import collect_reset_uids, reset_agent_histories
        pending, _failed = collect_reset_uids(state, validator_uid)
        if pending:
            book_ids = list(shadow.simulation_config.get('book_ids') or range(shadow.simulation_config['book_count']))
            for uid in sorted(pending):
                reset_agent_histories(shadow, uid, book_ids)
            print(f"[SHADOW] resets applied (derived): {sorted(pending)}", flush=True)
    return state.timestamp


def _shadow_child_main(sock, cores, parity_ns):
    """Child process: INIT -> apply teed rounds -> parity digests back.

    Shadow-reward protocol: after applying an interval-boundary round X (where
    main also scores), the child PAUSES applies — side-buffering later state
    frames — until main's ("score_at", (X, sim_ts_used, deregs)) frame arrives
    (sent after main's reward completes, carrying the exact live inputs main
    used). It then scores on histories that are exactly post-X, ships the
    trading scores back, and drains the side buffer. A missing score_at (main
    skipped/errored its reward) times out and applies continue.
    """
    import queue as _queue

    try:
        if cores:
            try:
                os.sched_setaffinity(0, set(cores))
            except OSError:
                pass
        print(f"[SHADOW] child up (pid {os.getpid()}, cores {cores or 'unpinned'})", flush=True)

        frames = _queue.Queue()

        def _drain_socket():
            try:
                while True:
                    frames.put(_recv_frame(sock))
            except (EOFError, OSError):
                frames.put(("stop", None))

        threading.Thread(target=_drain_socket, daemon=True, name="shadow-sock-drain").start()

        shadow = None
        base_ts = None
        init_parts = {}
        buffered = []       # pre-INIT state frames
        side_buffer = []    # states arriving while awaiting a score_at

        def _side_push(ts, raw):
            """Queue a frame that arrived while a score was awaited, BOUNDED.

            This queue had no cap while its sibling `buffered` has had one all along, and both hold
            the same thing: whole rounds of raw state, megabytes each. A scoring round that stalls
            therefore accumulated them until the box noticed -- which is the validator-restart memory
            spike long blamed on the metagraph sync worker, a child that ships a 0.16MB pickle and
            peaks around 125MB.

            A DROP IS NOT FREE, and it is not the same as the pre-INIT queue's drop. State frames are
            applied CUMULATIVELY -- apply_state_bytes advances shadow.step and accumulates trade
            volumes -- so a dropped frame leaves this shadow permanently short of a round and it
            diverges from main from that point on. `buffered` can drop safely because those frames
            precede INIT and the INIT snapshot supersedes them; these do not.

            The divergence is caught rather than hidden: the parent's parity check sees the mismatch
            and calls request_reinit(), and the shadow rebuilds from a fresh INIT. That is the
            system's own self-heal path, and it is why this cap can be a drop at all. It is expensive,
            and enough repeats trip the reinit storm breaker, which suspends the shadow until the
            validator restarts -- so the cap is set high enough to fire only in genuine pathology, not
            in the ordinary course of a slow round.
            """
            side_buffer.append((ts, raw))
            if len(side_buffer) > SHADOW_SIDE_BUFFER_MAX:
                print(
                    f"[SHADOW] score overdue — dropping oldest of {len(side_buffer)} side-buffered "
                    f"round(s); this shadow will diverge and re-INIT. Main scoring is unaffected.",
                    flush=True,
                )
                side_buffer.pop(0)
        awaiting_score_at = None
        pending_score_inputs = {}   # eager inputs by boundary ts
        applied = 0
        last_applied_ts = 0
        # A state that steps back (at or below the INIT base, or behind the last applied state) is held until the
        # next frame says what main did with it. The listener tees a state before main's tick handling sees it, so
        # when that state is what makes main open a new run, its sim_start reaches the child AFTER it, while main
        # shifts first and applies it second.
        held = None
        pending_save = None         # (expect_ts, path, light, mono_deadline)

        def _maybe_save():
            # Fire the pending save once the replica has caught up to its
            # snapshot point (states arrive FIFO, so >= means "at or one past").
            nonlocal pending_save
            if pending_save is None or shadow is None:
                return
            expect_ts, path, light, deadline = pending_save
            if last_applied_ts >= expect_ts:
                pending_save = None
                if last_applied_ts > expect_ts:
                    print(f"[SHADOW] save snapshot at ts={last_applied_ts} > requested {expect_ts}", flush=True)
                t0 = time.time()
                try:
                    nbytes = child_save_validator_state(shadow, light, path)
                    _send_frame(sock, ("save_done", (expect_ts, nbytes, time.time() - t0)))
                    print(f"[SHADOW] validator state saved ({nbytes/1e6:.1f}MB, {time.time()-t0:.2f}s)", flush=True)
                except Exception as e:
                    try:
                        _send_frame(sock, ("save_err", (expect_ts, f"{type(e).__name__}: {e}")))
                    except Exception:
                        pass
            elif time.monotonic() > deadline:
                pending_save = None
                try:
                    _send_frame(sock, ("save_err", (expect_ts, f"snapshot point never reached (applied={last_applied_ts})")))
                except Exception:
                    pass

        def _score_and_send(s_ts, sim_ts, deregs, gtx_scores, gtx_ema,
                            t_ema=None, t_ema_n=None, t_ema_ts=None, absent=None, presence=None,
                            pool_ema=None):
            t0 = time.time()
            try:
                result = shadow_score(shadow, sim_ts, deregs, gtx_scores, gtx_ema,
                                      t_ema, t_ema_n, t_ema_ts, absent=absent, presence=presence,
                                      debeta_pool_ema=pool_ema)
                _send_frame(sock, ("scores", (s_ts, result, time.time() - t0)))
            except Exception as e:
                import traceback
                print(f"[SHADOW] scoring failed at ts={s_ts}: {e}\n{traceback.format_exc()}", flush=True)
                try:
                    _send_frame(sock, ("scores_err", (s_ts, f"{type(e).__name__}: {e}")))
                except Exception:
                    pass

        def _apply_one(ts, raw):
            nonlocal applied, awaiting_score_at, last_applied_ts
            t0 = time.time()
            apply_state_bytes(shadow, raw)
            applied += 1
            last_applied_ts = ts
            if ts % parity_ns == 0:
                _send_frame(sock, ("parity", (ts, compute_parity_components(shadow), parity_vectors(shadow), applied, time.time() - t0)))
            if shadow.scoring_interval and ts % shadow.scoring_interval == 0:
                eager = pending_score_inputs.pop(ts, None)
                if eager is not None:
                    # eager path: inputs arrived at tee time — compute NOW
                    # (during main's lock-queue delay) with no boundary pause.
                    _score_and_send(ts, *eager)
                else:
                    awaiting_score_at = (ts, time.monotonic())

        def _resolve_held(shifted):
            """Settle the held state: after a shift it is the new run's first state and is applied; with no
            shift it is handled as it always was, dropped at or below the INIT base, applied above it."""
            nonlocal held
            if held is None:
                return
            h_ts, h_raw, below_base = held
            held = None
            if below_base and not shifted:
                return
            if awaiting_score_at is not None:
                _side_push(h_ts, h_raw)
            else:
                _apply_one(h_ts, h_raw)

        while True:
            try:
                kind, payload = frames.get(timeout=5.0)
            except _queue.Empty:
                _maybe_save()
                if awaiting_score_at and time.monotonic() - awaiting_score_at[1] > 120.0:
                    print(f"[SHADOW] score_at for ts={awaiting_score_at[0]} never arrived — skipping score", flush=True)
                    awaiting_score_at = None
                    pending, side_buffer = side_buffer, []
                    for ts, raw in pending:
                        if awaiting_score_at is None:
                            _apply_one(ts, raw)
                        else:
                            _side_push(ts, raw)
                continue
            if held is not None and kind != "sim_start":
                _resolve_held(False)
            if kind == "stop":
                break
            if kind == "init_part":
                name, blob = payload
                init_parts[name] = pickle.loads(blob)
            elif kind == "init_done":
                base_ts, knobs = payload
                shadow = ShadowState(_rebuild_structs(init_parts), knobs)
                # Child-local loky sizing: score on the child's own cores (or a
                # small unpinned pool when it has no dedicated slice).
                kcfg = shadow.scoring_config['scoring']['kappa']
                kcfg['reward_cores'] = list(cores) if cores else []
                if not cores and kcfg.get('parallel_workers') == -1:
                    # -1 means one loky worker per core; with no dedicated slice
                    # fall back to a small unpinned pool. Explicit 0 (serial)
                    # and positive counts pass through unchanged.
                    kcfg['parallel_workers'] = 2
                init_parts = None
                replayed = 0
                for ts, raw in buffered:
                    if ts > base_ts and awaiting_score_at is None:
                        _apply_one(ts, raw)
                        replayed += 1
                    elif ts > base_ts:
                        _side_push(ts, raw)
                buffered = []
                print(f"[SHADOW] init applied base_ts={base_ts} (replayed {replayed} buffered rounds)", flush=True)
            elif kind == "state":
                ts, raw = payload
                if shadow is None:
                    buffered.append((ts, raw))
                    if len(buffered) > 64:
                        print("[SHADOW] init overdue — dropping oldest buffered round", flush=True)
                        buffered.pop(0)
                    continue
                if ts <= base_ts or ts < last_applied_ts:
                    held = (ts, raw, ts <= base_ts)
                    continue
                if awaiting_score_at is not None:
                    _side_push(ts, raw)
                    continue
                _apply_one(ts, raw)
            elif kind == "sim_start":
                old_ts, new_ts = payload
                if shadow is not None:
                    # States teed before this shift are the old run's, and main applied them before shifting: the
                    # child applies them first too. A boundary awaited among them is void, no score follows a run
                    # change.
                    awaiting_score_at = None
                    pending, side_buffer = side_buffer, []
                    for ts, raw in pending:
                        _apply_one(ts, raw)
                        awaiting_score_at = None
                    from taos.im.validator.trade import shift_simulation_histories
                    shift_simulation_histories(
                        shadow, old_ts, new_ts,
                        book_count=shadow.simulation_config['book_count'],
                        volume_decimals=shadow.simulation.volumeDecimals,
                        lookback=shadow.config.scoring.kappa.lookback,
                        volume_assessment_period=shadow.config.scoring.activity.trade_volume_assessment_period,
                        miner_wealth=shadow.simulation.miner_wealth,
                        effective_max_uids=shadow.effective_max_uids,
                        book_ids=shadow.simulation_config.get('book_ids'),
                    )
                    # The new run restarts near ts=0, so the old-run guard must not drop its frames; the state that
                    # triggered this shift, if main noticed the run change while handling it, follows the shift.
                    base_ts = -1
                    awaiting_score_at = None
                    _resolve_held(True)
                    print(f"[SHADOW] sim_start applied ({old_ts} -> {new_ts})", flush=True)
            elif kind == "resets":
                if shadow is not None:
                    from taos.im.validator.trade import reset_agent_histories
                    book_ids = list(shadow.simulation_config.get('book_ids') or range(shadow.simulation_config['book_count']))
                    for uid in payload:
                        reset_agent_histories(shadow, uid, book_ids)
                    print(f"[SHADOW] resets applied: {payload}", flush=True)
            elif kind == "reinit":
                shadow = None
                base_ts = None
                init_parts = {}
                buffered = []
                side_buffer = []
                awaiting_score_at = None
                pending_save = None
                print("[SHADOW] state dropped — awaiting fresh INIT", flush=True)
            elif kind == "save":
                expect_ts, path, light = payload
                if shadow is None:
                    try:
                        _send_frame(sock, ("save_err", (expect_ts, "not initialized")))
                    except Exception:
                        pass
                else:
                    pending_save = (expect_ts, path, light, time.monotonic() + 60.0)
            elif kind == "score_inputs":
                s_ts, sim_ts, deregs, gtx_scores, gtx_ema = payload[:5]
                t_ema = payload[5] if len(payload) > 5 else None
                t_ema_n = payload[6] if len(payload) > 6 else None
                t_ema_ts = payload[7] if len(payload) > 7 else None
                absent = payload[8] if len(payload) > 8 else None
                presence = payload[9] if len(payload) > 9 else None
                pool_ema = payload[10] if len(payload) > 10 else None
                if shadow is not None and awaiting_score_at is not None and awaiting_score_at[0] == s_ts:
                    # inputs arrived after the boundary was applied — score now
                    awaiting_score_at = None
                    _score_and_send(s_ts, sim_ts, deregs, gtx_scores, gtx_ema,
                                    t_ema, t_ema_n, t_ema_ts, absent, presence, pool_ema)
                    pending, side_buffer = side_buffer, []
                    for ts, raw in pending:
                        if awaiting_score_at is None:
                            _apply_one(ts, raw)
                        else:
                            _side_push(ts, raw)
                else:
                    pending_score_inputs[s_ts] = (sim_ts, deregs, gtx_scores, gtx_ema,
                                                  t_ema, t_ema_n, t_ema_ts, absent, presence, pool_ema)
                    while len(pending_score_inputs) > 4:
                        pending_score_inputs.pop(next(iter(pending_score_inputs)))
            elif kind == "score_at":
                s_ts, sim_ts, deregs = payload[0], payload[1], payload[2]
                gentrx_scores = payload[3] if len(payload) > 3 else None
                gentrx_ema = payload[4] if len(payload) > 4 else None
                t_ema = payload[5] if len(payload) > 5 else None
                t_ema_n = payload[6] if len(payload) > 6 else None
                t_ema_ts = payload[7] if len(payload) > 7 else None
                absent = payload[8] if len(payload) > 8 else None
                presence = payload[9] if len(payload) > 9 else None
                pool_ema = payload[10] if len(payload) > 10 else None
                if shadow is None or awaiting_score_at is None or awaiting_score_at[0] != s_ts:
                    print(f"[SHADOW] unexpected score_at ts={s_ts} (awaiting={awaiting_score_at}) — ignored", flush=True)
                    if shadow is not None:
                        _send_frame(sock, ("scores_err", (s_ts, "not at boundary")))
                else:
                    awaiting_score_at = None
                    _score_and_send(s_ts, sim_ts, deregs, gentrx_scores, gentrx_ema,
                                    t_ema, t_ema_n, t_ema_ts, absent, presence, pool_ema)
                    pending, side_buffer = side_buffer, []
                    for ts, raw in pending:
                        if awaiting_score_at is None:
                            _apply_one(ts, raw)
                        else:
                            _side_push(ts, raw)
            _maybe_save()
    except (EOFError, OSError):
        pass
    except Exception as e:
        import traceback
        print(f"[SHADOW] child fatal: {e}\n{traceback.format_exc()}", flush=True)
    finally:
        try:
            sock.close()
        except Exception:
            pass


class _ReinitStorm:
    """Sliding-window counter behind the storm breaker: `hit(now)` records a re-INIT and answers whether
    `n` of them now sit inside `window` seconds. n <= 0 disables."""

    def __init__(self, n: int, window: float):
        self.n = int(n)
        self.window = float(window)
        self._times = deque()

    @property
    def count(self) -> int:
        return len(self._times)

    def hit(self, now: float) -> bool:
        if self.n <= 0:
            return False
        self._times.append(now)
        while self._times and now - self._times[0] > self.window:
            self._times.popleft()
        return len(self._times) >= self.n


class ScoringShadow:
    """Owner-side handle: tee stream, one-time INIT, parity ring + comparison."""

    def __init__(self, cores=None, parity_ns=SHADOW_PARITY_NS, child_fn=_shadow_child_main):
        self.parity_ns = parity_ns
        self._cores = list(cores) if cores else []
        self._child_fn = child_fn
        self._ctx = multiprocessing.get_context("spawn")
        self._sock = None
        self._proc = None
        self._reader = None
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="scoring_shadow")
        self._pending = 0
        self._pending_lock = threading.Lock()
        self._dropped = 0
        self.initialized = False
        # Two-sided rings: the child usually computes AHEAD of main (it applies
        # a round the moment it is teed, while main's _reward runs seconds later
        # behind _reward_lock) — so whichever side arrives first stashes its
        # value and the second side completes the comparison.
        self._ring = {}
        self._score_ring = {}
        self._pending_child_parity = {}
        self._pending_child_scores = {}
        self._score_futures = {}
        # Eager scoring (cutover): inputs shipped at boundary-tee time so the
        # child computes DURING main's lock-queue delay; results arriving before
        # main asks are stashed here and returned instantly by request_scores.
        self._eager_inputs = {}
        self._score_results = {}
        # Save offload (Stage B v2): the child writes the validator-state file
        # from its replica; main only ships the light main-only fields.
        self._save_futures = {}
        self._last_teed_ts = 0
        self.matches = 0
        self.mismatches = 0
        self.score_matches = 0
        self.score_mismatches = 0
        self._consecutive_mismatches = 0
        self.reinits = 0
        # Set by the storm breaker: every main-facing method is then inert (no tee, no INIT, no scores,
        # no save offload) and main scores and saves in-process until the validator restarts.
        self.cutover_suspended = False
        self._storm = _ReinitStorm(SHADOW_REINIT_STORM_N, SHADOW_REINIT_STORM_S)
        self._last_drop_log = 0.0

    def start(self) -> None:
        """Start the shadow process and its feed."""
        import socket as _socket
        self._sock, child_sock = _socket.socketpair()
        # daemon=False: the child spawns loky workers for shadow scoring, which
        # daemonic processes cannot. Orphan safety comes from the socket: when
        # the parent dies the child's recv EOFs and its loop exits cleanly.
        self._proc = self._ctx.Process(
            target=self._child_fn,
            args=(child_sock, self._cores, self.parity_ns),
            daemon=False,
            name="scoring-shadow",
        )
        self._proc.start()
        child_sock.close()
        self._reader = threading.Thread(target=self._read_loop, daemon=True, name="shadow-parity-reader")
        self._reader.start()

    def is_alive(self) -> bool:
        """Whether the shadow process is currently running."""
        return self._proc is not None and self._proc.is_alive()

    # ── main -> child ────────────────────────────────────────────────────────

    def tee(self, raw: bytes, timestamp: int) -> None:
        """Fire-and-forget send of one round's raw state bytes (FIFO executor).
        Bounded: if the child stalls, frames are dropped (shadow-only — never

        Args:
            raw: One round's raw state bytes.
            timestamp: The round timestamp.
        block or bloat the main process for the shadow's sake)."""
        if self.cutover_suspended or not self.is_alive():
            return
        with self._pending_lock:
            if self._pending >= 8:
                self._dropped += 1
                dropped = self._dropped
                now = time.time()
                log_it = now - self._last_drop_log >= 30.0
                if log_it:
                    self._last_drop_log = now
            else:
                self._pending += 1
                dropped = 0
                log_it = False
        if dropped:
            # A dropped round is a guaranteed parity MISMATCH and re-INIT downstream; until 0.6.1 the
            # only trace was the dropped= counter on a MATCH line, which a diverging child never prints.
            if log_it:
                import bittensor as bt
                bt.logging.warning(
                    f"[SHADOW] tee dropped frame ts={timestamp}: the child is not draining "
                    f"({self._pending} sends pending, {dropped} dropped so far). Its replica now lacks "
                    f"this round; expect a parity MISMATCH and a re-INIT."
                )
            return

        def _send():
            try:
                _send_frame(self._sock, ("state", (timestamp, raw)))
            except Exception:
                pass
            finally:
                with self._pending_lock:
                    self._pending -= 1

        self._executor.submit(_send)
        self._last_teed_ts = timestamp

    def emit_sim_start(self, old_ts: int, new_ts: int) -> None:
        """Simulation restart: the child must run the same history shift.

        Args:
            old_ts: The previous simulation's time base.
            new_ts: The new simulation's time base.
        FIFO-ordered with the state tee (old-sim frames before, new-sim after)."""
        if not self.is_alive():
            return

        def _send():
            try:
                _send_frame(self._sock, ("sim_start", (old_ts, new_ts)))
            except Exception:
                pass

        self._executor.submit(_send)

    def emit_resets(self, uids: list) -> None:
        """Deregistration resets: the child zeroes the same UIDs' histories."""
        if not self.is_alive():
            return

        def _send():
            try:
                _send_frame(self._sock, ("resets", list(uids)))
            except Exception:
                pass

        self._executor.submit(_send)

    def tee_score_inputs(self, timestamp: int, sim_ts: int, deregs: list,
                         gentrx_scores=None, gentrx_ema=None,
                         trading_ema=None, trading_ema_n=None, trading_ema_ts=None, absent=None,
                         presence=None, debeta_pool_ema=None) -> None:
        """Eager scoring: ship the boundary round's scoring inputs at TEE time,
        so the child computes during the seconds main's _reward spends queued
        behind _reward_lock — request_scores then collects a (usually) finished
        result instead of holding the lock through the full compute. The same

        Args:
            timestamp: Tee timestamp.
            sim_ts: Simulation timestamp of the boundary.
            deregs: Uids deregistered this round.
            gentrx_scores: Live GenTRX scores.
            gentrx_ema: Carried GenTRX EMA.
            trading_ema: Carried trading EMA.
            trading_ema_n: Carried per-uid EMA counts.
            trading_ema_ts: Carried per-uid EMA timestamps.
            debeta_pool_ema: Carried smoothed making term and share, under the proportional making pool.
        inputs are recorded for the verify pin (eager_inputs_for)."""
        if not self.is_alive() or not self.initialized:
            return
        pin = {
            'simulation_timestamp': sim_ts,
            'deregistered_uids': list(deregs),
            'gentrx_scores': dict(gentrx_scores or {}),
            'gentrx_ema': dict(gentrx_ema or {}),
            'trading_ema': dict(trading_ema or {}),
            'trading_ema_n': dict(trading_ema_n or {}),
            'trading_ema_ts': trading_ema_ts,
            'absent': (sorted(int(u) for u in absent) if absent is not None else None),
            'presence': ({int(u): float(v) for u, v in presence.items()} if presence is not None else None),
            'debeta_pool_ema': {str(k): dict(v or {}) for k, v in (debeta_pool_ema or {}).items()},
        }
        self._stash(self._eager_inputs, timestamp, pin, 4)

        def _send():
            try:
                _send_frame(self._sock, (
                    "score_inputs",
                    (timestamp, sim_ts, pin['deregistered_uids'],
                     pin['gentrx_scores'], pin['gentrx_ema'],
                     pin['trading_ema'], pin['trading_ema_n'], pin['trading_ema_ts'], pin['absent'],
                     pin['presence'], pin['debeta_pool_ema']),
                ))
            except Exception:
                pass

        self._executor.submit(_send)

    def eager_inputs_for(self, timestamp: int):
        """The exact inputs shipped for this boundary (verify must pin to these),
        or None if the boundary wasn't eagerly dispatched."""
        return self._eager_inputs.get(timestamp)

    def request_scores(self, timestamp: int, sim_ts: int, deregs: list,
                       gentrx_scores=None, gentrx_ema=None, timeout: float = 45.0,
                       eager: bool = False,
                       trading_ema=None, trading_ema_n=None, trading_ema_ts=None,
                       absent=None, presence=None, debeta_pool_ema=None):
        """Cutover mode: collect this boundary's full scoring result, blocking
        until it arrives (call via run_in_executor — the wait is GIL-free).
        eager=True means the inputs were already shipped at tee time (the child
        is computing or done — do not send a score_at); otherwise the score_at
        pull path runs as before. Returns the result dict {'trading','gentrx',
        'factors','gentrx_ema'} or None on ANY failure — the caller falls back
        to the in-process get_rewards and a dead child is respawned.

        Args:
            timestamp: The boundary timestamp.
            sim_ts: Simulation timestamp of the boundary.
            deregs: Uids deregistered this round.
            gentrx_scores: Live GenTRX scores.
            gentrx_ema: Carried GenTRX EMA.
            timeout: Wait bound in seconds.
            eager: Inputs were already shipped at tee time.
            trading_ema: Carried trading EMA.
            trading_ema_n: Carried per-uid EMA counts.
            trading_ema_ts: Carried per-uid EMA timestamps.
            debeta_pool_ema: Carried smoothed making term and share, under the proportional making pool.

        Returns:
            The child's full scoring result.
        """
        import concurrent.futures
        if self.cutover_suspended:
            return None
        ready = self._score_results.pop(timestamp, None)
        if ready is not None:
            return ready
        if not self.is_alive():
            try:
                self.start()
                self.initialized = False  # fresh child needs a new INIT
            except Exception:
                pass
            return None
        if not self.initialized:
            return None
        fut = concurrent.futures.Future()
        self._score_futures[timestamp] = fut

        if not eager:
            def _send():
                try:
                    _send_frame(self._sock, (
                        "score_at",
                        (timestamp, sim_ts, list(deregs),
                         dict(gentrx_scores or {}), dict(gentrx_ema or {}),
                         dict(trading_ema or {}), dict(trading_ema_n or {}), trading_ema_ts,
                         (sorted(int(u) for u in absent) if absent is not None else None),
                         ({int(u): float(v) for u, v in presence.items()} if presence is not None else None),
                         {str(k): dict(v or {}) for k, v in (debeta_pool_ema or {}).items()}),
                    ))
                except Exception:
                    pass

            self._executor.submit(_send)
        try:
            return fut.result(timeout=timeout)
        except Exception:
            return None
        finally:
            self._score_futures.pop(timestamp, None)

    def request_save(self, path: str, light: dict):
        """Save offload: ask the child to write the validator-state file from
        its replica once it has applied the last teed round. `light` carries
        the main-only fields (step/scores/hotkeys/miner_stats/...). Returns
        (expect_ts, Future) — the future resolves to (bytes, child_io_secs) on
        success or None on child failure — or None when the offload is

        Args:
            path: Destination state-file path.
            light: Main-only fields (step/scores/hotkeys/miner_stats/...).

        Returns:
            tuple: ``(expect_ts, Future)``; the future resolves to ``(bytes, child_io_secs)``.
        unavailable (caller falls back to the in-process save path)."""
        if not self.is_alive() or not self.initialized or not self._last_teed_ts:
            return None
        import concurrent.futures
        expect_ts = self._last_teed_ts
        fut = concurrent.futures.Future()
        self._save_futures[expect_ts] = fut

        def _send():
            try:
                _send_frame(self._sock, ("save", (expect_ts, path, light)))
            except Exception:
                pass

        self._executor.submit(_send)
        return expect_ts, fut

    def request_reinit(self) -> None:
        """Self-heal: drop the child's state and re-run INIT on the next round
        (triggered automatically after consecutive parity mismatches). Counted
        by the storm breaker: SHADOW_REINIT_STORM_N of these inside
        SHADOW_REINIT_STORM_S seconds suspend the service instead."""
        import bittensor as bt
        if self.cutover_suspended:
            return
        self.reinits += 1
        if self._storm.hit(time.monotonic()):
            self.suspend(f"{self._storm.count} re-INITs within {self._storm.window:.0f}s")
            return
        bt.logging.warning(f"[SHADOW] requesting re-INIT (parity self-heal, #{self.reinits})")
        self.initialized = False
        self._ring.clear()
        self._score_ring.clear()
        self._pending_child_parity.clear()
        self._pending_child_scores.clear()

        def _send():
            try:
                _send_frame(self._sock, ("reinit", None))
            except Exception:
                pass

        self._executor.submit(_send)

    def suspend(self, reason: str) -> None:
        """Storm breaker: the parity self-heal is not converging, so stop paying for it. The child
        drops its state and gets nothing further; every main-facing call becomes a no-op (request_scores
        and request_save answer None, so main's existing in-process fallbacks take over) until the
        validator restarts. Pending score waits are released with None so a boundary mid-wait falls
        back instead of running out its timeout."""
        import bittensor as bt
        if self.cutover_suspended:
            return
        self.cutover_suspended = True
        self.initialized = False
        for ring in (self._ring, self._score_ring, self._pending_child_parity,
                     self._pending_child_scores, self._eager_inputs, self._score_results):
            ring.clear()
        for fut in list(self._score_futures.values()):
            if not fut.done():
                fut.set_result(None)
        self._score_futures.clear()
        bt.logging.error(
            f"[SHADOW] {reason}: the parity self-heal is not converging, so the scoring service is "
            f"suspended and main scores and saves in-process until the validator restarts. Each re-INIT "
            f"was stalling main for the snapshot without ever restoring parity ({self.mismatches} "
            f"mismatches, {self.matches} matches, {self._dropped} tee drops). Look for "
            f"'[SHADOW] tee dropped' lines and for a structure missing from the INIT snapshot."
        )

        def _send():
            try:
                _send_frame(self._sock, ("reinit", None))
            except Exception:
                pass

        self._executor.submit(_send)

    def health(self) -> dict:
        """Counters for the report data and the validator gauges."""
        return {
            "alive": int(self.is_alive()),
            "initialized": int(self.initialized),
            "cutover_suspended": int(self.cutover_suspended),
            "parity_matches": int(self.matches),
            "parity_mismatches": int(self.mismatches),
            "reinits": int(self.reinits),
            "tee_dropped": int(self._dropped),
        }

    def send_init(self, validator) -> None:
        """Build + stream the INIT snapshot. MUST be called while the caller
        holds _reward_lock (structures frozen); runs synchronously on the
        shadow executor so it is FIFO-ordered with the tee frames."""
        if self.cutover_suspended:
            import concurrent.futures
            done = concurrent.futures.Future()
            done.set_result(None)
            return done
        self.initialized = True
        base_ts = validator._shadow_applied_ts

        def _do_init():
            t0 = time.time()
            try:
                for name in _STRUCT_NAMES:
                    plain = _plainify(getattr(validator, name, {}))
                    _send_frame(self._sock, ("init_part", (name, pickle.dumps(plain, protocol=5))))
                    del plain
                from taos.im.validator.reward import build_scoring_config, build_simulation_config_dict
                knobs = {
                    "_last_prune_timestamp": getattr(validator, "_last_prune_timestamp", None),
                    "_last_accounted_ts": getattr(validator, "_last_accounted_ts", None),
                    "step": validator.step,
                    "effective_max_uids": validator.effective_max_uids,
                    "config": _config_duck(validator.config),
                    "simulation": _simulation_duck(validator.simulation),
                    # Shadow-reward: the exact dicts main's get_rewards consumes
                    # (single source of truth — see reward.build_scoring_config).
                    "scoring_config": build_scoring_config(validator),
                    "simulation_config": build_simulation_config_dict(validator),
                    "scoring_interval": validator.config.scoring.interval,
                    "validator_uid": getattr(validator, 'uid', None),
                }
                _send_frame(self._sock, ("init_done", (base_ts, knobs)))
                import bittensor as bt
                bt.logging.info(f"[SHADOW] init snapshot sent (base_ts={base_ts}, {time.time()-t0:.2f}s)")
            except Exception as e:
                import bittensor as bt
                bt.logging.warning(f"[SHADOW] init failed: {e}")

        return self._executor.submit(_do_init)

    def _compare_parity(self, ts: int, mine, theirs, applied=None, apply_s=None) -> None:
        import bittensor as bt
        mine_comps, mine_vec = mine if isinstance(mine, tuple) else (mine, None)
        if isinstance(theirs, tuple):
            # (comps, vec) or (comps, vec, applied): the child's applied-round count rides along so a
            # MISMATCH line says how many rounds its replica had absorbed since INIT.
            theirs_comps = theirs[0]
            theirs_vec = theirs[1] if len(theirs) > 1 else None
            if applied is None and len(theirs) > 2:
                applied = theirs[2]
        else:
            theirs_comps, theirs_vec = theirs, None
        mine, theirs = mine_comps, theirs_comps
        if mine == theirs:
            self.matches += 1
            bt.logging.info(
                f"[SHADOW-PARITY] ts={ts} MATCH ({self.matches} ok / {self.mismatches} bad, "
                f"applied={applied}, dropped={self._dropped})"
            )
        else:
            self.mismatches += 1
            self._consecutive_mismatches += 1
            if isinstance(mine, dict) and isinstance(theirs, dict):
                # Name the diverging structures — turns a rare mismatch into a
                # self-diagnosing event instead of an opaque hash difference.
                _diff = sorted(
                    k for k in set(mine) | set(theirs) if mine.get(k) != theirs.get(k)
                )
                bt.logging.error(
                    f"[SHADOW-PARITY] ts={ts} MISMATCH diverged_structures={_diff} "
                    f"(applied={applied}, dropped={self._dropped}, reinits={self.reinits}) "
                    f"(main={ {k: mine.get(k) for k in _diff} } shadow={ {k: theirs.get(k) for k in _diff} })"
                )
                # The vectors: a dict of named uid vectors since 2 Oct 2026; a bare {uid: len} dict is the
                # older n_pnl-only form, read the same way so the two sides can be a version apart.
                def _vectors(v):
                    if isinstance(v, dict) and ("n_pnl" in v or "debeta_mtm" in v):
                        return v
                    return {"n_pnl": v} if isinstance(v, dict) else {}
                _mv, _tv = _vectors(mine_vec), _vectors(theirs_vec)
                if 'n_pnl' in _diff and _mv.get("n_pnl") is not None and _tv.get("n_pnl") is not None:
                    _uid_diff = {
                        u: (_mv["n_pnl"].get(u, 0), _tv["n_pnl"].get(u, 0))
                        for u in set(_mv["n_pnl"]) | set(_tv["n_pnl"])
                        if _mv["n_pnl"].get(u, 0) != _tv["n_pnl"].get(u, 0)
                    }
                    bt.logging.error(
                        f"[SHADOW-PARITY] ts={ts} n_pnl uid-level diff (main,shadow): {_uid_diff}"
                    )
                if 'debeta_mtm' in _diff and _mv.get("debeta_mtm") is not None and _tv.get("debeta_mtm") is not None:
                    _d = uid_level_diff(_mv["debeta_mtm"], _tv["debeta_mtm"])
                    bt.logging.error(
                        f"[SHADOW-PARITY] ts={ts} debeta_mtm uid-level diff, {_d['n_diff']} uid(s) differ; "
                        f"only main {_d['only_main'][:8]}, only shadow {_d['only_shadow'][:8]}; "
                        f"largest (main (books, mtm, inv), shadow (books, mtm, inv)): {_d['uids']}"
                    )
                    _mb, _tb = _mv.get("mtm_books") or {}, _tv.get("mtm_books") or {}
                    if _d["uids"] and _mb and _tb:
                        _top = next(iter(_d["uids"]))
                        _bm, _bt = (_mb.get("books") or {}).get(_top, {}), (_tb.get("books") or {}).get(_top, {})
                        _rows = {bk: {"main": _bm.get(bk), "shadow": _bt.get(bk),
                                      "p_last": ((_mb.get("p_last") or {}).get(bk), (_tb.get("p_last") or {}).get(bk)),
                                      "mark_prev": ((_mb.get("mark_prev") or {}).get(bk), (_tb.get("mark_prev") or {}).get(bk))}
                                 for bk in sorted(set(_bm) | set(_bt))}
                        bt.logging.error(f"[SHADOW-PARITY] ts={ts} debeta_mtm per-book for uid {_top} (mtm, inv) and (p_last main, shadow), (mark_prev main, shadow): {_rows}")
            else:
                bt.logging.error(f"[SHADOW-PARITY] ts={ts} MISMATCH main={mine} shadow={theirs}")
            if self._consecutive_mismatches >= 2:
                self._consecutive_mismatches = 0
                self.request_reinit()
            return
        self._consecutive_mismatches = 0

    def _compare_scores(self, ts: int, mine: list, theirs: list) -> None:
        import bittensor as bt
        if len(mine) == len(theirs) and all(a == b for a, b in zip(mine, theirs)):
            self.score_matches += 1
            bt.logging.info(
                f"[SHADOW-SCORES] ts={ts} MATCH ({self.score_matches} ok / "
                f"{self.score_mismatches} bad, n={len(theirs)})"
            )
        else:
            self.score_mismatches += 1
            _diffs = [
                (i, a, b) for i, (a, b) in enumerate(zip(mine, theirs)) if a != b
            ] if len(mine) == len(theirs) else []
            _max = max((abs(a - b) for _, a, b in _diffs), default=float('nan'))
            bt.logging.error(
                f"[SHADOW-SCORES] ts={ts} MISMATCH n_main={len(mine)} n_shadow={len(theirs)} "
                f"diff_uids={len(_diffs)} max_abs_diff={_max:.3e} first={_diffs[:3]}"
            )

    @staticmethod
    def _stash(ring: dict, key, value, cap: int) -> None:
        ring[key] = value
        while len(ring) > cap:
            ring.pop(next(iter(ring)))

    def record_main_digest(self, timestamp: int, digest: str) -> None:
        """Record the main process's scoring digest for parity comparison.

        Args:
            timestamp (int): Step timestamp the digest belongs to.
            digest (str): The main scorer's digest.
        """
        if self.cutover_suspended:
            return
        theirs = self._pending_child_parity.pop(timestamp, None)
        if theirs is not None:
            self._compare_parity(timestamp, digest, theirs)
        else:
            self._stash(self._ring, timestamp, digest, 16)

    def on_main_scored(self, timestamp: int, sim_ts_used: int, deregs_used: list, trading_scores: list,
                       trading_ema=None, trading_ema_n=None, trading_ema_ts=None) -> None:
        """Called after main's get_rewards completes on a scoring round: record
        main's trading scores for comparison and release the child (which is

        Args:
            timestamp: The scoring round timestamp.
            sim_ts_used: Simulation timestamp main actually scored on.
            deregs_used: Deregistrations main actually applied.
            trading_scores: Main's trading scores, recorded for comparison.
            trading_ema: Main's carried EMA.
            trading_ema_n: Main's carried per-uid counts.
            trading_ema_ts: Main's carried per-uid timestamps.
        holding applies at this boundary) with the exact live inputs main used."""
        theirs = self._pending_child_scores.pop(timestamp, None)
        if theirs is not None:
            self._compare_scores(timestamp, list(trading_scores), theirs)
        else:
            self._stash(self._score_ring, timestamp, list(trading_scores), 8)
        if not self.is_alive():
            return

        def _send():
            try:
                _send_frame(self._sock, ("score_at", (timestamp, sim_ts_used, list(deregs_used),
                                                      None, None,
                                                      dict(trading_ema or {}), dict(trading_ema_n or {}),
                                                      trading_ema_ts)))
            except Exception:
                pass

        self._executor.submit(_send)

    # ── child -> main ────────────────────────────────────────────────────────

    def _read_loop(self):
        import bittensor as bt
        try:
            while True:
                kind, payload = _recv_frame(self._sock)
                if kind == "parity":
                    ts, comps, vec, applied, apply_s = payload
                    mine = self._ring.pop(ts, None)
                    if mine is None:
                        # Child computed ahead of main (normal: it applies on tee,
                        # main applies seconds later behind _reward_lock) — stash
                        # and let record_main_digest complete the comparison.
                        self._stash(self._pending_child_parity, ts, (comps, vec, applied), 32)
                    else:
                        self._compare_parity(ts, mine, (comps, vec, applied))
                elif kind == "scores":
                    ts, result, score_s = payload
                    fut = self._score_futures.pop(ts, None)
                    if fut is not None:
                        # cutover mode: resolve the awaiting _reward directly
                        fut.set_result(result)
                        continue
                    if ts in self._eager_inputs:
                        # eager result landed before main asked — stash for
                        # request_scores to return instantly
                        self._stash(self._score_results, ts, result, 4)
                        continue
                    trading = result['trading'] if isinstance(result, dict) else result
                    mine = self._score_ring.pop(ts, None)
                    if mine is None:
                        self._stash(self._pending_child_scores, ts, trading, 8)
                    else:
                        self._compare_scores(ts, mine, trading)
                elif kind == "scores_err":
                    ts, msg = payload
                    bt.logging.warning(f"[SHADOW] child scoring error at ts={ts}: {msg}")
                    fut = self._score_futures.pop(ts, None)
                    if fut is not None:
                        fut.set_result(None)
                elif kind == "save_done":
                    ts, nbytes, secs = payload
                    fut = self._save_futures.pop(ts, None)
                    if fut is not None:
                        fut.set_result((nbytes, secs))
                elif kind == "save_err":
                    ts, msg = payload
                    bt.logging.warning(f"[SHADOW] child save failed at ts={ts}: {msg}")
                    fut = self._save_futures.pop(ts, None)
                    if fut is not None:
                        fut.set_result(None)
        except (EOFError, OSError):
            pass
        except Exception as e:
            bt.logging.warning(f"[SHADOW] parity reader: {e}")

    def stop(self) -> None:
        """Stop the shadow process and release its resources."""
        try:
            self._executor.submit(lambda: _send_frame(self._sock, ("stop", None)))
            self._executor.shutdown(wait=True)
        except Exception:
            pass
        if self._sock is not None:
            try:
                self._sock.close()
            except Exception:
                pass
        if self._proc is not None:
            self._proc.join(timeout=3.0)
            if self._proc.is_alive():
                self._proc.kill()
            self._proc = None


def _num(v, default, cast):
    """Cast v, or return default when v is genuinely absent. `v or default` would swallow a
    legitimate zero (see the debeta note in _config_duck)."""
    if v is None:
        return cast(default)
    try:
        return cast(v)
    except (TypeError, ValueError):
        return cast(default)


def _debeta_duck(d):
    """Every scoring.debeta dial the parser declares, read off main's config, cast to the parser default's type.
    `is None` decides absence, never `or`: a configured zero (floor_scale 0, w_make 0) reaches the child as zero."""
    from types import SimpleNamespace
    from taos.im.config import debeta_defaults, debeta_dial
    return SimpleNamespace(**{name: _num(debeta_dial(d, name), default, type(default))
                              for name, default in debeta_defaults().items()})


def _config_duck(config):
    """Minimal picklable stand-in exposing exactly the config paths trade.py reads."""
    from types import SimpleNamespace
    _d = getattr(config.scoring, 'debeta', None)
    return SimpleNamespace(
        scoring=SimpleNamespace(
            activity=SimpleNamespace(
                trade_volume_assessment_period=config.scoring.activity.trade_volume_assessment_period,
                trade_volume_sampling_interval=config.scoring.activity.trade_volume_sampling_interval,
            ),
            kappa=SimpleNamespace(lookback=config.scoring.kappa.lookback),
            # De-beta gates both the trade.py accumulators and compute_debeta_scores, so the child carries every
            # dial main's config holds; a dial main lacks takes the parser default, as main's own reads do.
            debeta=_debeta_duck(_d),
        )
    )


def _simulation_duck(simulation):
    """What the scoring child reads off the simulation: the two scalars, and config_for_book answering each book's
    minimum order size, the dust floor's voting bar (trade._min_order_size). Without that answer the child took the
    0.0 fallback on every book while main read the layout's minimum, and the two sides built different floors from
    the same prints on a two-class layout. The map is built here, once, so the duck stays plain data to ship."""
    from types import SimpleNamespace
    min_sizes = {}
    lookup = getattr(simulation, "config_for_book", None)
    if callable(lookup):
        books = getattr(simulation, "book_ids", None) or range(int(getattr(simulation, "book_count", 0) or 0))
        for b in books:
            try:
                min_sizes[int(b)] = float(getattr(lookup(int(b)), "min_order_size", 0.0) or 0.0)
            except Exception:
                min_sizes[int(b)] = 0.0
    return _SimulationDuck(simulation.volumeDecimals, simulation.miner_wealth, min_sizes)


class _SimulationDuck:
    """Plain data with one lookup; a module-level class so the INIT frame pickles (a lambda on a namespace does not)."""

    def __init__(self, volume_decimals, miner_wealth, min_order_size_by_book):
        self.volumeDecimals = volume_decimals
        self.miner_wealth = miner_wealth
        self.min_order_size_by_book = dict(min_order_size_by_book)

    def config_for_book(self, book_id):
        from types import SimpleNamespace
        return SimpleNamespace(min_order_size=self.min_order_size_by_book.get(int(book_id), 0.0))
