/*
 * SPDX-FileCopyrightText: 2025 Rayleigh Research <to@rayleigh.re>
 * SPDX-License-Identifier: MIT
 */
#include <taosim/book/Book.hpp>

#include <algorithm>
#include <vector>

#include <taosim/simulation/SimulationException.hpp>
#include "Simulation.hpp"
// For the STP cancel notice: the resting order's owner must be TOLD its order is gone, and the
// cancellation here never had an instruction behind it, so no response path exists to say so.
#include <taosim/message/ExchangeAgentMessagePayloads.hpp>

#include <range/v3/action/remove_if.hpp>

//-------------------------------------------------------------------------

namespace taosim::book
{

//-------------------------------------------------------------------------

Book::Book(
    Simulation* simulation,
    BookId id,
    size_t maxDepth,
    size_t detailedDepth,
    std::shared_ptr<OrderID> orderIdCounter,
    std::shared_ptr<TradeID> tradeIdCounter)
    : m_simulation{simulation},
      m_id{id},
      m_orderIdCounter{orderIdCounter ? orderIdCounter : std::make_shared<OrderID>()},
      m_tradeIdCounter{tradeIdCounter ? tradeIdCounter : std::make_shared<TradeID>()}
{
    if (maxDepth == 0) {
        throw std::invalid_argument("Book maximum depth must be non-zero");
    }
    m_maxDepth = maxDepth;
    m_detailedDepth = std::min(detailedDepth, maxDepth);

    simulation->logDebug(
        orderIdCounter
            ? fmt::format("Using shared orderIdCounter ({}) for book {}", *m_orderIdCounter, simulation->bookIdCanon(id))
            : fmt::format("Creating unique orderIdCounter ({}) for book {}", *m_orderIdCounter, simulation->bookIdCanon(id)));
    simulation->logDebug(
        tradeIdCounter
            ? fmt::format("Using shared tradeIdCounter ({}) for book {}", *m_tradeIdCounter, simulation->bookIdCanon(id))
            : fmt::format("Creating unique tradeIdCounter ({}) for book {}", *m_tradeIdCounter, simulation->bookIdCanon(id)));

    setupL2Signal();
}

//-------------------------------------------------------------------------

void Book::recordBandTrade(
    Timestamp ts, taosim::decimal_t price, AgentId maker, AgentId taker) noexcept
{
    if (price <= 0_dec) return;
    // Self-trades are excluded, mirroring the Ma==Ta guard in accumulate_book_capture. Without this a
    // miner walks the reference by trading with itself at the band edge for the cost of fees only, which
    // removes the sustained-capital cost that is the whole deterrent.
    if (maker == taker) return;
    m_bandLastTradeTs = ts;
    m_bandRefusedSinceTrade = false;
    m_bandFirstRefusalTs = 0;
    m_bandLastPrice = price;
    if (!m_bandSeeded) {
        m_bandSeeded = true;
        m_bandLastSampleTs = ts;
        m_bandSamples.push_back(price);
        m_bandRefCached = price;
    }
    sampleBandRef(ts);
}

//-------------------------------------------------------------------------

void Book::sampleBandRef(Timestamp ts) noexcept
{
    const auto& params = m_simulation->exchange()->config().parameters();
    const auto interval = params.bandRefInterval;
    const auto window = params.bandRefWindow;
    if (interval <= 0 || m_bandLastPrice <= 0_dec) return;
    const size_t maxSamples =
        static_cast<size_t>(std::max<int64_t>(1, window / interval));
    bool pushed = false;
    // Catch up whole intervals. During a quiet stretch the prevailing price is re-sampled, so the window
    // never empties and the band never silently disables itself (without the catch-up, a gap longer than
    // the window drops every sample and leaves the sweep unbounded).
    while (m_bandSeeded && static_cast<int64_t>(ts - m_bandLastSampleTs) >= interval) {
        m_bandLastSampleTs += interval;
        m_bandSamples.push_back(m_bandLastPrice);
        if (m_bandSamples.size() > maxSamples) m_bandSamples.pop_front();
        pushed = true;
    }
    if (!pushed) return;
    // Median, recomputed only on a push (once per interval) and cached, so the match hot path stays O(1).
    std::vector<taosim::decimal_t> tmp{m_bandSamples.begin(), m_bandSamples.end()};
    const size_t mid = tmp.size() / 2;
    std::nth_element(tmp.begin(), tmp.begin() + mid, tmp.end());
    m_bandRefCached = tmp[mid];
}

//-------------------------------------------------------------------------

taosim::decimal_t Book::bandRef() const noexcept
{
    return m_bandRefCached;
}

//-------------------------------------------------------------------------

taosim::decimal_t Book::bandLimit(bool isBuy) const noexcept
{
    const double band = effectiveBand(m_simulation->currentTimestamp());
    const auto ref = m_bandRefCached;
    if (band <= 0.0 || ref <= 0_dec) {
        return isBuy ? std::numeric_limits<taosim::decimal_t>::max()
                     : std::numeric_limits<taosim::decimal_t>::min();
    }
    const auto bnd = taosim::util::double2decimal(band);
    return isBuy ? ref * taosim::util::dec1p(bnd) : ref * taosim::util::dec1m(bnd);
}

//-------------------------------------------------------------------------

double Book::effectiveBand(Timestamp ts) const noexcept
{
    const auto& params = m_simulation->exchange()->config().parameters();
    const double band = params.maxPriceBand;
    if (band <= 0.0 || !m_bandSeeded || params.bandReleaseAfter <= 0 || !m_bandRefusedSinceTrade) {
        return band;
    }
    // Silence is counted from the last print, which travels with the book in the checkpoint. When no print
    // is known (a checkpoint written before that field existed) it is counted from the first refusal
    // instead. Never from the sample clock: that clock advances every time an order is processed, so a
    // book locked across a resume would never accumulate the silence and never release.
    const Timestamp last = m_bandLastTradeTs != 0 ? m_bandLastTradeTs : m_bandFirstRefusalTs;
    if (last == 0 || ts <= last) {
        return band;
    }
    const int64_t silent = static_cast<int64_t>(ts - last);
    if (silent < params.bandReleaseAfter) {
        return band;
    }
    const int64_t step = std::max<int64_t>(params.bandReleaseStep, 1);
    const int64_t widenings = 1 + (silent - params.bandReleaseAfter) / step;
    return std::min(params.bandReleaseMax, band * static_cast<double>(1 + widenings));
}

//-------------------------------------------------------------------------

void Book::noteBandRefusal() noexcept
{
    if (!m_bandRefusedSinceTrade) {
        m_bandRefusedSinceTrade = true;
        m_bandFirstRefusalTs = m_simulation->currentTimestamp();
    }
}

//-------------------------------------------------------------------------

taosim::decimal_t Book::midPrice() const noexcept
{
    const auto bid = bestBid();
    const auto ask = bestAsk();

    if (bid == 0_dec || ask == 0_dec) [[unlikely]] {
        return {};
    }
    return DEC(0.5) * (bid + ask);
}

//-------------------------------------------------------------------------

taosim::decimal_t Book::bestBid() const noexcept
{
    return bestBuyLevel()
        .transform([](auto&& level) { return level.get().price(); })
        .value_or(0_dec);
}

//-------------------------------------------------------------------------

taosim::decimal_t Book::bestAsk() const noexcept
{
    return bestSellLevel()
        .transform([](auto&& level) { return level.get().price(); })
        .value_or(0_dec);
}

//-------------------------------------------------------------------------

std::optional<taosim::decimal_t> Book::spread() const noexcept
{
    const auto bid = bestBid();
    const auto ask = bestAsk();

    if (bid == 0_dec || ask == 0_dec) [[unlikely]] {
        return {};
    }
    return std::make_optional(ask - bid);
}

//-------------------------------------------------------------------------

void Book::refreshTopOfBook() const noexcept
{
    auto& buyQueue = const_cast<OrderContainer&>(m_buyQueue);
    auto& sellQueue = const_cast<OrderContainer&>(m_sellQueue);

    auto buyView = buyQueue | ranges::views::reverse;
    auto buyIt = ranges::find_if(buyView, [](auto&& level) { return level.hasActiveOrders(); });
    m_topOfBook.bestBuyLevel = (buyIt != ranges::end(buyView))
        ? std::make_optional(std::ref(*buyIt)) : std::nullopt;

    auto sellIt = ranges::find_if(sellQueue, [](auto&& level) { return level.hasActiveOrders(); });
    m_topOfBook.bestSellLevel = (sellIt != ranges::end(sellQueue))
        ? std::make_optional(std::ref(*sellIt)) : std::nullopt;

    m_topOfBook.isDirty = false;
}

//-------------------------------------------------------------------------

Book::OptLevelRef Book::bestBuyLevel() const noexcept
{
    if (m_topOfBook.isDirty) {
        refreshTopOfBook();
    }
    return m_topOfBook.bestBuyLevel;
}

//-------------------------------------------------------------------------

Book::OptLevelRef Book::bestSellLevel() const noexcept
{
    if (m_topOfBook.isDirty) {
        refreshTopOfBook();
    }
    return m_topOfBook.bestSellLevel;
}

//-------------------------------------------------------------------------

void Book::placeOrder(const MarketOrder::Ptr& order)
{
    using namespace taosim::util;

    m_order2clientCtx[order->id()].instrSeq = m_simulation->currentInstructionSeq();
    const auto clientCtx = m_order2clientCtx.at(order->id());
    const auto slip = order->maxSlippage();
    const auto priceDecimals =
        m_simulation->exchange()->config().parameters().priceIncrementDecimals;

    // The processing step is conditional on the opposite side having any
    // active orders (the match loop dereferences bestBuyLevel()/bestSellLevel()
    // and would otherwise throw on the empty `std::optional`). We must still
    // emit `marketOrderProcessed` at the end even when nothing traded, so
    // marketOrderProcessedCallback can release the order's untouched
    // reservation and drop it from the agent's activeOrders — otherwise the
    // order permanently lingers there with a live reservation.
    if (order->direction() == OrderDirection::BUY) {
        if (m_sellQueue.hasActiveOrders()) {
            const auto maxPrice = (slip > 0_dec)
                ? round(bestAsk() * dec1p(slip), priceDecimals)
                : std::numeric_limits<taosim::decimal_t>::max();
            processAgainstTheSellQueue(order, maxPrice);
        }
    } else {
        if (m_buyQueue.hasActiveOrders()) {
            const auto minPrice = (slip > 0_dec)
                ? round(bestBid() * dec1m(slip), priceDecimals)
                : std::numeric_limits<taosim::decimal_t>::min();
            processAgainstTheBuyQueue(order, minPrice);
        }
    }

    m_signals.marketOrderProcessed(
        order, OrderContext{clientCtx.agentId, m_id, clientCtx.clientOrderId});
}

//-------------------------------------------------------------------------

void Book::placeOrder(const LimitOrder::Ptr& order)
{
    m_order2clientCtx[order->id()].instrSeq = m_simulation->currentInstructionSeq();
    const auto clientCtx = m_order2clientCtx.at(order->id());

    if (order->direction() == OrderDirection::BUY) {
        placeLimitBuy(order);
    } else {
        placeLimitSell(order);
    }

    m_signals.limitOrderProcessed(
        order, OrderContext{clientCtx.agentId, m_id, clientCtx.clientOrderId});
}

//-------------------------------------------------------------------------

void Book::placeLimitBuy(const LimitOrder::Ptr& order)
{
    if (!m_sellQueue.hasActiveOrders() || order->price() < bestAsk()) {
        auto firstLessThan = std::find_if(
            m_buyQueue.rbegin(),
            m_buyQueue.rend(),
            [&order](const auto& level) { return level.price() <= order->price(); });

        if (firstLessThan != m_buyQueue.rend() && firstLessThan->price() == order->price()) {
            registerLimitOrder(order);
            firstLessThan->push_back(order);
        }
        else {
            taosim::book::TickContainer tov{&m_buyQueue, order->price()};
            registerLimitOrder(order);
            tov.push_back(order);
            m_buyQueue.insert(firstLessThan.base(), std::move(tov));
        }
        m_topOfBook.invalidate();
    }
    else {
        const auto volBefore = order->volume();
        processAgainstTheSellQueue(order, order->price());

        if (order->volume() > 0_dec) {
            if (order->volume() == volBefore) {
                // No progress was made — place as passive to avoid infinite recursion
                // A CROSSING ORDER THAT CANNOT MATCH MUST NOT REST, OR IT WOULD LEAVE THE BOOK CROSSED
                // PERMANENTLY. Reaching here means the order is marketable but processAgainst* moved none of
                // it -- in practice because the price band stopped the walk: that loop is bounded by
                // bandLo/bandHi = bandRef * (1 -/+ maxPriceBand). Resting it at its own crossing price then
                // puts a bid above the ask ladder (or an ask below the bid ladder), and the book cannot
                // recover: the band reference is fed ONLY by trades (recordBandTrade is its sole setter), so
                // with matching blocked no trade prints, sampleBandRef re-samples the frozen price forever,
                // and the band never releases. A closed loop with no exit.
                //
                // Both directions reach it: a bid resting above the ask ladder, or an ask below the bid
                // ladder. Either leaves the book crossed from that instant on, with every subsequent level
                // update carrying the inversion, and no path back.
                //
                // The band's policy is deliberately NOT changed: no match is permitted that was not permitted
                // before, and the reference still moves only on trades, which is what PriceBandTests pins
                // ("NO RATCHET -- the reference must NOT be top-of-book"). This only refuses to CREATE an
                // illegal state. The order is unregistered on the same path a fully-filled order takes.
                //
                // Trade-off: an order that today rests (invisibly crossing the book) is instead dropped. That
                // is visible where the current behaviour is not, but it IS a behaviour change, and a dedicated
                // refusal code would be better than reusing unregister.
                if (m_sellQueue.hasActiveOrders() && order->price() >= bestAsk()) {
                    unregisterLimitOrder(order);
                    return;
                }
                auto firstLessThan = std::find_if(
                    m_buyQueue.rbegin(),
                    m_buyQueue.rend(),
                    [&order](const auto& level) { return level.price() <= order->price(); });

                if (firstLessThan != m_buyQueue.rend() && firstLessThan->price() == order->price()) {
                    registerLimitOrder(order);
                    firstLessThan->push_back(order);
                }
                else {
                    taosim::book::TickContainer tov{&m_buyQueue, order->price()};
                    registerLimitOrder(order);
                    tov.push_back(order);
                    m_buyQueue.insert(firstLessThan.base(), std::move(tov));
                }
                m_topOfBook.invalidate();
            } else {
                placeOrder(order);
            }
        } else {
            unregisterLimitOrder(order);
        }
    }
}

//-------------------------------------------------------------------------

void Book::placeLimitSell(const LimitOrder::Ptr& order)
{
    if (!m_buyQueue.hasActiveOrders() || order->price() > bestBid()) {
        auto firstGreaterThan = std::find_if(
            m_sellQueue.begin(),
            m_sellQueue.end(),
            [&order](const auto& level) { return level.price() >= order->price(); });

        if (firstGreaterThan != m_sellQueue.end() && firstGreaterThan->price() == order->price()) {
            registerLimitOrder(order);
            firstGreaterThan->push_back(order);
        }
        else {
            taosim::book::TickContainer tov{&m_sellQueue, order->price()};
            registerLimitOrder(order);
            tov.push_back(order);
            m_sellQueue.insert(firstGreaterThan, std::move(tov));
        }
        m_topOfBook.invalidate();
    }
    else {
        const auto volBefore = order->volume();
        processAgainstTheBuyQueue(order, order->price());

        if (order->volume() > 0_dec) {
            if (order->volume() == volBefore) {
                // No progress was made — place as passive to avoid infinite recursion
                // A CROSSING ORDER THAT CANNOT MATCH MUST NOT REST, OR IT WOULD LEAVE THE BOOK CROSSED
                // PERMANENTLY. Reaching here means the order is marketable but processAgainst* moved none of
                // it -- in practice because the price band stopped the walk: that loop is bounded by
                // bandLo/bandHi = bandRef * (1 -/+ maxPriceBand). Resting it at its own crossing price then
                // puts a bid above the ask ladder (or an ask below the bid ladder), and the book cannot
                // recover: the band reference is fed ONLY by trades (recordBandTrade is its sole setter), so
                // with matching blocked no trade prints, sampleBandRef re-samples the frozen price forever,
                // and the band never releases. A closed loop with no exit.
                //
                // Both directions reach it: a bid resting above the ask ladder, or an ask below the bid
                // ladder. Either leaves the book crossed from that instant on, with every subsequent level
                // update carrying the inversion, and no path back.
                //
                // The band's policy is deliberately NOT changed: no match is permitted that was not permitted
                // before, and the reference still moves only on trades, which is what PriceBandTests pins
                // ("NO RATCHET -- the reference must NOT be top-of-book"). This only refuses to CREATE an
                // illegal state. The order is unregistered on the same path a fully-filled order takes.
                //
                // Trade-off: an order that today rests (invisibly crossing the book) is instead dropped. That
                // is visible where the current behaviour is not, but it IS a behaviour change, and a dedicated
                // refusal code would be better than reusing unregister.
                if (m_buyQueue.hasActiveOrders() && order->price() <= bestBid()) {
                    unregisterLimitOrder(order);
                    return;
                }
                auto firstGreaterThan = std::find_if(
                    m_sellQueue.begin(),
                    m_sellQueue.end(),
                    [&order](const auto& level) { return level.price() >= order->price(); });

                if (firstGreaterThan != m_sellQueue.end() && firstGreaterThan->price() == order->price()) {
                    registerLimitOrder(order);
                    firstGreaterThan->push_back(order);
                }
                else {
                    taosim::book::TickContainer tov{&m_sellQueue, order->price()};
                    registerLimitOrder(order);
                    tov.push_back(order);
                    m_sellQueue.insert(firstGreaterThan, std::move(tov));
                }
                m_topOfBook.invalidate();
            } else {
                placeOrder(order);
            }
        } else {
            unregisterLimitOrder(order);
        }
    }
}

//-------------------------------------------------------------------------

bool Book::cancelOrder(OrderID orderId, std::optional<taosim::decimal_t> volumeToCancel)
{
    auto it = m_orderIdMap.find(orderId);
    if (it == m_orderIdMap.end()) { return false; }

    const auto maxDecimals = std::max({
        m_simulation->exchange()->config().parameters().volumeIncrementDecimals,
        m_simulation->exchange()->config().parameters().priceIncrementDecimals,
        m_simulation->exchange()->config().parameters().quoteIncrementDecimals,
        m_simulation->exchange()->config().parameters().baseIncrementDecimals
    });

    auto order = it->second;

    const taosim::decimal_t orderVolume = order->volume();
    if (orderVolume == 0_dec) { return false; }

    taosim::decimal_t volumeToCancelActual =
        std::min(volumeToCancel.value_or(orderVolume), orderVolume);

    volumeToCancelActual = taosim::util::round(volumeToCancelActual, maxDecimals);

    if (m_simulation->debug()) {
        const auto ctx = m_order2clientCtx[order->id()];
        const auto& balances = m_simulation->exchange()->accounts()[ctx.agentId][m_id];
        m_simulation->logDebug("{} | AGENT #{} BOOK {} : QUOTE : {}  BASE : {}", 
            m_simulation->currentTimestamp(), ctx.agentId, m_id, *balances.quote, balances.base);
    }
    m_signals.cancelOrderDetails(order, volumeToCancelActual, m_id);

    auto& orderSideLevels = order->direction() == OrderDirection::BUY ? m_buyQueue : m_sellQueue;
    auto levelIt = std::lower_bound(orderSideLevels.begin(), orderSideLevels.end(), order->price());

    // Invalidate BEFORE mutating: the unregister and cancel signals below both reach readers of the
    // best levels (reservation release, L2 logger), and the level erased here may be the cached one.
    m_topOfBook.invalidate();

    // The level aggregates totalVolume (own plus borrowed), so it loses exactly what the order's
    // total loses, not the own-volume figure the cancellation is expressed in.
    if (volumeToCancelActual == orderVolume) {
        std::erase_if(
            *levelIt, [orderId](const auto orderOnLevel) { return orderOnLevel->id() == orderId; });
        levelIt->updateVolume(-order->totalVolume());
        if (levelIt->empty()) {
            orderSideLevels.erase(levelIt);
        }
        unregisterLimitOrder(order);
    }
    else {
        const auto totalVolumeBefore = order->totalVolume();
        order->removeVolume(volumeToCancelActual);
        levelIt->updateVolume(order->totalVolume() - totalVolumeBefore);
    }

    m_signals.cancel(order->id(), volumeToCancelActual);

    return true;
}

//-------------------------------------------------------------------------

bool Book::restoreRestingOrderVolume(OrderID orderId, taosim::decimal_t deltaVolume)
{
    if (deltaVolume <= 0_dec) { return false; }

    const auto it = m_orderIdMap.find(orderId);
    if (it == m_orderIdMap.end()) { return false; }

    const auto& order = it->second;
    auto& orderSideLevels = order->direction() == OrderDirection::BUY ? m_buyQueue : m_sellQueue;
    const auto levelIt =
        std::lower_bound(orderSideLevels.begin(), orderSideLevels.end(), order->price());
    if (levelIt == orderSideLevels.end() || levelIt->price() != order->price()) { return false; }

    const auto totalVolumeBefore = order->totalVolume();
    order->setVolume(order->volume() + deltaVolume);
    levelIt->updateVolume(order->totalVolume() - totalVolumeBefore);
    m_topOfBook.invalidate();

    return true;
}

//-------------------------------------------------------------------------

std::optional<LimitOrder::Ptr> Book::getOrder(OrderID orderId) const
{
    auto it = m_orderIdMap.find(orderId);
    return it != m_orderIdMap.end() ? std::make_optional(it->second) : std::nullopt;
}

//-------------------------------------------------------------------------

void Book::registerLimitOrder(const LimitOrder::Ptr& order)
{
    m_orderIdMap[order->id()] = order;
    if (m_simulation->debug()) {
        const auto ctx = m_order2clientCtx[order->id()];
        auto& balances = m_simulation->exchange()->accounts().at(ctx.agentId).at(m_id);
        fmt::println("{} | AGENT #{} BOOK {} : REGISTERED {} ORDER #{} FOR {}@{}| RESERVED {} QUOTE + {} BASE | BALANCES : QUOTE {}  BASE {}", m_simulation->currentTimestamp(), 
            ctx.agentId, m_simulation->bookIdCanon(m_id), order->direction() == OrderDirection::BUY ? "BUY" : "SELL",
            order->id(), order->leverage() > 0_dec ? fmt::format("{}x{}",1_dec + order->leverage(),order->volume()) : fmt::format("{}",order->volume()), order->price(),
            balances.quote->getReservation(order->id()).value_or(0_dec), balances.base.getReservation(order->id()).value_or(0_dec),
            *balances.quote, balances.base);
    } 
}

//-------------------------------------------------------------------------

void Book::unregisterLimitOrder(const LimitOrder::Ptr& order)
{
    m_signals.unregister(order, m_id);
    m_orderIdMap.erase(order->id());
    if (m_unregisteredCapacity > 0) {
        if (const auto it = m_order2clientCtx.find(order->id()); it != m_order2clientCtx.end()) {
            const bool inserted = m_unregistered.insert_or_assign(
                order->id(), UnregisteredOrder{.order = order, .ctx = it->second}).second;
            if (inserted) { m_unregisteredQueue.push_back(order->id()); }
            while (m_unregisteredQueue.size() > m_unregisteredCapacity) {
                m_unregistered.erase(m_unregisteredQueue.front());
                m_unregisteredQueue.pop_front();
            }
        }
    }
    m_order2clientCtx.erase(order->id());
}

//-------------------------------------------------------------------------

const Book::UnregisteredOrder* Book::unregisteredOrder(OrderID orderId) const noexcept
{
    const auto it = m_unregistered.find(orderId);
    return it != m_unregistered.end() ? &it->second : nullptr;
}

//-------------------------------------------------------------------------

taosim::decimal_t Book::processAgainstTheBuyQueue(const Order::Ptr& order, taosim::decimal_t minPrice)
{
    // PRICE BAND, single enforcement point: applied here rather than at the market-order call
    // sites so it binds EVERY aggressor. A band on market orders alone is evaded by a limit order
    // priced deep through the book, which matches at the far level and prints the same excursion.
    // LULD prohibits any trade outside the band, not merely market-order executions.
    sampleBandRef(m_simulation->currentTimestamp());
    const auto ownMin = minPrice;
    minPrice = std::max(minPrice, bandLimit(false));
    // BOTH bounds, not just the sweep's adverse side. Enforcing only the floor here left the upside
    // open: a resting bid parked ABOVE ref*(1+band) is hit by a sell-aggressor and prints far outside
    // the band (measured: 315 prints up to +27.6% in one arm, every one a sell-aggressor above the
    // band and none below - the exact spike-ring mechanic of parking an order and feeding into it).
    // LULD prohibits ANY print outside [lo, hi]; with the band off bandLimit(true) is the max
    // sentinel, so this line is inert and band-off runs stay byte-identical.
    const auto bandHi = bandLimit(true);
    using namespace taosim::util;

    taosim::decimal_t processedQuote = {};
    const auto volumeDecimals = m_simulation->exchange()->config().parameters().volumeIncrementDecimals;
    const auto priceDecimals = m_simulation->exchange()->config().parameters().priceIncrementDecimals;
    const auto maxDecimals = std::max({
        volumeDecimals,
        priceDecimals,
        m_simulation->exchange()->config().parameters().quoteIncrementDecimals,
        m_simulation->exchange()->config().parameters().baseIncrementDecimals
    });
    const auto agentId = m_order2clientCtx[order->id()].agentId;

    auto bestBuyDeque = &bestBuyLevel().value().get();

    order->setVolume(taosim::util::round(order->volume(), volumeDecimals));
    order->setLeverage(taosim::util::round(order->leverage(), volumeDecimals));

    while (order->volume() > 0_dec && bestBuyDeque->price() >= minPrice
           && bestBuyDeque->price() <= bandHi) {
        LimitOrder::Ptr iop = bestBuyDeque->getFirstActiveOrder();
        if (!iop) {
            // All orders on this level are ghosts, advance to next level
            auto optLevel = bestBuyLevel();
            if (!optLevel || &optLevel->get() == bestBuyDeque) {
                break;
            }
            bestBuyDeque = &optLevel->get();
            continue;
        }
        const auto iopAgentId = m_order2clientCtx[iop->id()].agentId;
        // COMPARE WHO ACTED, not who owns the aggressing order.
        //
        // In exchange mode a resting order is usually taken by a sweep the exchange places under its own
        // id (agent -1) once a miner's instruction has moved the pool through it. Comparing the owner
        // therefore never matched (-1 != the miner) and self-trade prevention could not fire at all:
        // zero SELF TRADE PREVENTION lines existed across the lifetime of an exchange process. The
        // miner was nonetheless on both sides of the event its own instruction caused, which is exactly
        // what STP exists to stop. initiatorAgentId is set only on sweep orders and names the miner
        // whose instruction caused them; for every ordinary order it is empty and this is unchanged.
        const auto actingAgentId =
            m_order2clientCtx[order->id()].initiatorAgentId.value_or(agentId);
        // ONLY ORDERS THAT WERE ALREADY RESTING WHEN THIS TAKER ARRIVED.
        //
        // `iop` is the resting order, `order` the incoming aggressor. A sweep the exchange creates at
        // submission to fill a just-placed marketable order arrives in the SAME event as that order,
        // so the "resting" side was never resting when the taker turned up -- it is the very order the
        // sweep exists to fill. Cancelling it is not self-trade prevention, it is destroying the order.
        // On one book, a single engine timestamp:
        //   REGISTERED BUY ORDER #148 FOR 1061.3652@0.012
        //   sweep SELL #149 (1.0x1061.3652@MARKET)
        //   SELF TRADE PREVENTION CANCELED ORDER 148
        // Nothing filled, nothing rested, no notice, both directions, and the miner could not opt out.
        //
        // "Already resting" MUST be decided on order id, not timestamp. Simulation::m_time.current is
        // set per delivered message to instr.delay, a per-batch offset that is NOT monotonic across
        // batches, so an order resting since an earlier batch can carry a LARGER timestamp than the
        // taker arriving now. Comparing timestamps therefore silently stops protecting exactly the
        // orders STP exists to protect. Order ids are minted monotonically, so a lower id is precisely
        // "was on the book first", and it keeps STP firing for the case it was added for: a miner with
        // an EXISTING resting order that submits a separate instruction moving the pool through it.
        // Same instruction => NOT already resting. Different instruction => order id decides.
        //
        // Two distinct hazards, and fixing one alone reintroduces the other. Across batches the
        // timestamp is useless: Simulation::m_time.current is set per delivered message to
        // instr.delay, a per-batch offset that is NOT monotonic, so an order resting since an earlier
        // batch can carry the LARGER timestamp and silently lose STP protection. Within one
        // instruction the order id is useless: the engine's eager sweep is minted immediately after
        // the order it exists to FILL, so the sweep always has the higher id and STP cancels its own
        // target.
        //
        // Timestamp equality does NOT mean "one instruction". A miner's whole batch carries ONE
        // timestamp, so two orders it sends on the same book in one batch are separate instructions
        // that share one. Reading those as a single instruction stands STP down between them, which is
        // exactly the self-trade this guard exists to prevent, and it is reachable in exchange mode
        // because the sweep inherits ctx.delay from the same batch.
        //
        // Dispatch identity is carried explicitly now and compared exactly. It FAILS CLOSED: an
        // absent seq never compares equal, so the simulation path -- which never dispatches
        // instructions and is therefore never stamped -- reduces to the order-id test alone, which
        // is what this expression already evaluated to there.
        const auto& aggSeq = m_order2clientCtx[order->id()].instrSeq;
        const auto& restSeq = m_order2clientCtx[iop->id()].instrSeq;
        const bool sameInstruction = aggSeq.has_value() && aggSeq == restSeq;
        const bool alreadyResting = !sameInstruction && iop->id() < order->id();
        if (actingAgentId == iopAgentId && order->stpFlag() != STPFlag::NONE && alreadyResting){
            // actingAgentId, NOT agentId: the guard above has already proved
            // actingAgentId == iopAgentId, so this is the RESTING ORDER'S OWNER. agentId is the
            // aggressor's own id, which for an exchange-placed sweep is -1 -- and cancelAndLog
            // builds the cancellation event from whatever it is handed, so passing -1 addresses
            // the cancellation to a non-agent and the owner is never notified.
            bestBuyDeque = preventSelfTrade(bestBuyDeque, iop, order, actingAgentId);
            if (bestBuyDeque == nullptr)
                break;
            continue;
        }

        // A resting order whose backing reservation is exhausted must not trade:
        // commit rounding across partial fills can consume the reservation while a
        // dust remainder stays on the level, and a fill against it would abort in
        // ClearingManager::handleTrade ("No reservation for resting..."). Ghost it
        // here — the post-fill twin of this guard below only protects LATER matches.
        if (m_simulation->exchange()->accounts()[iopAgentId][m_id]
                .getReservationInBase(iop->id(), 1_dec) == 0_dec) {
            m_simulation->logDebug(
                "BOOK {} : ORDER #{} REMAINDER {} WITHOUT RESERVATION (GHOSTED)",
                m_id, iop->id(), iop->totalVolume());
            bestBuyDeque->updateVolume(-iop->totalVolume());
            iop->setVolume(0_dec);
            m_topOfBook.invalidate();
            continue;
        }

        const taosim::decimal_t usedVolume = std::min(iop->totalVolume(), order->totalVolume());

        OrderClientContext aggCtx, restCtx;
        if (m_simulation->debug()) {
            aggCtx = m_order2clientCtx[order->id()];
            const auto& aggBalances = m_simulation->exchange()->accounts()[aggCtx.agentId][m_id];
            restCtx = m_order2clientCtx[iop->id()];
            const auto& restingBalances = m_simulation->exchange()->accounts()[restCtx.agentId][m_id];
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : QUOTE : {}  BASE : {}", m_simulation->currentTimestamp(), restCtx.agentId, m_id, *restingBalances.quote, restingBalances.base);
        }

        if (usedVolume > 0_dec) {
            processedQuote += usedVolume * bestBuyDeque->price();
            logTrade(
                m_simulation->currentTimestamp(),
                OrderDirection::SELL,
                order->id(),
                iop->id(),
                usedVolume,
                bestBuyDeque->price());
            recordBandTrade(
                m_simulation->currentTimestamp(), bestBuyDeque->price(),
                m_order2clientCtx[iop->id()].agentId, m_order2clientCtx[order->id()].agentId);
        }

        // The level is charged the resting order's actual totalVolume change once all of the
        // rounding and dust handling below has settled, which keeps it equal to the sum of its
        // orders by construction.
        const auto restingTotalVolumeBefore = iop->totalVolume();
        order->removeLeveragedVolume(usedVolume);
        iop->removeLeveragedVolume(usedVolume);

        order->setVolume(taosim::util::round(order->volume(), maxDecimals));
        iop->setVolume(taosim::util::round(iop->volume(), maxDecimals));

        auto& accounts = m_simulation->exchange()->accounts();
        const auto& aggBalances = accounts[agentId][m_id];
        if ((order->volume() > 0_dec && taosim::util::round(order->volume(), volumeDecimals) == 0_dec) ||
            aggBalances.getReservationInBase(order->id(), 1_dec) == 0_dec){
            order->setVolume(0_dec);
        }

        const auto& restingBalances = accounts[iopAgentId][m_id];
        if ((iop->volume() > 0_dec && taosim::util::round(iop->volume(), volumeDecimals) == 0_dec) ||
            restingBalances.getReservationInBase(iop->id(), 1_dec) == 0_dec){
            iop->setVolume(0_dec);
        }

        bestBuyDeque->updateVolume(iop->totalVolume() - restingTotalVolumeBefore);
        m_topOfBook.invalidate();

        // Ghost order: leave fully filled resting orders in place for reconciliation
        if (taosim::util::round(iop->totalVolume(), volumeDecimals) == 0_dec) {
            m_simulation->logDebug("BOOK {} : ORDER #{} FULLY FILLED (GHOST)", m_id, iop->id());
        }

        if (m_simulation->debug()) {
            const auto& restingBalances = m_simulation->exchange()->accounts()[restCtx.agentId][m_id];
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : QUOTE : {}  BASE : {}", m_simulation->currentTimestamp(), aggCtx.agentId, m_id, *aggBalances.quote, aggBalances.base);
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : QUOTE : {}  BASE : {}", m_simulation->currentTimestamp(), restCtx.agentId, m_id, *restingBalances.quote, restingBalances.base);
        }

        if (!bestBuyDeque->hasActiveOrders()) {
            auto optLevel = bestBuyLevel();
            if (!optLevel) {
                break;
            }
            bestBuyDeque = &optLevel->get();
        }
    }

    // A marketable remainder stopped by the band rather than by the order's own floor or an empty side:
    // the band is refusing prints, which is what the release rule in effectiveBand counts.
    if (order->volume() > 0_dec) {
        if (const auto lvl = bestBuyLevel(); lvl && lvl->get().getFirstActiveOrder()) {
            const auto p = lvl->get().price();
            if (p >= ownMin && (p < minPrice || p > bandHi)) {
                noteBandRefusal();
            }
        }
    }

    return processedQuote;
}

//-------------------------------------------------------------------------

taosim::decimal_t Book::processAgainstTheSellQueue(const Order::Ptr& order, taosim::decimal_t maxPrice)
{
    // PRICE BAND, single enforcement point: applied here rather than at the market-order call
    // sites so it binds EVERY aggressor. A band on market orders alone is evaded by a limit order
    // priced deep through the book, which matches at the far level and prints the same excursion.
    // LULD prohibits any trade outside the band, not merely market-order executions.
    sampleBandRef(m_simulation->currentTimestamp());
    const auto ownMax = maxPrice;
    maxPrice = std::min(maxPrice, bandLimit(true));
    // BOTH bounds - mirror of the buy-queue fix: a resting ask parked BELOW ref*(1-band) lifted by a
    // buy-aggressor printed under the band (measured: 101 prints, every one a buy-aggressor below
    // the band). Inert when the band is off (bandLimit(false) is the min sentinel).
    const auto bandLo = bandLimit(false);
    using namespace taosim::util;

    taosim::decimal_t processedQuote = {};
    const auto volumeDecimals = m_simulation->exchange()->config().parameters().volumeIncrementDecimals;
    const auto priceDecimals = m_simulation->exchange()->config().parameters().priceIncrementDecimals;
    const auto maxDecimals = std::max({
        volumeDecimals,
        priceDecimals,
        m_simulation->exchange()->config().parameters().quoteIncrementDecimals,
        m_simulation->exchange()->config().parameters().baseIncrementDecimals
    });
    const auto agentId = m_order2clientCtx[order->id()].agentId;

    auto bestSellDeque = &bestSellLevel().value().get();

    order->setVolume(taosim::util::round(order->volume(), volumeDecimals));
    order->setLeverage(taosim::util::round(order->leverage(), volumeDecimals));

    while (order->volume() > 0_dec && bestSellDeque->price() <= maxPrice
           && bestSellDeque->price() >= bandLo) {
        LimitOrder::Ptr iop = bestSellDeque->getFirstActiveOrder();
        if (!iop) {
            // All orders on this level are ghosts, advance to next level
            auto optLevel = bestSellLevel();
            if (!optLevel || &optLevel->get() == bestSellDeque) {
                break;
            }
            bestSellDeque = &optLevel->get();
            continue;
        }
        const auto iopAgentId = m_order2clientCtx[iop->id()].agentId;
        // COMPARE WHO ACTED, not who owns the aggressing order.
        //
        // In exchange mode a resting order is usually taken by a sweep the exchange places under its own
        // id (agent -1) once a miner's instruction has moved the pool through it. Comparing the owner
        // therefore never matched (-1 != the miner) and self-trade prevention could not fire at all:
        // zero SELF TRADE PREVENTION lines existed across the lifetime of an exchange process. The
        // miner was nonetheless on both sides of the event its own instruction caused, which is exactly
        // what STP exists to stop. initiatorAgentId is set only on sweep orders and names the miner
        // whose instruction caused them; for every ordinary order it is empty and this is unchanged.
        const auto actingAgentId =
            m_order2clientCtx[order->id()].initiatorAgentId.value_or(agentId);
        // ONLY ORDERS THAT WERE ALREADY RESTING WHEN THIS TAKER ARRIVED.
        //
        // `iop` is the resting order, `order` the incoming aggressor. A sweep the exchange creates at
        // submission to fill a just-placed marketable order arrives in the SAME event as that order,
        // so the "resting" side was never resting when the taker turned up -- it is the very order the
        // sweep exists to fill. Cancelling it is not self-trade prevention, it is destroying the order.
        // On one book, a single engine timestamp:
        //   REGISTERED BUY ORDER #148 FOR 1061.3652@0.012
        //   sweep SELL #149 (1.0x1061.3652@MARKET)
        //   SELF TRADE PREVENTION CANCELED ORDER 148
        // Nothing filled, nothing rested, no notice, both directions, and the miner could not opt out.
        //
        // "Already resting" MUST be decided on order id, not timestamp. Simulation::m_time.current is
        // set per delivered message to instr.delay, a per-batch offset that is NOT monotonic across
        // batches, so an order resting since an earlier batch can carry a LARGER timestamp than the
        // taker arriving now. Comparing timestamps therefore silently stops protecting exactly the
        // orders STP exists to protect. Order ids are minted monotonically, so a lower id is precisely
        // "was on the book first", and it keeps STP firing for the case it was added for: a miner with
        // an EXISTING resting order that submits a separate instruction moving the pool through it.
        // Same instruction => NOT already resting. Different instruction => order id decides.
        //
        // Two distinct hazards, and fixing one alone reintroduces the other. Across batches the
        // timestamp is useless: Simulation::m_time.current is set per delivered message to
        // instr.delay, a per-batch offset that is NOT monotonic, so an order resting since an earlier
        // batch can carry the LARGER timestamp and silently lose STP protection. Within one
        // instruction the order id is useless: the engine's eager sweep is minted immediately after
        // the order it exists to FILL, so the sweep always has the higher id and STP cancels its own
        // target.
        //
        // Timestamp equality does NOT mean "one instruction". A miner's whole batch carries ONE
        // timestamp, so two orders it sends on the same book in one batch are separate instructions
        // that share one. Reading those as a single instruction stands STP down between them, which is
        // exactly the self-trade this guard exists to prevent, and it is reachable in exchange mode
        // because the sweep inherits ctx.delay from the same batch.
        //
        // Dispatch identity is carried explicitly now and compared exactly. It FAILS CLOSED: an
        // absent seq never compares equal, so the simulation path -- which never dispatches
        // instructions and is therefore never stamped -- reduces to the order-id test alone, which
        // is what this expression already evaluated to there.
        const auto& aggSeq = m_order2clientCtx[order->id()].instrSeq;
        const auto& restSeq = m_order2clientCtx[iop->id()].instrSeq;
        const bool sameInstruction = aggSeq.has_value() && aggSeq == restSeq;
        const bool alreadyResting = !sameInstruction && iop->id() < order->id();
        if (actingAgentId == iopAgentId && order->stpFlag() != STPFlag::NONE && alreadyResting){
            // See the buy path: actingAgentId is the resting owner here, agentId is the
            // aggressor (-1 for an exchange sweep), and the cancellation event is built from it.
            bestSellDeque = preventSelfTrade(bestSellDeque, iop, order, actingAgentId);
            if (bestSellDeque == nullptr)
                break;
            continue;
        }

        // Twin of the buy-queue pre-fill guard: never trade against a resting order
        // whose backing reservation is already exhausted (see there).
        if (m_simulation->exchange()->accounts()[iopAgentId][m_id]
                .getReservationInBase(iop->id(), 1_dec) == 0_dec) {
            m_simulation->logDebug(
                "BOOK {} : ORDER #{} REMAINDER {} WITHOUT RESERVATION (GHOSTED)",
                m_id, iop->id(), iop->totalVolume());
            bestSellDeque->updateVolume(-iop->totalVolume());
            iop->setVolume(0_dec);
            m_topOfBook.invalidate();
            continue;
        }

        const taosim::decimal_t usedVolume = std::min(iop->totalVolume(), order->totalVolume());

        OrderClientContext aggCtx, restCtx;
        if (m_simulation->debug()) {
            aggCtx = m_order2clientCtx[order->id()];
            const auto& aggBalances = m_simulation->exchange()->accounts()[aggCtx.agentId][m_id];
            restCtx = m_order2clientCtx[iop->id()];
            const auto& restingBalances = m_simulation->exchange()->accounts()[restCtx.agentId][m_id];
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : QUOTE : {}  BASE : {}",
                m_simulation->currentTimestamp(), restCtx.agentId, m_id, *restingBalances.quote, restingBalances.base);
        }

        if (usedVolume > 0_dec) {
            processedQuote += usedVolume * bestSellDeque->price();
            logTrade(
                m_simulation->currentTimestamp(),
                OrderDirection::BUY,
                order->id(),
                iop->id(),
                usedVolume,
                bestSellDeque->price());
            recordBandTrade(
                m_simulation->currentTimestamp(), bestSellDeque->price(),
                m_order2clientCtx[iop->id()].agentId, m_order2clientCtx[order->id()].agentId);
        }

        // The level is charged the resting order's actual totalVolume change once all of the
        // rounding and dust handling below has settled, which keeps it equal to the sum of its
        // orders by construction.
        const auto restingTotalVolumeBefore = iop->totalVolume();
        order->removeLeveragedVolume(usedVolume);
        iop->removeLeveragedVolume(usedVolume);

        order->setVolume(taosim::util::round(order->volume(), maxDecimals));
        iop->setVolume(taosim::util::round(iop->volume(), maxDecimals));

        auto& accounts = m_simulation->exchange()->accounts();
        const auto& aggBalances = accounts[agentId][m_id];
        if ((order->volume() > 0_dec && taosim::util::round(order->volume(), volumeDecimals) == 0_dec) ||
            aggBalances.getReservationInBase(order->id(), 1_dec) == 0_dec){
            order->setVolume(0_dec);
        }

        const auto& restingBalances = accounts[iopAgentId][m_id];
        if ((iop->volume() > 0_dec && taosim::util::round(iop->volume(), volumeDecimals) == 0_dec) ||
            restingBalances.getReservationInBase(iop->id(), 1_dec) == 0_dec){
            iop->setVolume(0_dec);
        }

        bestSellDeque->updateVolume(iop->totalVolume() - restingTotalVolumeBefore);
        m_topOfBook.invalidate();

        // Ghost order: leave fully filled resting orders in place for reconciliation
        if (taosim::util::round(iop->totalVolume(), volumeDecimals) == 0_dec) {
            m_simulation->logDebug("BOOK {} : ORDER #{} FULLY FILLED (GHOST)", m_id, iop->id());
        }

        if (m_simulation->debug()) {
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : QUOTE : {}  BASE : {}", m_simulation->currentTimestamp(), aggCtx.agentId, m_id, *aggBalances.quote, aggBalances.base);
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : QUOTE : {}  BASE : {}", m_simulation->currentTimestamp(), restCtx.agentId, m_id, *restingBalances.quote, restingBalances.base);
        }

        if (!bestSellDeque->hasActiveOrders()) {
            auto optLevel = bestSellLevel();
            if (!optLevel) {
                break;
            }
            bestSellDeque = &optLevel->get();
        }
    }

    // Mirror of the buy-queue exit: a remainder the band stopped, not the order's own cap or an empty side.
    if (order->volume() > 0_dec) {
        if (const auto lvl = bestSellLevel(); lvl && lvl->get().getFirstActiveOrder()) {
            const auto p = lvl->get().price();
            if (p <= ownMax && (p > maxPrice || p < bandLo)) {
                noteBandRefusal();
            }
        }
    }

    return processedQuote;
}

//-------------------------------------------------------------------------

taosim::book::TickContainer* Book::preventSelfTrade(
    taosim::book::TickContainer* queue,
    const LimitOrder::Ptr& iop,
    const Order::Ptr& order,
    AgentId agentId)
{
    auto stpFlag = order->stpFlag();
    auto now = m_simulation->currentTimestamp();

    // THE INCOMING SIDE NEEDS THE SAME NOTICE AS THE RESTING SIDE. cancelAndLog below tells the owner
    // when STP cancels a RESTING order, but the three paths that cancel the INCOMING order only wrote a
    // log line -- so an order the miner had just placed vanished with its reservation freed and nothing
    // on its channel to say so. An order can be registered, cancelled and unregistered inside a single
    // engine timestamp, which leaves the validator no record of it and the miner holding a phantom
    // resting order whose funds the engine has already released.
    //
    // BOTH MECHANISMS, not exchange-service only. This notice was gated on exchangeServiceMode() on the
    // belief that a simulation miner sees the cancellation as a book event on state.books[id].e. It does
    // not: the published books carry {bids, asks, r} and nothing else, and the validator builds a
    // miner's notices from the proxy's messages alone, so in simulation an STP cancel reached the miner
    // through no channel at all: the order is narrated as cancelled, no RDCO is emitted, and the
    // owner's cancellation handler is never invoked. Miner-initiated cancels already deliver their
    // RESPONSE_DISTRIBUTED_CANCEL_ORDERS through the same buffer in both modes, so there is nothing to
    // fire twice. The only reason not to dispatch is having no proxy to dispatch through.
    auto notifyOwnerCancelled = [&](OrderID orderId, AgentId ownerId, taosim::decimal_t volume) {
        auto* proxy = m_simulation->proxy();
        // DIAGNOSTIC: say whether the notice is dispatched or dropped. "Did it fire" has to be answered
        // from the engine rather than inferred from the miner's silence.
        if (proxy == nullptr) {
            m_simulation->logDebug(
                "{} | AGENT #{} BOOK {} : STP CANCEL NOTICE SUPPRESSED for order {} (no proxy)",
                m_simulation->currentTimestamp(), ownerId, m_id, orderId);
            return;
        }
        m_simulation->logDebug("{} | AGENT #{} BOOK {} : STP CANCEL NOTICE DISPATCHED for order {}",
            m_simulation->currentTimestamp(), ownerId, m_id, orderId);
        proxy->pushNotice(Message::create(
            m_simulation->currentTimestamp(),
            m_simulation->currentTimestamp(),
            m_simulation->exchange()->name(),
            proxy->name(),
            "RESPONSE_DISTRIBUTED_CANCEL_ORDERS",
            MessagePayload::create<DistributedAgentResponsePayload>(
                ownerId,
                MessagePayload::create<CancelOrdersResponsePayload>(
                    std::vector<OrderID>{orderId},
                    MessagePayload::create<CancelOrdersPayload>(
                        std::vector{taosim::event::Cancellation{orderId, volume}}, m_id)))));
    };

    auto cancelAndLog = [&](OrderID orderId, std::optional<taosim::decimal_t> volume = {}) {
        if (cancelOrder(orderId, volume)) {
            taosim::event::Cancellation cancellation{orderId, volume};
            m_simulation->exchange()->signals().at(m_id)->cancelLog(CancellationWithLogContext(
                cancellation,
                std::make_shared<CancellationLogContext>(
                    agentId,
                    m_id,
                    now)));
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : SELF TRADE PREVENTION CANCELED {}ORDER {}", 
                now, agentId, m_id, 
                volume.has_value() ? fmt::format("{} volume of ", volume.value()) : "",
                orderId);
            // TELL THE OWNER. cancelLog above is a LOGGING signal (L2/L3 feeds); no agent message ever
            // carried this cancellation, so the miner's order vanished silently -- an STP cancel has no
            // instruction behind it, hence no response path. Dispatch the same response shape a miner
            // cancel gets, addressed to the owner, delivered through the proxy like every other notice.
            // In BOTH mechanisms: see notifyOwnerCancelled above for why the exchange-service gate that
            // used to sit here was wrong, and why nothing fires twice without it.
            auto* proxy = m_simulation->proxy();
            if (proxy == nullptr) {
                m_simulation->logDebug("{} | AGENT #{} BOOK {} : STP RESTING CANCEL NOTICE SUPPRESSED for order {} (no proxy)",
                    m_simulation->currentTimestamp(), agentId, m_id, orderId);
            } else {
                m_simulation->logDebug("{} | AGENT #{} BOOK {} : STP RESTING CANCEL NOTICE DISPATCHED for order {}",
                    m_simulation->currentTimestamp(), agentId, m_id, orderId);
                // DIRECT, NOT QUEUED -- see DistributedProxyAgent::pushNotice. dispatchMessage from
                // inside matching is never delivered: order 379's notice produced zero proxy receipts.
                proxy->pushNotice(Message::create(
                    m_simulation->currentTimestamp(),
                    m_simulation->currentTimestamp(),
                    m_simulation->exchange()->name(),
                    proxy->name(),
                    "RESPONSE_DISTRIBUTED_CANCEL_ORDERS",
                    MessagePayload::create<DistributedAgentResponsePayload>(
                        agentId,
                        MessagePayload::create<CancelOrdersResponsePayload>(
                            std::vector<OrderID>{orderId},
                            MessagePayload::create<CancelOrdersPayload>(
                                std::vector{taosim::event::Cancellation{orderId, volume}}, m_id)))));
            }
            return true;
        } else {
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : SELF TRADE PREVENTION OF ORDER {} FAILED", now, agentId, m_id, orderId);
            return false;
        }
    };

    if (stpFlag == STPFlag::CN || stpFlag == STPFlag::CB) {
        const auto _stpCancelledVolume = order->volume();
        order->removeVolume(_stpCancelledVolume);
        m_simulation->logDebug("{} | AGENT #{} BOOK {} : SELF TRADE PREVENTION CANCELED ORDER {}", now, agentId, m_id, order->id());
        notifyOwnerCancelled(order->id(), agentId, _stpCancelledVolume);  // STP fires only when both sides are the same agent, so agentId IS this order's owner -- the same recipient cancelAndLog uses for the resting side.
        if (stpFlag == STPFlag::CN) {
            return nullptr;
        }
    }

    // After cancelOrder, the queue pointer may be dangling (deque erase invalidates),
    // so always re-derive from bestBuyLevel/bestSellLevel.
    auto freshQueue = [this](bool isBuy) -> TickContainer* {
        auto optLevel = isBuy ? bestBuyLevel() : bestSellLevel();
        return optLevel ? &optLevel->get() : nullptr;
    };

    if (stpFlag == STPFlag::CO || stpFlag == STPFlag::CB) {
        const bool isBuy = iop->direction() == OrderDirection::BUY;
        cancelAndLog(iop->id());
        queue = freshQueue(isBuy);
        if (stpFlag == STPFlag::CB) {
            return nullptr;
        }
        return queue;
    }

    if (stpFlag == STPFlag::DC) {
        if (iop->totalVolume() == order->totalVolume()){
            const auto _stpCancelledVolume = order->volume();
            order->removeVolume(_stpCancelledVolume);
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : SELF TRADE PREVENTION CANCELED ORDER {}", now, agentId, m_id, order->id());
            notifyOwnerCancelled(order->id(), agentId, _stpCancelledVolume);  // STP fires only when both sides are the same agent, so agentId IS this order's owner -- the same recipient cancelAndLog uses for the resting side.
            cancelAndLog(iop->id());
            return nullptr;
        } else if (iop->totalVolume() < order->totalVolume()){
            auto volumeToCancel = taosim::util::round(iop->totalVolume() / taosim::util::dec1p(order->leverage()),
                m_simulation->exchange()->config().parameters().volumeIncrementDecimals);
            const bool isBuy = iop->direction() == OrderDirection::BUY;
            if (cancelAndLog(iop->id())){
                queue = freshQueue(isBuy);
                if (!queue) return nullptr;
                order->removeVolume(volumeToCancel);
                return queue;
            }
        } else {
            auto volumeToCancel = taosim::util::round(order->totalVolume() / taosim::util::dec1p(iop->leverage()),
                m_simulation->exchange()->config().parameters().volumeIncrementDecimals);
            const auto _stpCancelledVolume = order->volume();
            order->removeVolume(_stpCancelledVolume);
            m_simulation->logDebug("{} | AGENT #{} BOOK {} : SELF TRADE PREVENTION CANCELED ORDER {}", now, agentId, m_id, order->id());
            notifyOwnerCancelled(order->id(), agentId, _stpCancelledVolume);  // STP fires only when both sides are the same agent, so agentId IS this order's owner -- the same recipient cancelAndLog uses for the resting side.
            cancelAndLog(iop->id(), volumeToCancel);
            return nullptr;
        }
    }

    return queue;
}

//-------------------------------------------------------------------------

void Book::clearFilledOrders() noexcept
{
    auto impl = [this](auto&& side) {
        for (auto it = side.begin(); it != side.end(); ) {
            // Remove ghost orders (zero volume) from this level
            for (auto orderIt = it->begin(); orderIt != it->end(); ) {
                if ((*orderIt)->totalVolume() == 0_dec) {
                    unregisterLimitOrder(*orderIt);
                    orderIt = it->erase(orderIt);
                } else {
                    ++orderIt;
                }
            }
            // Remove empty levels; the unregister signal of a later iteration may read the best
            // levels, so the cache must not outlive the erase.
            if (it->empty()) {
                it = side.erase(it);
                m_topOfBook.invalidate();
            } else {
                ++it;
            }
        }
    };

    impl(m_buyQueue);
    impl(m_sellQueue);
    m_topOfBook.invalidate();
}

//-------------------------------------------------------------------------

void Book::printCSV(uint32_t depth) const
{
    std::cout << "ask";
    dumpCSVLOB(m_sellQueue.cbegin(), m_sellQueue.cend(), depth);
    std::cout << "\n";

    std::cout << "bid";
    dumpCSVLOB(m_buyQueue.crbegin(), m_buyQueue.crend(), depth);
    std::cout << "\n";
}

//-------------------------------------------------------------------------

void Book::jsonSerialize(rapidjson::Document& json, const std::string& key) const
{
    auto serialize = [this](rapidjson::Document& json) {
        json.SetObject();
        auto& allocator = json.GetAllocator();

        auto serializeLevelBroad = [](rapidjson::Document& json, const taosim::book::TickContainer& level) {
            json.SetObject();
            auto& allocator = json.GetAllocator();
            json.AddMember(
                "price", rapidjson::Value{taosim::util::decimal2double(level.price())}, allocator);
            json.AddMember(
                "volume", rapidjson::Value{taosim::util::decimal2double(level.volume())}, allocator);
        };

        rapidjson::Value bidsJson{rapidjson::kArrayType};
        for (const auto& level : m_buyQueue | views::reverse | views::take(m_detailedDepth)) {
            rapidjson::Document levelJson{&allocator};
            level.jsonSerialize(levelJson);
            bidsJson.PushBack(levelJson, allocator);
        }
        for (const auto& level : m_buyQueue | views::reverse | views::drop(m_detailedDepth)) {
            rapidjson::Document levelJson{&allocator};
            serializeLevelBroad(levelJson, level);
            bidsJson.PushBack(levelJson, allocator);
        }
        json.AddMember(
            "bid", bidsJson.Size() > 0 ? bidsJson : rapidjson::Value{}.SetNull(), allocator);

        rapidjson::Value asksJson{rapidjson::kArrayType};
        for (const auto& level : m_sellQueue | views::take(m_detailedDepth)) {
            rapidjson::Document levelJson{&allocator};
            level.jsonSerialize(levelJson);
            asksJson.PushBack(levelJson, allocator);
        }
        for (const auto& level : m_sellQueue | views::drop(m_detailedDepth)) {
            rapidjson::Document levelJson{&allocator};
            serializeLevelBroad(levelJson, level);
            asksJson.PushBack(levelJson, allocator);
        }
        json.AddMember(
            "ask", asksJson.Size() > 0 ? asksJson : rapidjson::Value{}.SetNull(), allocator);
    };
    taosim::json::serializeHelper(json, key, serialize);
}

//-------------------------------------------------------------------------

void Book::setupL2Signal()
{
    m_signals.limitOrderProcessed.connect([this](auto&&... args) {
        if (!m_initMode) {
            emitL2Signal(std::forward<decltype(args)>(args)...);
        }
    });
    m_signals.marketOrderProcessed.connect([this](auto&&... args) {
        emitL2Signal(std::forward<decltype(args)>(args)...);
    });
    m_signals.trade.connect([this](auto&&... args) {
        emitL2Signal(std::forward<decltype(args)>(args)...);
    });
    m_signals.cancel.connect([this](auto&&... args) {
        emitL2Signal(std::forward<decltype(args)>(args)...);
    });
}

//-------------------------------------------------------------------------

}  // namespace taosim::book

//-------------------------------------------------------------------------
